﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PropertyManagementPortal.Migrations
{
    /// <inheritdoc />
    public partial class AddNewRole : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroups",
                columns: new[] { "user_group_id", "name", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date" },
                values: new object[] { (short)4, "LGAA Consultant", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)4);
        }
    }
}
