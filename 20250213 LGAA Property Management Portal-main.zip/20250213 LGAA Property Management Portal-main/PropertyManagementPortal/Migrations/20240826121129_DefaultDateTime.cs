﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PropertyManagementPortal.Migrations
{
    /// <inheritdoc />
    public partial class DefaultDateTime : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                keyColumn: "bl_construction_rights_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                keyColumn: "bl_construction_rights_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                keyColumn: "bl_construction_rights_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "email_notification_id",
                keyValue: 1,
                columns: new[] { "email_text", "sys_date_created" },
                values: new object[] { "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n        /* Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Registrovani ste na Portalu za upravljanje imovine kao korisnik.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <b><Username></b>\r\n                                                    \r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Ljubazno Vas molimo da kreirate Vašu lozinku za pristup Portalu. Lozinku će te kreirati tako što kliknete na sljedeći <a href=\"<ConfirmationLink>\">link</a> i slijedite uputstva sistema.\r\n                                                    <br>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "email_notification_id",
                keyValue: 2,
                columns: new[] { "email_text", "sys_date_created" },
                values: new object[] { "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n            /*\r\n                                  Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Kako bi izvršili promjenu Vaše lozinke molimo Vas da pratite sljedeći <a href=\"<ConfirmationLink>\">LINK</a>.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <Username>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)11,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)12,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)13,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 11,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 12,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 13,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 14,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 15,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 16,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 17,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 18,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 19,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 20,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 21,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 22,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 23,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 24,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 25,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 26,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 27,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 28,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 29,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 30,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 31,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 32,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 33,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 34,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 35,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 36,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 37,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 38,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 39,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 40,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 41,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 42,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 43,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 44,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 45,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 46,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 47,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 48,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 49,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 50,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 51,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 52,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 53,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 54,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 55,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 56,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 57,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 58,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 59,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 60,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 61,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 62,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 63,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 64,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 65,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 66,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 67,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 68,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 69,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 70,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 71,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 72,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 73,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 74,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 75,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 76,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 77,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 78,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 79,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 80,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 81,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 82,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 83,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 84,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 85,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 86,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 87,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 88,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 89,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 90,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 91,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 92,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 93,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 94,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 95,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 96,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 97,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 98,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 99,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 100,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 101,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 102,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 103,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 104,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 105,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 106,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 107,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 108,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 109,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 110,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 111,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 112,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 113,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 114,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 115,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 116,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 117,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 118,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 119,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 120,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 121,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 122,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 123,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 124,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 125,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 126,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 127,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 128,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 129,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 130,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 131,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 132,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 133,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 134,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 135,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 136,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 137,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 138,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 139,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 140,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 141,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 142,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                keyColumn: "property_use_basis_document_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                keyColumn: "property_use_basis_document_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                keyColumn: "property_use_basis_document_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserGenders",
                keyColumn: "property_user_gender_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserGenders",
                keyColumn: "property_user_gender_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserGenders",
                keyColumn: "property_user_gender_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                keyColumn: "restricted_real_right_information_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                keyColumn: "restricted_real_right_information_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                keyColumn: "restricted_real_right_information_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "SPF_PropertyTypes",
                keyColumn: "id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "SPF_PropertyTypes",
                keyColumn: "id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Users",
                keyColumn: "user_id",
                keyValue: new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                columns: new[] { "email_code", "sys_created_date", "valid_from", "valid_to" },
                values: new object[] { new Guid("ef496512-1eaf-4d17-9ba1-422cffb755a6"), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2297, 10, 16, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                keyColumn: "al_credit_rating_category_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "AL_LandTypes",
                keyColumn: "al_land_type_id",
                keyValue: (byte)10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1446));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1450));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1452));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1455));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "action_id",
                keyValue: 5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1457));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1600));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1604));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1606));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1609));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1612));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "audit_log_enumeration_id",
                keyValue: 6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1614));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                keyColumn: "bl_construction_rights_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                keyColumn: "bl_construction_rights_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                keyColumn: "bl_construction_rights_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypes",
                keyColumn: "contract_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                keyColumn: "contract_type_based_on_user_status_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "DisputeTypes",
                keyColumn: "dispute_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "email_notification_id",
                keyValue: 1,
                columns: new[] { "email_text", "sys_date_created" },
                values: new object[] { "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n        /* Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Registrovani ste na Portalu za upravljanje imovine kao korisnik.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <b><Username></b>.\r\n                                                    \r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Ljubazno Vas molimo da kreirate Vašu lozinku za pristup Portalu. Lozinku će te kreirati tako što kliknete na sljedeći <a href=\"<ConfirmationLink>\">link</a> i slijedite uputstva sistema.\r\n                                                    <br>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1581) });

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "email_notification_id",
                keyValue: 2,
                columns: new[] { "email_text", "sys_date_created" },
                values: new object[] { "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n            /*\r\n                                  Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Kako bi izvršili promjenu Vaše lozinke molimo Vas da pratite sljedeći <a href=\"<ConfirmationLink>\">LINK</a>.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <Username>.\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1584) });

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)11,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)12,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                keyColumn: "installed_infrastructure_id",
                keyValue: (byte)13,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1679));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1683));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1685));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1688));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1691));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1693));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1695));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1698));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1701));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1703));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 11,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1707));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 12,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1709));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 13,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1712));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 14,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1714));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 15,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1717));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 16,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1722));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 17,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1725));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 18,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1728));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 19,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1731));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 20,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1735));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 21,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1739));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 22,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1742));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 23,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1746));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 24,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1750));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 25,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1754));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 26,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1757));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 27,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1761));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 28,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1764));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 29,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1768));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 30,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1772));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 31,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1776));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 32,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1780));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 33,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1785));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 34,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1789));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 35,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1793));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 36,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1797));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 37,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1801));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 38,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1804));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 39,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1808));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 40,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1812));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 41,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1816));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 42,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1819));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 43,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1822));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 44,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1825));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 45,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1829));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 46,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1832));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 47,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1837));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 48,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1840));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 49,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1844));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 50,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1847));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 51,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1851));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 52,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1854));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 53,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1858));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 54,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1862));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 55,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1866));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 56,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1870));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 57,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1875));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 58,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1891));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 59,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1896));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 60,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1900));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 61,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1904));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 62,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1908));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 63,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1911));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 64,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1915) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 65,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1919));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 66,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1923));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 67,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1927));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 68,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1930));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 69,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1935));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 70,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1943));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 71,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1947));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 72,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1949));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 73,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1952));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 74,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1954));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 75,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1957));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 76,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1960));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 77,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1962));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 78,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1964));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 79,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1967));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 80,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1969));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 81,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1971));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 82,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1974));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 83,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1976));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 84,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1978));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 85,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1981));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 86,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1983));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 87,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1985));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 88,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1988));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 89,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1990));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 90,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1993));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 91,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1995));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 92,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1997));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 93,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1999));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 94,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2002));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 95,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2004));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 96,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2007));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 97,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2009));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 98,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2011));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 99,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2013) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 100,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2016));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 101,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2018));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 102,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2020));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 103,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2023));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 104,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2025));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 105,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2027));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 106,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2030));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 107,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2032));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 108,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2034));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 109,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2037));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 110,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2039));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 111,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2041));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 112,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2044));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 113,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2046));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 114,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2055) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 115,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2058));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 116,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2060));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 117,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2063));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 118,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2065));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 119,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2067));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 120,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2070));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 121,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2073) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 122,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2075));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 123,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2078));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 124,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2080));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 125,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2082));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 126,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2085));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 127,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2087));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 128,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2089));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 129,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2092));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 130,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2094));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 131,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2097));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 132,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2100));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 133,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2102));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 134,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2104));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 135,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2107));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 136,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2109));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 137,
                columns: new[] { "local_government_unit_id", "sys_created_date" },
                values: new object[] { (byte)1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2111) });

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 138,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2114));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 139,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2116));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 140,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2118));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 141,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2120));

            migrationBuilder.UpdateData(
                schema: "mm",
                table: "Municipalities",
                keyColumn: "municipality_id",
                keyValue: 142,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2123));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                keyColumn: "obs_rba_spf_condition_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                keyColumn: "obs_rba_spf_energy_class_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                keyColumn: "obs_rba_spf_property_type_id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                keyColumn: "ownership_rights_acquisition_legal_basis_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "OwnershipTypes",
                keyColumn: "ownership_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PaymentFrequencies",
                keyColumn: "payment_frequency_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PossessionBases",
                keyColumn: "possession_basis_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyCategories",
                keyColumn: "property_category_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyStatuses",
                keyColumn: "property_status_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBases",
                keyColumn: "property_use_basis_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                keyColumn: "property_use_basis_document_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                keyColumn: "property_use_basis_document_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                keyColumn: "property_use_basis_document_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserGenders",
                keyColumn: "property_user_gender_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserGenders",
                keyColumn: "property_user_gender_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserGenders",
                keyColumn: "property_user_gender_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "PropertyUserTypes",
                keyColumn: "property_user_type_id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                keyColumn: "restricted_real_right_information_id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                keyColumn: "restricted_real_right_information_id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                keyColumn: "restricted_real_right_information_id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "SPF_PropertyTypes",
                keyColumn: "id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "SPF_PropertyTypes",
                keyColumn: "id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1160));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1239));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "user_group_id",
                keyValue: (short)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1242));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Users",
                keyColumn: "user_id",
                keyValue: new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                columns: new[] { "email_code", "sys_created_date", "valid_from", "valid_to" },
                values: new object[] { new Guid("8f1079ac-a492-4055-b664-6ba23a6f65b2"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1544), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1545), new DateTime(2297, 10, 25, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1547) });

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)1,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)2,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)3,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)4,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)5,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)6,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)7,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)8,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)9,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));

            migrationBuilder.UpdateData(
                schema: "pmp",
                table: "Zones",
                keyColumn: "id",
                keyValue: (byte)10,
                column: "sys_created_date",
                value: new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169));
        }
    }
}
