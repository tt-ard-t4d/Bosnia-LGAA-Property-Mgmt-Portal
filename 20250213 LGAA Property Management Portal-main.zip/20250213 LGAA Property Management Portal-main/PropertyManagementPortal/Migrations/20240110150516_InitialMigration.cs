﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PropertyManagementPortal.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.EnsureSchema(
                name: "pmp");

            migrationBuilder.EnsureSchema(
                name: "mm");

            migrationBuilder.CreateTable(
                name: "Actions",
                schema: "dbo",
                columns: table => new
                {
                    action_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    action_name = table.Column<string>(type: "text", nullable: false),
                    action_enumeration_name = table.Column<string>(type: "text", nullable: false),
                    description = table.Column<string>(type: "text", nullable: true),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_actions", x => x.action_id);
                });

            migrationBuilder.CreateTable(
                name: "ActionsHistory",
                schema: "dbo",
                columns: table => new
                {
                    history_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    action_id = table.Column<int>(type: "integer", nullable: false),
                    action_name = table.Column<string>(type: "text", nullable: false),
                    action_enumeration_name = table.Column<string>(type: "text", nullable: false),
                    description = table.Column<string>(type: "text", nullable: true),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false),
                    status = table.Column<short>(type: "smallint", nullable: true),
                    status_name = table.Column<string>(type: "text", nullable: true),
                    sys_entry_time = table.Column<DateTime>(type: "timestamp", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_actions_history", x => x.history_id);
                });

            migrationBuilder.CreateTable(
                name: "AL_CreditRatingCategories",
                schema: "pmp",
                columns: table => new
                {
                    al_credit_rating_category_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_al_credit_rating_categories", x => x.al_credit_rating_category_id);
                });

            migrationBuilder.CreateTable(
                name: "AL_LandTypes",
                schema: "pmp",
                columns: table => new
                {
                    al_land_type_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_al_land_types", x => x.al_land_type_id);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogEnumerations",
                schema: "dbo",
                columns: table => new
                {
                    audit_log_enumeration_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    audit_log_enumeration_description = table.Column<string>(type: "text", nullable: false),
                    audit_log_enumeration_text = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_audit_log_enumerations", x => x.audit_log_enumeration_id);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogs",
                schema: "dbo",
                columns: table => new
                {
                    audit_log_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    audit_log_text = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<int>(type: "integer", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<int>(type: "integer", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    related_item_id = table.Column<long>(type: "bigint", nullable: true),
                    audit_log_enumeration_id = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_audit_logs", x => x.audit_log_id);
                });

            migrationBuilder.CreateTable(
                name: "BL_ConstructionRightsBases",
                schema: "pmp",
                columns: table => new
                {
                    bl_construction_rights_basis_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_bl_construction_rights_bases", x => x.bl_construction_rights_basis_id);
                });

            migrationBuilder.CreateTable(
                name: "ContractTypes",
                schema: "pmp",
                columns: table => new
                {
                    contract_type_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_contract_types", x => x.contract_type_id);
                });

            migrationBuilder.CreateTable(
                name: "ContractTypesBasedOnUserStatus",
                schema: "pmp",
                columns: table => new
                {
                    contract_type_based_on_user_status_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_contract_types_based_on_user_status", x => x.contract_type_based_on_user_status_id);
                });

            migrationBuilder.CreateTable(
                name: "DisputeTypes",
                schema: "pmp",
                columns: table => new
                {
                    dispute_type_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_dispute_types", x => x.dispute_type_id);
                });

            migrationBuilder.CreateTable(
                name: "EmailNotifications",
                schema: "dbo",
                columns: table => new
                {
                    email_notification_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    email_description = table.Column<string>(type: "text", nullable: false),
                    email_subject = table.Column<string>(type: "text", nullable: false),
                    email_text = table.Column<string>(type: "text", nullable: false),
                    sys_date_created = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_date_last_modified = table.Column<DateTime>(type: "timestamp", nullable: true),
                    sys_created_by_user_id = table.Column<int>(type: "integer", nullable: false),
                    sys_modified_by_user_id = table.Column<int>(type: "integer", nullable: true),
                    email_status = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_email_notifications", x => x.email_notification_id);
                });

            migrationBuilder.CreateTable(
                name: "Entities",
                schema: "mm",
                columns: table => new
                {
                    entity_id = table.Column<byte>(type: "smallint", nullable: false),
                    entity_name = table.Column<string>(type: "text", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_entities", x => x.entity_id);
                });

            migrationBuilder.CreateTable(
                name: "get_user_actions",
                columns: table => new
                {
                    action_id = table.Column<int>(type: "integer", nullable: false),
                    action_name = table.Column<string>(type: "text", nullable: false),
                    action_enumeration_name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "InstalledInfrastructure",
                schema: "pmp",
                columns: table => new
                {
                    installed_infrastructure_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_installed_infrastructure", x => x.installed_infrastructure_id);
                });

            migrationBuilder.CreateTable(
                name: "LocalGovernmentUnits",
                schema: "mm",
                columns: table => new
                {
                    local_government_unit_id = table.Column<byte>(type: "smallint", nullable: false),
                    local_government_unit_name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_local_government_units", x => x.local_government_unit_id);
                });

            migrationBuilder.CreateTable(
                name: "OBS_RBA_SPF_Conditions",
                schema: "pmp",
                columns: table => new
                {
                    obs_rba_spf_condition_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_obs_rba_spf_conditions", x => x.obs_rba_spf_condition_id);
                });

            migrationBuilder.CreateTable(
                name: "OBS_RBA_SPF_EnergyClasses",
                schema: "pmp",
                columns: table => new
                {
                    obs_rba_spf_energy_class_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_obs_rba_spf_energy_classes", x => x.obs_rba_spf_energy_class_id);
                });

            migrationBuilder.CreateTable(
                name: "OBS_RBA_SPF_PropertyTypes",
                schema: "pmp",
                columns: table => new
                {
                    obs_rba_spf_property_type_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_obs_rba_spf_property_types", x => x.obs_rba_spf_property_type_id);
                });

            migrationBuilder.CreateTable(
                name: "OwnershipRightsAcquisitionLegalBases",
                schema: "pmp",
                columns: table => new
                {
                    ownership_rights_acquisition_legal_basis_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ownership_rights_acquisition_legal_bases", x => x.ownership_rights_acquisition_legal_basis_id);
                });

            migrationBuilder.CreateTable(
                name: "OwnershipTypes",
                schema: "pmp",
                columns: table => new
                {
                    ownership_type_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ownership_types", x => x.ownership_type_id);
                });

            migrationBuilder.CreateTable(
                name: "PaymentFrequencies",
                schema: "pmp",
                columns: table => new
                {
                    payment_frequency_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_payment_frequencies", x => x.payment_frequency_id);
                });

            migrationBuilder.CreateTable(
                name: "PossessionBases",
                schema: "pmp",
                columns: table => new
                {
                    possession_basis_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_possession_bases", x => x.possession_basis_id);
                });

            migrationBuilder.CreateTable(
                name: "PropertyCategories",
                schema: "pmp",
                columns: table => new
                {
                    property_category_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    code = table.Column<string>(type: "text", nullable: false),
                    internal_name = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_categories", x => x.property_category_id);
                });

            migrationBuilder.CreateTable(
                name: "PropertyStatuses",
                schema: "pmp",
                columns: table => new
                {
                    property_status_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_statuses", x => x.property_status_id);
                });

            migrationBuilder.CreateTable(
                name: "PropertyUseBases",
                schema: "pmp",
                columns: table => new
                {
                    property_use_basis_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_use_bases", x => x.property_use_basis_id);
                });

            migrationBuilder.CreateTable(
                name: "PropertyUseBasisDocuments",
                schema: "pmp",
                columns: table => new
                {
                    property_use_basis_document_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_use_basis_documents", x => x.property_use_basis_document_id);
                });

            migrationBuilder.CreateTable(
                name: "PropertyUserGenders",
                schema: "pmp",
                columns: table => new
                {
                    property_user_gender_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_user_genders", x => x.property_user_gender_id);
                });

            migrationBuilder.CreateTable(
                name: "PropertyUserTypes",
                schema: "pmp",
                columns: table => new
                {
                    property_user_type_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_user_types", x => x.property_user_type_id);
                });

            migrationBuilder.CreateTable(
                name: "RestrictedRealRightInformation",
                schema: "pmp",
                columns: table => new
                {
                    restricted_real_right_information_id = table.Column<byte>(type: "smallint", nullable: false),
                    value = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_restricted_real_right_information", x => x.restricted_real_right_information_id);
                });

            migrationBuilder.CreateTable(
                name: "SPF_PropertyTypes",
                schema: "pmp",
                columns: table => new
                {
                    id = table.Column<byte>(type: "smallint", nullable: false),
                    title = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_spf_property_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "UserGroups",
                schema: "dbo",
                columns: table => new
                {
                    user_group_id = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_user_groups", x => x.user_group_id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                schema: "dbo",
                columns: table => new
                {
                    user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    valid_from = table.Column<DateTime>(type: "timestamp", nullable: false),
                    valid_to = table.Column<DateTime>(type: "timestamp", nullable: false),
                    first_name_enc = table.Column<string>(type: "text", nullable: false),
                    last_name_enc = table.Column<string>(type: "text", nullable: false),
                    email_enc = table.Column<string>(type: "text", nullable: false),
                    user_name_enc = table.Column<string>(type: "text", nullable: false),
                    password_hash = table.Column<string>(type: "text", nullable: false),
                    password_salt = table.Column<string>(type: "text", nullable: false),
                    email_code = table.Column<Guid>(type: "uuid", nullable: false),
                    language_id = table.Column<int>(type: "integer", nullable: false),
                    is_directory_user = table.Column<bool>(type: "boolean", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_users", x => x.user_id);
                });

            migrationBuilder.CreateTable(
                name: "Zones",
                schema: "pmp",
                columns: table => new
                {
                    id = table.Column<byte>(type: "smallint", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_zones", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Municipalities",
                schema: "mm",
                columns: table => new
                {
                    municipality_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    entity_id = table.Column<byte>(type: "smallint", nullable: false),
                    slug = table.Column<string>(type: "text", nullable: false),
                    municipality_name = table.Column<string>(type: "text", nullable: false),
                    local_government_unit_id = table.Column<byte>(type: "smallint", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_municipalities", x => x.municipality_id);
                    table.ForeignKey(
                        name: "fk_municipalities_entities_entity_id",
                        column: x => x.entity_id,
                        principalSchema: "mm",
                        principalTable: "Entities",
                        principalColumn: "entity_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_municipalities_local_government_unit_local_government_unit_",
                        column: x => x.local_government_unit_id,
                        principalSchema: "mm",
                        principalTable: "LocalGovernmentUnits",
                        principalColumn: "local_government_unit_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserGroupActionRel",
                schema: "dbo",
                columns: table => new
                {
                    user_group_and_action_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_group_id = table.Column<short>(type: "smallint", nullable: false),
                    action_id = table.Column<int>(type: "integer", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_user_group_action_rel", x => x.user_group_and_action_id);
                    table.ForeignKey(
                        name: "fk_user_group_action_rel_actions_action_id",
                        column: x => x.action_id,
                        principalSchema: "dbo",
                        principalTable: "Actions",
                        principalColumn: "action_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_user_group_action_rel_user_groups_user_group_id",
                        column: x => x.user_group_id,
                        principalSchema: "dbo",
                        principalTable: "UserGroups",
                        principalColumn: "user_group_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserActionRel",
                schema: "dbo",
                columns: table => new
                {
                    user_and_action_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    action_id = table.Column<int>(type: "integer", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_user_action_rel", x => x.user_and_action_id);
                    table.ForeignKey(
                        name: "fk_user_action_rel_actions_action_id",
                        column: x => x.action_id,
                        principalSchema: "dbo",
                        principalTable: "Actions",
                        principalColumn: "action_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_user_action_rel_users_user_id",
                        column: x => x.user_id,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "user_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserGroupUserRel",
                schema: "dbo",
                columns: table => new
                {
                    user_and_group_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    user_group_id = table.Column<short>(type: "smallint", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_user_group_user_rel", x => x.user_and_group_id);
                    table.ForeignKey(
                        name: "fk_user_group_user_rel_user_groups_user_group_id",
                        column: x => x.user_group_id,
                        principalSchema: "dbo",
                        principalTable: "UserGroups",
                        principalColumn: "user_group_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_user_group_user_rel_users_user_id",
                        column: x => x.user_id,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "user_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Properties",
                schema: "pmp",
                columns: table => new
                {
                    property_id = table.Column<Guid>(type: "uuid", nullable: false),
                    property_display_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    municipality_id = table.Column<int>(type: "integer", nullable: false),
                    property_category_id = table.Column<byte>(type: "smallint", nullable: false),
                    location_address = table.Column<string>(type: "text", nullable: false),
                    ko = table.Column<string>(type: "text", nullable: true),
                    kp = table.Column<string>(type: "text", nullable: true),
                    property_register = table.Column<string>(type: "text", nullable: true),
                    zone_id = table.Column<byte>(type: "smallint", nullable: true),
                    latitude = table.Column<decimal>(type: "numeric", nullable: true),
                    longitude = table.Column<decimal>(type: "numeric", nullable: true),
                    property_area = table.Column<decimal>(type: "numeric", nullable: true),
                    obs_rba_spf_unit_number = table.Column<int>(type: "integer", nullable: true),
                    obs_rba_spf_garden_area = table.Column<decimal>(type: "numeric", nullable: true),
                    property_owner = table.Column<string>(type: "text", nullable: false),
                    possession_basis_id = table.Column<byte>(type: "smallint", nullable: true),
                    ownership_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    is_dispute = table.Column<bool>(type: "boolean", nullable: true),
                    dispute_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    usurpation_exists = table.Column<bool>(type: "boolean", nullable: true),
                    ownership_rights_acquisition_year = table.Column<int>(type: "integer", nullable: true),
                    ownership_rights_acquisition_legal_basis_id = table.Column<byte>(type: "smallint", nullable: true),
                    ownership_rights_acquisition_legitimation_information = table.Column<string>(type: "text", nullable: true),
                    is_nationalized_property = table.Column<bool>(type: "boolean", nullable: true),
                    is_restricted_disposition = table.Column<bool>(type: "boolean", nullable: true),
                    restricted_real_right_information_id = table.Column<byte>(type: "smallint", nullable: true),
                    restricted_real_right_information_other = table.Column<string>(type: "text", nullable: true),
                    al_credit_rating_category_id = table.Column<byte>(type: "smallint", nullable: true),
                    al_land_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    bl_has_construction_rights = table.Column<bool>(type: "boolean", nullable: true),
                    bl_construction_rights_basis_id = table.Column<byte>(type: "smallint", nullable: true),
                    bl_construction_rights_holder = table.Column<string>(type: "text", nullable: true),
                    al_bl_land_use_according_regulatory_plan = table.Column<string>(type: "text", nullable: true),
                    obs_rba_spf_property_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    obs_rba_spf_number_of_floors = table.Column<decimal>(type: "numeric", nullable: true),
                    obs_rba_is_shared_object = table.Column<bool>(type: "boolean", nullable: true),
                    obs_rba_spf_energy_class_id = table.Column<byte>(type: "smallint", nullable: true),
                    obs_rba_spf_build_year = table.Column<int>(type: "integer", nullable: true),
                    obs_rba_spf_condition_id = table.Column<byte>(type: "smallint", nullable: true),
                    spf_is_legally_constructed = table.Column<bool>(type: "boolean", nullable: true),
                    spf_property_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    comment = table.Column<string>(type: "character varying(65000)", maxLength: 65000, nullable: true),
                    property_installed_infrastructures_other = table.Column<string>(type: "text", nullable: true),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_properties", x => x.property_id);
                    table.ForeignKey(
                        name: "fk_properties_al_credit_rating_categories_al_credit_rating_categ",
                        column: x => x.al_credit_rating_category_id,
                        principalSchema: "pmp",
                        principalTable: "AL_CreditRatingCategories",
                        principalColumn: "al_credit_rating_category_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_al_land_types_al_land_type_id",
                        column: x => x.al_land_type_id,
                        principalSchema: "pmp",
                        principalTable: "AL_LandTypes",
                        principalColumn: "al_land_type_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_bl_construction_rights_bases_bl_construction_right",
                        column: x => x.bl_construction_rights_basis_id,
                        principalSchema: "pmp",
                        principalTable: "BL_ConstructionRightsBases",
                        principalColumn: "bl_construction_rights_basis_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_dispute_types_dispute_type_id",
                        column: x => x.dispute_type_id,
                        principalSchema: "pmp",
                        principalTable: "DisputeTypes",
                        principalColumn: "dispute_type_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_municipalities_municipality_id",
                        column: x => x.municipality_id,
                        principalSchema: "mm",
                        principalTable: "Municipalities",
                        principalColumn: "municipality_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_obs_rba_spf_conditions_obs_rba_spf_condition_id",
                        column: x => x.obs_rba_spf_condition_id,
                        principalSchema: "pmp",
                        principalTable: "OBS_RBA_SPF_Conditions",
                        principalColumn: "obs_rba_spf_condition_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_obs_rba_spf_energy_classes_obs_rba_spf_energy_cla",
                        column: x => x.obs_rba_spf_energy_class_id,
                        principalSchema: "pmp",
                        principalTable: "OBS_RBA_SPF_EnergyClasses",
                        principalColumn: "obs_rba_spf_energy_class_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_obs_rba_spf_property_types_obs_rba_spf_property_t",
                        column: x => x.obs_rba_spf_property_type_id,
                        principalSchema: "pmp",
                        principalTable: "OBS_RBA_SPF_PropertyTypes",
                        principalColumn: "obs_rba_spf_property_type_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_ownership_rights_acquisition_legal_bases_ownership_r",
                        column: x => x.ownership_rights_acquisition_legal_basis_id,
                        principalSchema: "pmp",
                        principalTable: "OwnershipRightsAcquisitionLegalBases",
                        principalColumn: "ownership_rights_acquisition_legal_basis_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_ownership_types_ownership_type_id",
                        column: x => x.ownership_type_id,
                        principalSchema: "pmp",
                        principalTable: "OwnershipTypes",
                        principalColumn: "ownership_type_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_possession_bases_possession_basis_id",
                        column: x => x.possession_basis_id,
                        principalSchema: "pmp",
                        principalTable: "PossessionBases",
                        principalColumn: "possession_basis_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_property_categories_property_category_id",
                        column: x => x.property_category_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyCategories",
                        principalColumn: "property_category_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_restricted_real_right_information_restricted_rea",
                        column: x => x.restricted_real_right_information_id,
                        principalSchema: "pmp",
                        principalTable: "RestrictedRealRightInformation",
                        principalColumn: "restricted_real_right_information_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_spf_property_types_spf_property_type_id",
                        column: x => x.spf_property_type_id,
                        principalSchema: "pmp",
                        principalTable: "SPF_PropertyTypes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_properties_zones_zone_id",
                        column: x => x.zone_id,
                        principalSchema: "pmp",
                        principalTable: "Zones",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserMunicipalityRel",
                schema: "mm",
                columns: table => new
                {
                    user_and_municipality_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    municipality_id = table.Column<int>(type: "integer", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_user_municipality_rel", x => x.user_and_municipality_id);
                    table.ForeignKey(
                        name: "fk_user_municipality_rel_municipalities_municipality_id",
                        column: x => x.municipality_id,
                        principalSchema: "mm",
                        principalTable: "Municipalities",
                        principalColumn: "municipality_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_user_municipality_rel_users_user_id",
                        column: x => x.user_id,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "user_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PropertyInstalledInfrastructureRel",
                schema: "pmp",
                columns: table => new
                {
                    property_installed_infrastructure_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    property_id = table.Column<Guid>(type: "uuid", nullable: false),
                    installed_infrastructure_id = table.Column<byte>(type: "smallint", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_installed_infrastructure_rel", x => x.property_installed_infrastructure_id);
                    table.ForeignKey(
                        name: "fk_property_installed_infrastructure_rel_installed_infrastructure_",
                        column: x => x.installed_infrastructure_id,
                        principalSchema: "pmp",
                        principalTable: "InstalledInfrastructure",
                        principalColumn: "installed_infrastructure_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_installed_infrastructure_rel_properties_property_id",
                        column: x => x.property_id,
                        principalSchema: "pmp",
                        principalTable: "Properties",
                        principalColumn: "property_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PropertyLeaseData",
                schema: "pmp",
                columns: table => new
                {
                    property_lease_data_id = table.Column<Guid>(type: "uuid", nullable: false),
                    property_id = table.Column<Guid>(type: "uuid", nullable: false),
                    property_status_id = table.Column<byte>(type: "smallint", nullable: false),
                    property_user_name = table.Column<string>(type: "text", nullable: true),
                    contract_number = table.Column<string>(type: "text", nullable: true),
                    contract_conclusion_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    contract_duration_in_months = table.Column<int>(type: "integer", nullable: true),
                    payment_frequency_id = table.Column<byte>(type: "smallint", nullable: true),
                    other_contractual_obligations = table.Column<string>(type: "text", nullable: true),
                    property_use_basis_document_id = table.Column<byte>(type: "smallint", nullable: true),
                    property_use_basis_id = table.Column<byte>(type: "smallint", nullable: true),
                    property_user_gender_id = table.Column<byte>(type: "smallint", nullable: true),
                    property_user_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    property_user_type_other = table.Column<string>(type: "text", nullable: true),
                    contracted_value = table.Column<decimal>(type: "numeric", nullable: true),
                    contract_type_based_on_user_status_id = table.Column<byte>(type: "smallint", nullable: true),
                    contract_type_id = table.Column<byte>(type: "smallint", nullable: true),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_lease_data", x => x.property_lease_data_id);
                    table.ForeignKey(
                        name: "fk_property_lease_data_contract_types_based_on_user_status_contr",
                        column: x => x.contract_type_based_on_user_status_id,
                        principalSchema: "pmp",
                        principalTable: "ContractTypesBasedOnUserStatus",
                        principalColumn: "contract_type_based_on_user_status_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_contract_types_contract_type_id",
                        column: x => x.contract_type_id,
                        principalSchema: "pmp",
                        principalTable: "ContractTypes",
                        principalColumn: "contract_type_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_payment_frequencies_payment_frequency_id",
                        column: x => x.payment_frequency_id,
                        principalSchema: "pmp",
                        principalTable: "PaymentFrequencies",
                        principalColumn: "payment_frequency_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_properties_property_id",
                        column: x => x.property_id,
                        principalSchema: "pmp",
                        principalTable: "Properties",
                        principalColumn: "property_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_property_statuses_property_status_id",
                        column: x => x.property_status_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyStatuses",
                        principalColumn: "property_status_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_property_use_bases_property_use_basis_id",
                        column: x => x.property_use_basis_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyUseBases",
                        principalColumn: "property_use_basis_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_property_use_basis_documents_property_use",
                        column: x => x.property_use_basis_document_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyUseBasisDocuments",
                        principalColumn: "property_use_basis_document_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_property_user_genders_property_user_gende",
                        column: x => x.property_user_gender_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyUserGenders",
                        principalColumn: "property_user_gender_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_property_lease_data_property_user_types_property_user_type_id",
                        column: x => x.property_user_type_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyUserTypes",
                        principalColumn: "property_user_type_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PropertyValues",
                schema: "pmp",
                columns: table => new
                {
                    property_value_id = table.Column<Guid>(type: "uuid", nullable: false),
                    property_id = table.Column<Guid>(type: "uuid", nullable: false),
                    current_year_bookkeeping_value = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    current_year_bookkeeping_value_comment = table.Column<string>(type: "text", nullable: true),
                    current_year_estimated_market_value = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    current_year_estimated_market_value_comment = table.Column<string>(type: "text", nullable: true),
                    estimated_maintenance_cost = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    estimated_maintenance_cost_comment = table.Column<string>(type: "text", nullable: true),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    sys_created_date = table.Column<DateTime>(type: "timestamp", nullable: false),
                    sys_last_modified_by_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sys_last_modified_date = table.Column<DateTime>(type: "timestamp", nullable: true),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_property_values", x => x.property_value_id);
                    table.ForeignKey(
                        name: "fk_property_values_properties_property_id",
                        column: x => x.property_id,
                        principalSchema: "pmp",
                        principalTable: "Properties",
                        principalColumn: "property_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AttachedFiles",
                schema: "dbo",
                columns: table => new
                {
                    attached_file_id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    property_id = table.Column<Guid>(type: "uuid", nullable: true),
                    property_lease_data_id = table.Column<Guid>(type: "uuid", nullable: true),
                    azure_file_id = table.Column<Guid>(type: "uuid", nullable: false),
                    file_name = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: false),
                    extension = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    content_type = table.Column<string>(type: "text", nullable: false),
                    title = table.Column<string>(type: "character varying(1500)", maxLength: 1500, nullable: false),
                    size = table.Column<long>(type: "bigint", nullable: true),
                    link = table.Column<string>(type: "text", nullable: false),
                    sys_created_by_user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    retired = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_attached_files", x => x.attached_file_id);
                    table.ForeignKey(
                        name: "fk_attached_files_properties_property_id",
                        column: x => x.property_id,
                        principalSchema: "pmp",
                        principalTable: "Properties",
                        principalColumn: "property_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_attached_files_property_lease_data_property_lease_data_id",
                        column: x => x.property_lease_data_id,
                        principalSchema: "pmp",
                        principalTable: "PropertyLeaseData",
                        principalColumn: "property_lease_data_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "AL_CreditRatingCategories",
                columns: new[] { "al_credit_rating_category_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "I bonitetna kategorija(90 - 100 bodova)" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "II bonitetna kategorija(80 - 90 bodova)" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "III bonitetna kategorija(60 - 80 bodova)" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "IV bonitetna kategorija(40 - 60 bodova), koju čine: -IVa bonitetna potkategorija; -IVb bonitetna potkategorija;" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "V bonitetna kategorija(30 - 40 bodova)" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "VI bonitetna kategorija(20 - 30 bodova)" },
                    { (byte)7, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "VII bonitetna kategorija(10 - 20 bodova)" },
                    { (byte)8, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "VIII bonitetna kategorija(do 10 bodova)" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "AL_LandTypes",
                columns: new[] { "al_land_type_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Oranice" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Bašte" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Voćnjaci" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Vinogradi" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Livade" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Pašnjaci" },
                    { (byte)7, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Bare" },
                    { (byte)8, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Trske" },
                    { (byte)9, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Močvare" },
                    { (byte)10, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "Actions",
                columns: new[] { "action_id", "action_enumeration_name", "action_name", "description", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date" },
                values: new object[,]
                {
                    { 1, "ADMIN_USER_CREATE", "Create User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1446), null, null },
                    { 2, "ADMIN_USER_READ", "View User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1450), null, null },
                    { 3, "ADMIN_USER_EDIT", "Edit User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1452), null, null },
                    { 4, "ADMIN_USER_DELETE", "Delete User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1455), null, null },
                    { 5, "ADMIN_USERS_OVERVIEW", "Users Overview", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1457), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                columns: new[] { "audit_log_enumeration_id", "audit_log_enumeration_description", "audit_log_enumeration_text", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date" },
                values: new object[,]
                {
                    { 1, "Log-in", "User <username> logged in.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1600), null, null },
                    { 2, "Log-out", "User <username> logged out.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1604), null, null },
                    { 3, "User registration", "User <username> has been registered.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1606), null, null },
                    { 4, "User creation", "User <username> has been created.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1609), null, null },
                    { 5, "Email notifications sent", "Email notification <emailNotificationName> has been sent to <username>.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1612), null, null },
                    { 6, "Forgotten password reset", "User <username> requested password reset.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1614), null, null }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "BL_ConstructionRightsBases",
                columns: new[] { "bl_construction_rights_basis_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ugovor" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Odluka" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "ContractTypes",
                columns: new[] { "contract_type_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ugovor o prodaji" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ugovor o najmu/zakupu/podzakupu" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ugovor o koncesiji" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "ContractTypesBasedOnUserStatus",
                columns: new[] { "contract_type_based_on_user_status_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Komercijalna cijena" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Subvencionirana cijena - socijalna kategorija" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Bez naknade" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "DisputeTypes",
                columns: new[] { "dispute_type_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Upravni postupak" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Sudski postupak" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Upravni spor" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "EmailNotifications",
                columns: new[] { "email_notification_id", "email_description", "email_status", "email_subject", "email_text", "sys_created_by_user_id", "sys_date_created", "sys_date_last_modified", "sys_modified_by_user_id" },
                values: new object[,]
                {
                    { 1, "EmailPasswordSetup", 2, "Setup your password", "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n        /* Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Registrovani ste na Portalu za upravljanje imovine kao korisnik.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <b><Username></b>.\r\n                                                    \r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Ljubazno Vas molimo da kreirate Vašu lozinku za pristup Portalu. Lozinku će te kreirati tako što kliknete na sljedeći <a href=\"<ConfirmationLink>\">link</a> i slijedite uputstva sistema.\r\n                                                    <br>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", 1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1581), null, null },
                    { 2, "EmailPasswordReset", 2, "Reset your password", "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n            /*\r\n                                  Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Kako bi izvršili promjenu Vaše lozinke molimo Vas da pratite sljedeći <a href=\"<ConfirmationLink>\">LINK</a>.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <Username>.\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", 1, new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1584), null, null }
                });

            migrationBuilder.InsertData(
                schema: "mm",
                table: "Entities",
                columns: new[] { "entity_id", "entity_name", "retired" },
                values: new object[,]
                {
                    { (byte)1, "Federacija Bosne i Hercegovine", false },
                    { (byte)2, "Republika Srpska", false }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "InstalledInfrastructure",
                columns: new[] { "installed_infrastructure_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Pristupni put" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Elektro mreža" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Sistem navodnjavanja" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Sistem zasjenjivanja" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Protugradne mreže" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Sistem zaštite od mraza" },
                    { (byte)7, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Pristup - putna komunikacija" },
                    { (byte)8, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Elektro priključak" },
                    { (byte)9, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Vodovod" },
                    { (byte)10, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Kanalizacija" },
                    { (byte)11, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Centralno grijanje" },
                    { (byte)12, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Toplovod" },
                    { (byte)13, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "mm",
                table: "LocalGovernmentUnits",
                columns: new[] { "local_government_unit_id", "local_government_unit_name" },
                values: new object[,]
                {
                    { (byte)1, "Općina" },
                    { (byte)2, "Grad" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "OBS_RBA_SPF_Conditions",
                columns: new[] { "obs_rba_spf_condition_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Potpuno funkcionalan/adaptiran" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Sa oštećenjima - postoji mogućnost korištenja" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ruiniran/devastiran - ne postoji mogućnost korištenja u postojećem stanju" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "OBS_RBA_SPF_EnergyClasses",
                columns: new[] { "obs_rba_spf_energy_class_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "A+" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "A" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "B" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "C" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "D" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "E" },
                    { (byte)7, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "F" },
                    { (byte)8, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "G" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "OBS_RBA_SPF_PropertyTypes",
                columns: new[] { "obs_rba_spf_property_type_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Zgrada" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Poslovni prostor" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Stan" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Garaža" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Javna zgrada - obdanište" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Pozorište" },
                    { (byte)7, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Biblioteka" },
                    { (byte)8, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Dom kulture" },
                    { (byte)9, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "OwnershipRightsAcquisitionLegalBases",
                columns: new[] { "ownership_rights_acquisition_legal_basis_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ugovor o zamjeni" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Kupoprodajni ugovor" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Nasljeđivanje" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Eksproprijacija" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "OwnershipTypes",
                columns: new[] { "ownership_type_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Isključivo vlasništvo" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Suvlasništvo" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Zajedničko" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Izvanknjižno" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PaymentFrequencies",
                columns: new[] { "payment_frequency_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Jednokratno" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Mjesečno" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Kvartalno" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Godišnje" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PossessionBases",
                columns: new[] { "possession_basis_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Svojina" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Pravo korištenja" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Posjed" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PropertyCategories",
                columns: new[] { "property_category_id", "code", "internal_name", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, "AL", "Agricultural land", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Poljoprivredno zemljište" },
                    { (byte)2, "BL", "Building land", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Građevinsko zemljište" },
                    { (byte)3, "OBS", "Office buildings/spaces", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Poslovne zgrade-prostori" },
                    { (byte)4, "RBA", "Residential buildings/apartments", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Stambene zgrade-stanovi" },
                    { (byte)5, "SPF", "Special purpose facilities", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Objekti posebne namjene" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PropertyStatuses",
                columns: new[] { "property_status_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "U upotrebi" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Slobodno za korištenje" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Slobodno za korištenje - potpuno funkcionalan" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Slobodan za korištenje - sa oštećenjima" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ruiniran/devastiran - ne postoji mogućnost korištenja u postojećm stanju" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PropertyUseBases",
                columns: new[] { "property_use_basis_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Zakup" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Podzakup" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Koncesija" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Prodaja" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PropertyUseBasisDocuments",
                columns: new[] { "property_use_basis_document_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ugovor" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Odluka" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PropertyUserGenders",
                columns: new[] { "property_user_gender_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Ženski" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Muški" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "PropertyUserTypes",
                columns: new[] { "property_user_type_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Poslovni subjekt" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Udruženje" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Obrt/Preduzetnik" },
                    { (byte)4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Zadruga" },
                    { (byte)5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Fizičko lice" },
                    { (byte)6, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "RestrictedRealRightInformation",
                columns: new[] { "restricted_real_right_information_id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "value" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Zalog" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Služnost" },
                    { (byte)3, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Drugo" }
                });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "SPF_PropertyTypes",
                columns: new[] { "id", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "title" },
                values: new object[,]
                {
                    { (byte)1, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Zgrada - Cjelina" },
                    { (byte)2, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null, "Dio nekretnine - Prostor" }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroups",
                columns: new[] { "user_group_id", "name", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date" },
                values: new object[,]
                {
                    { (short)1, "System Administrator", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1160), null, null },
                    { (short)2, "LGU Administrator", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1239), null, null },
                    { (short)3, "LGU User", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1242), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "Users",
                columns: new[] { "user_id", "email_code", "email_enc", "first_name_enc", "is_directory_user", "language_id", "last_name_enc", "password_hash", "password_salt", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date", "user_name_enc", "valid_from", "valid_to" },
                values: new object[] { new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new Guid("8f1079ac-a492-4055-b664-6ba23a6f65b2"), "St6/v49lrqKXW5W7ytqLHA==", "vOIUBnFT5Y809QUJqH4AzQ==", false, 1, "vOIUBnFT5Y809QUJqH4AzQ==", "5367F0A6E0BFBA425D5584C4B8A0F8A872B4885C90783FD698060A483146D29DD352665D9A220DDDD5EEE2D82DDCB06C213AA36381CAEF4E6B5F00CE3843FD45", "gWnj99aObNTLFxxcohCDq1dAaFXu1J1gTpZCYEa7pcATr/xD48yzNcfG96c+WhcZBIkEa7rKpwzvaG2wsT3LqQ==", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1544), null, null, "1/ZVbp32LhD77H7MGNgKmw==", new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1545), new DateTime(2297, 10, 25, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1547) });

            migrationBuilder.InsertData(
                schema: "pmp",
                table: "Zones",
                columns: new[] { "id", "name", "retired", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date" },
                values: new object[,]
                {
                    { (byte)1, "Zona 1", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)2, "Zona 2", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)3, "Zona 3", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)4, "Zona 4", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)5, "Zona 5", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)6, "Zona 6", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)7, "Zona 7", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)8, "Zona 8", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)9, "Zona 9", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null },
                    { (byte)10, "Zona 10", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2169), null, null }
                });

            migrationBuilder.InsertData(
                schema: "mm",
                table: "Municipalities",
                columns: new[] { "municipality_id", "entity_id", "local_government_unit_id", "municipality_name", "retired", "slug", "sys_created_by_user_id", "sys_created_date", "sys_last_modified_by_user_id", "sys_last_modified_date" },
                values: new object[,]
                {
                    { 1, (byte)2, (byte)1, "Trebinje", true, "trebinje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1679), null, null },
                    { 2, (byte)2, (byte)1, "Bileća", true, "bileca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1683), null, null },
                    { 3, (byte)2, (byte)1, "Ljubinje", true, "ljubinje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1685), null, null },
                    { 4, (byte)2, (byte)1, "Berkovići", true, "berkovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1688), null, null },
                    { 5, (byte)2, (byte)1, "Gacko", true, "gacko", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1691), null, null },
                    { 6, (byte)2, (byte)1, "Nevesinje", true, "nevesinje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1693), null, null },
                    { 7, (byte)2, (byte)1, "Istočni Mostar", true, "istocni-mostar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1695), null, null },
                    { 8, (byte)2, (byte)1, "Foča", true, "foca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1698), null, null },
                    { 9, (byte)2, (byte)1, "Čajniče", true, "cajnice", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1701), null, null },
                    { 10, (byte)2, (byte)1, "Milići", true, "milici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1703), null, null },
                    { 11, (byte)2, (byte)1, "Srebrenica", true, "srebrenica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1707), null, null },
                    { 12, (byte)2, (byte)1, "Bratunac", true, "bratunac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1709), null, null },
                    { 13, (byte)2, (byte)1, "Vlasenica", true, "vlasenica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1712), null, null },
                    { 14, (byte)2, (byte)1, "Šekovići", true, "sekovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1714), null, null },
                    { 15, (byte)2, (byte)1, "Osmaci", true, "osmaci", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1717), null, null },
                    { 16, (byte)2, (byte)1, "Zvornik", true, "zvornik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1722), null, null },
                    { 17, (byte)2, (byte)1, "Lopare", false, "lopare", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1725), null, null },
                    { 18, (byte)2, (byte)1, "Ugljevik", true, "ugljevik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1728), null, null },
                    { 19, (byte)2, (byte)1, "Bijeljina", true, "bijeljina", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1731), null, null },
                    { 20, (byte)2, (byte)1, "Srbac", true, "srbac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1735), null, null },
                    { 21, (byte)2, (byte)1, "Prnjavor", true, "prnjavor", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1739), null, null },
                    { 22, (byte)2, (byte)1, "Laktaši", true, "laktasi", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1742), null, null },
                    { 23, (byte)2, (byte)1, "Teslić", false, "teslic", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1746), null, null },
                    { 24, (byte)2, (byte)1, "Čelinac", true, "celinac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1750), null, null },
                    { 25, (byte)2, (byte)1, "Kotor Varoš", true, "kotor-varos", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1754), null, null },
                    { 26, (byte)2, (byte)1, "Kneževo", true, "knezevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1757), null, null },
                    { 27, (byte)2, (byte)1, "Kupres", true, "kupres-rs", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1761), null, null },
                    { 28, (byte)2, (byte)1, "Šipovo", true, "sipovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1764), null, null },
                    { 29, (byte)2, (byte)1, "Jezero", true, "jezero", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1768), null, null },
                    { 30, (byte)2, (byte)1, "Mrkonjić Grad", true, "mrkonjic-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1772), null, null },
                    { 31, (byte)2, (byte)1, "Istočni Drvar", true, "istocni-drvar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1776), null, null },
                    { 32, (byte)2, (byte)1, "Petrovac", true, "petrovac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1780), null, null },
                    { 33, (byte)2, (byte)1, "Ribnik", true, "ribnik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1785), null, null },
                    { 34, (byte)2, (byte)1, "Banja Luka", true, "banja-luka", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1789), null, null },
                    { 35, (byte)2, (byte)1, "Gradiška", true, "gradiska", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1793), null, null },
                    { 36, (byte)2, (byte)1, "Kozarska Dubica", true, "kozarska-dubica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1797), null, null },
                    { 37, (byte)2, (byte)1, "Kostajnica", true, "kostajnica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1801), null, null },
                    { 38, (byte)2, (byte)1, "Krupa na Uni", true, "krupa-na-uni", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1804), null, null },
                    { 39, (byte)2, (byte)1, "Novi Grad", true, "novi-grad-rs", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1808), null, null },
                    { 40, (byte)2, (byte)1, "Prijedor", true, "prijedor", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1812), null, null },
                    { 41, (byte)2, (byte)1, "Oštra Luka", true, "ostra-luka", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1816), null, null },
                    { 42, (byte)2, (byte)1, "Kalinovik", true, "kalinovik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1819), null, null },
                    { 43, (byte)2, (byte)1, "Ustiprača", true, "ustipraca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1822), null, null },
                    { 44, (byte)2, (byte)1, "Istočna Ilidža", true, "istocna-ilidza", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1825), null, null },
                    { 45, (byte)2, (byte)1, "Istočno Novo Sarajevo", true, "istocno-novo-sarajevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1829), null, null },
                    { 46, (byte)2, (byte)1, "Trnovo", true, "trnovo-rs", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1832), null, null },
                    { 47, (byte)2, (byte)1, "Pale", true, "pale", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1837), null, null },
                    { 48, (byte)2, (byte)1, "Rogatica", true, "rogatica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1840), null, null },
                    { 49, (byte)2, (byte)1, "Istočni Stari Grad", true, "istocni-stari-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1844), null, null },
                    { 50, (byte)2, (byte)1, "Sokolac", true, "sokolac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1847), null, null },
                    { 51, (byte)2, (byte)1, "Han Pijesak", true, "han-pijesak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1851), null, null },
                    { 52, (byte)2, (byte)1, "Rudo", true, "rudo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1854), null, null },
                    { 53, (byte)2, (byte)1, "Višegrad", true, "visegrad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1858), null, null },
                    { 54, (byte)2, (byte)1, "Šamac", false, "samac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1862), null, null },
                    { 55, (byte)2, (byte)1, "Petrovo", true, "petrovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1866), null, null },
                    { 56, (byte)2, (byte)1, "Doboj", true, "doboj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1870), null, null },
                    { 57, (byte)2, (byte)1, "Brod", true, "brod", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1875), null, null },
                    { 58, (byte)2, (byte)1, "Derventa", true, "derventa", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1891), null, null },
                    { 59, (byte)2, (byte)1, "Pelagićevo", true, "pelagicevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1896), null, null },
                    { 60, (byte)2, (byte)1, "Donji Žabar", true, "donji-zabar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1900), null, null },
                    { 61, (byte)2, (byte)1, "Vukosavlje", true, "vukosavlje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1904), null, null },
                    { 62, (byte)2, (byte)1, "Modriča", true, "modrica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1908), null, null },
                    { 63, (byte)1, (byte)1, "Foča-Ustikolina", true, "foca-ustikolina", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1911), null, null },
                    { 64, (byte)1, (byte)1, "Goražde", true, "gorazde", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1915), null, null },
                    { 65, (byte)1, (byte)1, "Pale-Prača", true, "pale-praca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1919), null, null },
                    { 66, (byte)1, (byte)1, "Stari Grad Sarajevo", true, "stari-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1923), null, null },
                    { 67, (byte)1, (byte)1, "Centar Sarajevo", true, "centar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1927), null, null },
                    { 68, (byte)1, (byte)1, "Novo Sarajevo", true, "novo-sarajevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1930), null, null },
                    { 69, (byte)1, (byte)1, "Novi Grad Sarajevo", true, "novi-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1935), null, null },
                    { 70, (byte)1, (byte)1, "Trnovo", true, "trnovo-fbih", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1943), null, null },
                    { 71, (byte)1, (byte)1, "Ilijaš", true, "ilijas", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1947), null, null },
                    { 72, (byte)1, (byte)1, "Hadžići", true, "hadzici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1949), null, null },
                    { 73, (byte)1, (byte)1, "Ilidža", true, "ilidza", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1952), null, null },
                    { 74, (byte)1, (byte)1, "Vogošća", true, "vogosca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1954), null, null },
                    { 75, (byte)1, (byte)1, "Gornji Vakuf-Uskoplje", true, "gornji-vakuf-uskoplje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1957), null, null },
                    { 76, (byte)1, (byte)1, "Fojnica", true, "fojnica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1960), null, null },
                    { 77, (byte)1, (byte)1, "Kreševo", true, "kresevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1962), null, null },
                    { 78, (byte)1, (byte)1, "Kiseljak", true, "kiseljak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1964), null, null },
                    { 79, (byte)1, (byte)1, "Busovača", true, "busovaca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1967), null, null },
                    { 80, (byte)1, (byte)1, "Vitez", true, "vitez", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1969), null, null },
                    { 81, (byte)1, (byte)1, "Novi Travnik", true, "novi-travnik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1971), null, null },
                    { 82, (byte)1, (byte)1, "Bugojno", true, "bugojno", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1974), null, null },
                    { 83, (byte)1, (byte)1, "Donji Vakuf", true, "donji-vakuf", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1976), null, null },
                    { 84, (byte)1, (byte)1, "Jajce", true, "jajce", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1978), null, null },
                    { 85, (byte)1, (byte)1, "Dobretići", true, "dobretici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1981), null, null },
                    { 86, (byte)1, (byte)1, "Travnik", true, "travnik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1983), null, null },
                    { 87, (byte)1, (byte)1, "Breza", true, "breza", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1985), null, null },
                    { 88, (byte)1, (byte)1, "Olovo", true, "olovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1988), null, null },
                    { 89, (byte)1, (byte)1, "Vareš", false, "vares", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1990), null, null },
                    { 90, (byte)1, (byte)1, "Visoko", true, "visoko", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1993), null, null },
                    { 91, (byte)1, (byte)1, "Kakanj", true, "kakanj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1995), null, null },
                    { 92, (byte)1, (byte)2, "Zenica", false, "zenica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1997), null, null },
                    { 93, (byte)1, (byte)2, "Zavidovići", false, "zavidovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(1999), null, null },
                    { 94, (byte)1, (byte)1, "Žepče", false, "zepce", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2002), null, null },
                    { 95, (byte)1, (byte)1, "Maglaj", true, "maglaj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2004), null, null },
                    { 96, (byte)1, (byte)1, "Tešanj", true, "tesanj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2007), null, null },
                    { 97, (byte)1, (byte)1, "Doboj-Jug", true, "doboj-jug", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2009), null, null },
                    { 98, (byte)1, (byte)1, "Usora", true, "usora", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2011), null, null },
                    { 99, (byte)1, (byte)1, "Ljubuški", true, "ljubuski", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2013), null, null },
                    { 100, (byte)1, (byte)1, "Grude", true, "grude", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2016), null, null },
                    { 101, (byte)1, (byte)1, "Široki Brijeg", true, "siroki-brijeg", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2018), null, null },
                    { 102, (byte)1, (byte)1, "Posušje", true, "posusje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2020), null, null },
                    { 103, (byte)1, (byte)1, "Neum", true, "neum", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2023), null, null },
                    { 104, (byte)1, (byte)1, "Ravno", true, "ravno", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2025), null, null },
                    { 105, (byte)1, (byte)1, "Stolac", true, "stolac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2027), null, null },
                    { 106, (byte)1, (byte)1, "Mostar", true, "mostar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2030), null, null },
                    { 107, (byte)1, (byte)1, "Konjic", true, "konjic", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2032), null, null },
                    { 108, (byte)1, (byte)1, "Čapljina", true, "capljina", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2034), null, null },
                    { 109, (byte)1, (byte)1, "Čitluk", true, "citluk", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2037), null, null },
                    { 110, (byte)1, (byte)1, "Jablanica", true, "jablanica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2039), null, null },
                    { 111, (byte)1, (byte)1, "Prozor-Rama", true, "prozor-rama", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2041), null, null },
                    { 112, (byte)1, (byte)1, "Tomislavgrad", true, "tomislavgrad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2044), null, null },
                    { 113, (byte)1, (byte)1, "Kupres", true, "kupres", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2046), null, null },
                    { 114, (byte)1, (byte)1, "Livno", true, "livno", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2055), null, null },
                    { 115, (byte)1, (byte)1, "Glamoč", true, "glamoc", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2058), null, null },
                    { 116, (byte)1, (byte)1, "Bosansko Grahovo", true, "bosansko-grahovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2060), null, null },
                    { 117, (byte)1, (byte)1, "Drvar", true, "drvar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2063), null, null },
                    { 118, (byte)1, (byte)1, "Kladanj", true, "kladanj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2065), null, null },
                    { 119, (byte)1, (byte)1, "Banovići", true, "banovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2067), null, null },
                    { 120, (byte)1, (byte)1, "Živinice", true, "zivinice", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2070), null, null },
                    { 121, (byte)1, (byte)1, "Lukavac", true, "lukavac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2073), null, null },
                    { 122, (byte)1, (byte)1, "Kalesija", true, "kalesija", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2075), null, null },
                    { 123, (byte)1, (byte)1, "Sapna", true, "sapna", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2078), null, null },
                    { 124, (byte)1, (byte)1, "Teočak", true, "teocak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2080), null, null },
                    { 125, (byte)1, (byte)2, "Tuzla", false, "tuzla", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2082), null, null },
                    { 126, (byte)1, (byte)1, "Čelić", true, "celic", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2085), null, null },
                    { 127, (byte)1, (byte)1, "Srebrenik", true, "srebrenik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2087), null, null },
                    { 128, (byte)1, (byte)1, "Doboj-Istok", true, "doboj-istok", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2089), null, null },
                    { 129, (byte)1, (byte)1, "Gračanica", true, "gracanica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2092), null, null },
                    { 130, (byte)1, (byte)2, "Gradačac", false, "gradacac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2094), null, null },
                    { 131, (byte)1, (byte)1, "Ključ", true, "kljuc", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2097), null, null },
                    { 132, (byte)1, (byte)1, "Sanski Most", true, "sanski-most", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2100), null, null },
                    { 133, (byte)1, (byte)1, "Bosanski Petrovac", true, "bosanski-petrovac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2102), null, null },
                    { 134, (byte)1, (byte)1, "Bihać", true, "bihac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2104), null, null },
                    { 135, (byte)1, (byte)1, "Cazin", true, "cazin", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2107), null, null },
                    { 136, (byte)1, (byte)1, "Bužim", true, "buzim", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2109), null, null },
                    { 137, (byte)1, (byte)1, "Bosanska Krupa", true, "bosanska-krupa", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2111), null, null },
                    { 138, (byte)1, (byte)1, "Velika Kladuša", true, "velika-kladusa", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2114), null, null },
                    { 139, (byte)1, (byte)1, "Orašje", true, "orasje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2116), null, null },
                    { 140, (byte)1, (byte)1, "Odžak", true, "odzak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2118), null, null },
                    { 141, (byte)1, (byte)1, "Domaljevac-Šamac", true, "domaljevac-samac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2120), null, null },
                    { 142, (byte)1, (byte)1, "Brčko", true, "brcko", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 10, 16, 5, 16, 318, DateTimeKind.Local).AddTicks(2123), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserActionRel",
                columns: new[] { "user_and_action_id", "action_id", "retired", "user_id" },
                values: new object[,]
                {
                    { 1, 5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f") },
                    { 2, 4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f") }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroupActionRel",
                columns: new[] { "user_group_and_action_id", "action_id", "retired", "user_group_id" },
                values: new object[,]
                {
                    { 1, 1, false, (short)1 },
                    { 2, 2, false, (short)1 },
                    { 3, 3, false, (short)1 },
                    { 4, 4, false, (short)1 },
                    { 5, 5, false, (short)1 }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroupUserRel",
                columns: new[] { "user_and_group_id", "retired", "user_group_id", "user_id" },
                values: new object[] { 1, false, (short)1, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f") });

            migrationBuilder.CreateIndex(
                name: "ix_actions_action_enumeration_name",
                schema: "dbo",
                table: "Actions",
                column: "action_enumeration_name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_actions_action_name",
                schema: "dbo",
                table: "Actions",
                column: "action_name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_attached_files_property_id",
                schema: "dbo",
                table: "AttachedFiles",
                column: "property_id");

            migrationBuilder.CreateIndex(
                name: "ix_attached_files_property_lease_data_id",
                schema: "dbo",
                table: "AttachedFiles",
                column: "property_lease_data_id");

            migrationBuilder.CreateIndex(
                name: "ix_municipalities_entity_id",
                schema: "mm",
                table: "Municipalities",
                column: "entity_id");

            migrationBuilder.CreateIndex(
                name: "ix_municipalities_local_government_unit_id",
                schema: "mm",
                table: "Municipalities",
                column: "local_government_unit_id");

            migrationBuilder.CreateIndex(
                name: "ix_municipalities_slug",
                schema: "mm",
                table: "Municipalities",
                column: "slug",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_properties_al_credit_rating_category_id",
                schema: "pmp",
                table: "Properties",
                column: "al_credit_rating_category_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_al_land_type_id",
                schema: "pmp",
                table: "Properties",
                column: "al_land_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_bl_construction_rights_basis_id",
                schema: "pmp",
                table: "Properties",
                column: "bl_construction_rights_basis_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_dispute_type_id",
                schema: "pmp",
                table: "Properties",
                column: "dispute_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_municipality_id",
                schema: "pmp",
                table: "Properties",
                column: "municipality_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_obs_rba_spf_condition_id",
                schema: "pmp",
                table: "Properties",
                column: "obs_rba_spf_condition_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_obs_rba_spf_energy_class_id",
                schema: "pmp",
                table: "Properties",
                column: "obs_rba_spf_energy_class_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_obs_rba_spf_property_type_id",
                schema: "pmp",
                table: "Properties",
                column: "obs_rba_spf_property_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_ownership_rights_acquisition_legal_basis_id",
                schema: "pmp",
                table: "Properties",
                column: "ownership_rights_acquisition_legal_basis_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_ownership_type_id",
                schema: "pmp",
                table: "Properties",
                column: "ownership_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_possession_basis_id",
                schema: "pmp",
                table: "Properties",
                column: "possession_basis_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_property_category_id",
                schema: "pmp",
                table: "Properties",
                column: "property_category_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_restricted_real_right_information_id",
                schema: "pmp",
                table: "Properties",
                column: "restricted_real_right_information_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_spf_property_type_id",
                schema: "pmp",
                table: "Properties",
                column: "spf_property_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_properties_zone_id",
                schema: "pmp",
                table: "Properties",
                column: "zone_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_installed_infrastructure_rel_installed_infrastructure",
                schema: "pmp",
                table: "PropertyInstalledInfrastructureRel",
                column: "installed_infrastructure_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_installed_infrastructure_rel_property_id",
                schema: "pmp",
                table: "PropertyInstalledInfrastructureRel",
                column: "property_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_contract_type_based_on_user_status_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "contract_type_based_on_user_status_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_contract_type_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "contract_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_payment_frequency_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "payment_frequency_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_property_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "property_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_property_status_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "property_status_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_property_use_basis_document_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "property_use_basis_document_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_property_use_basis_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "property_use_basis_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_property_user_gender_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "property_user_gender_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_lease_data_property_user_type_id",
                schema: "pmp",
                table: "PropertyLeaseData",
                column: "property_user_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_property_values_property_id",
                schema: "pmp",
                table: "PropertyValues",
                column: "property_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_action_rel_action_id",
                schema: "dbo",
                table: "UserActionRel",
                column: "action_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_action_rel_user_id",
                schema: "dbo",
                table: "UserActionRel",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_group_action_rel_action_id",
                schema: "dbo",
                table: "UserGroupActionRel",
                column: "action_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_group_action_rel_user_group_id",
                schema: "dbo",
                table: "UserGroupActionRel",
                column: "user_group_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_group_user_rel_user_group_id",
                schema: "dbo",
                table: "UserGroupUserRel",
                column: "user_group_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_group_user_rel_user_id",
                schema: "dbo",
                table: "UserGroupUserRel",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_municipality_rel_municipality_id",
                schema: "mm",
                table: "UserMunicipalityRel",
                column: "municipality_id");

            migrationBuilder.CreateIndex(
                name: "ix_user_municipality_rel_user_id",
                schema: "mm",
                table: "UserMunicipalityRel",
                column: "user_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ActionsHistory",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "AttachedFiles",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "AuditLogEnumerations",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "AuditLogs",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "EmailNotifications",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "get_user_actions");

            migrationBuilder.DropTable(
                name: "PropertyInstalledInfrastructureRel",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyValues",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "UserActionRel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserGroupActionRel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserGroupUserRel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserMunicipalityRel",
                schema: "mm");

            migrationBuilder.DropTable(
                name: "PropertyLeaseData",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "InstalledInfrastructure",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "Actions",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserGroups",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Users",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ContractTypesBasedOnUserStatus",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "ContractTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PaymentFrequencies",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "Properties",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyStatuses",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyUseBases",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyUseBasisDocuments",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyUserGenders",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyUserTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "AL_CreditRatingCategories",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "AL_LandTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "BL_ConstructionRightsBases",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "DisputeTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "Municipalities",
                schema: "mm");

            migrationBuilder.DropTable(
                name: "OBS_RBA_SPF_Conditions",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "OBS_RBA_SPF_EnergyClasses",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "OBS_RBA_SPF_PropertyTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "OwnershipRightsAcquisitionLegalBases",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "OwnershipTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PossessionBases",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "PropertyCategories",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "RestrictedRealRightInformation",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "SPF_PropertyTypes",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "Zones",
                schema: "pmp");

            migrationBuilder.DropTable(
                name: "Entities",
                schema: "mm");

            migrationBuilder.DropTable(
                name: "LocalGovernmentUnits",
                schema: "mm");
        }
    }
}
