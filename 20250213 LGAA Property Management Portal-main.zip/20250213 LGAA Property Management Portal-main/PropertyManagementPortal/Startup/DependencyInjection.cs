﻿using Domain.Contracts;
using FluentValidation;
using Infrastructure.Data.Repositories;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.DependencyInjection.Extensions;
using PropertyManagementPortal.Domain.Contracts.Admin;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Contracts.Utils;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Data.Repositories.Admin;
using PropertyManagementPortal.Infrastructure.Data.Repositories.App;
using PropertyManagementPortal.Infrastructure.Data.Repositories.Utils;
using PropertyManagementPortal.Infrastructure.Validators;

namespace PropertyManagementPortal.Startup
{
    public static class DependencyInjection
    {
        public static void RegisterRepositories(this IServiceCollection services)
        {
            //Admin
            services.AddScoped<IUserRepository, UserRepository>();

            //Utils
            services.AddScoped<IAuditLogEnumerationRepository, AuditLogEnumerationRepository>();
            services.AddScoped<IAuditLogRepository, AuditLogRepository>();
            services.AddScoped<IEmailNotificationRepository, EmailNotificationRepository>();
            services.AddScoped<IAttachmentRepository, AttachmentRepository>();
            services.AddScoped<IDropDownRepository, DropDownRepository>();
            services.AddScoped<IActionManagementRepository, ActionManagementRepository>();

            //HttpContext
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();

            //PFM
            services.AddScoped<IPMPDropDownRepository, PMPDropdownRepository>();
            services.AddScoped<IMunicipalityRepository, MunicipalityRepository>();
            services.AddScoped<IPropertyRepository, PropertyRepository>();
            services.AddScoped<IPropertyDDLRepository, PropertyDDLRepository>();
            services.AddScoped<IPropertyLeaseDataDDLRepository, PropertyLeaseDataDDLRepository>();
            services.AddScoped<IPropertyLeaseDataRepository, PropertyLeaseDataRepository>();
            services.AddScoped<IPropertyValueRepository, PropertyValueRepository>();
        }

        public static void RegisterValidators(this IServiceCollection services)
        {
            services.AddScoped<IValidator<UserDTO>, UserDTOValidator>();
        }
    }
}
