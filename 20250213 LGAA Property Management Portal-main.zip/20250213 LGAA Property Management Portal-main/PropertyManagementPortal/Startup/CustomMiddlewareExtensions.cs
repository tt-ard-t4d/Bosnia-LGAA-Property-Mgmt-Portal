﻿using DocumentFormat.OpenXml.Spreadsheet;
using PropertyManagementPortal.Infrastructure.Middleware;

namespace PropertyManagementPortal.Startup
{
    public static class CustomMiddlewareExtensions
    {
        public static IApplicationBuilder UseAntiXssMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<AntiXssMiddleware>();
        }

        public static IApplicationBuilder AddResponseHeaders(this IApplicationBuilder builder)
        {
            return builder.Use(async (context, next) =>
            {
                context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                context.Response.Headers.Add("Content-Security-Policy", "default-src * 'self' 'unsafe-inline' 'unsafe-eval' data: gap: content:; font-src 'self' ;");
                context.Response.Headers.Add("X-XSS-Protection", "1; mode=block ");

                await next.Invoke();
            });
        }
    }
}
