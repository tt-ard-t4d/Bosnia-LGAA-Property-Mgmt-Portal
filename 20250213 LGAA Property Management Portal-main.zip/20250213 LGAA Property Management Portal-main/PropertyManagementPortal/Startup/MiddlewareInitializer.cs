﻿using Microsoft.AspNetCore.Builder;
using PropertyManagementPortal.Infrastructure.Middleware;

namespace PropertyManagementPortal.Startup
{
    public static partial class MiddlewareInitializer
    {
        public static WebApplication ConfigureMiddleware(this WebApplication app)
        {
            if (!app.Environment.IsDevelopment())
            {
                //Strict-Transport-Security header
                app.UseHsts();
            }
            else
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v2/swagger.json", "Project Template");
                });
            }

            app.UseHttpsRedirection();
            //app.UseAntiXssMiddleware();
            app.AddResponseHeaders();
            app.UseSession();

            app.UseStaticFiles();
            app.UseRouting();
            app.Use((context, next) =>
            {
                context.Request.EnableBuffering();
                return next();
            });

            app.UseAuthentication();
            app.UseAuthorization();
            app.AddLocalization();
            app.RegisterEndpoints();

            return app;
        }
    }
}
