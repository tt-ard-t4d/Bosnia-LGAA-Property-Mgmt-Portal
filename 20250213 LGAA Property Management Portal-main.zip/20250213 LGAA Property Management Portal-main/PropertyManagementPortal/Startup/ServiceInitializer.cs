﻿using Azure.Storage.Blobs;
using Infrastructure.Core;
using Infrastructure.Data;
using Infrastructure.Settings.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using PropertyManagementPortal.Infrastructure.Core.Admin;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Core;
using Microsoft.AspNetCore.Authentication.Cookies;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Binders.Providers;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc.Razor;
using PropertyManagementPortal.Infrastructure.Core.PMP;

namespace PropertyManagementPortal.Startup
{
    public static partial class ServiceInitializer
    {
        public static IServiceCollection RegisterApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<DatabaseContext>(
                //opts => opts.UseSqlServer(configuration.GetConnectionString("DevConnection"))
                opts => opts.UseNpgsql(configuration.GetConnectionString("DevConnection"))
                            .UseSnakeCaseNamingConvention()
            );

            services.AddLocalization(options => options.ResourcesPath = "Infrastructure/Resources");
            services.ConfigureLocalization();

            services.AddIdentityCore<IdentityUser>()
            .AddEntityFrameworkStores<DatabaseContext>()
            .AddSignInManager<SignInManager<IdentityUser>>()
            .AddDefaultTokenProviders();


            services.AddAuthentication(AzureADDefaults.AuthenticationScheme)
               .AddAzureAD(options => configuration.Bind("AzureAd", options))
               .AddCookie(IdentityConstants.ExternalScheme, options =>
               {
                   options.Cookie.Name = IdentityConstants.ExternalScheme;
                   options.Cookie.HttpOnly = true;
                   options.Cookie.SameSite = SameSiteMode.Strict;
                   options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                   options.ExpireTimeSpan = TimeSpan.FromMinutes(5);
               });


            services.AddAuthentication(IdentityConstants.ExternalScheme)
            .AddCookie("Identity.Application", options =>
            {
                options.Cookie.Name = IdentityConstants.ExternalScheme;
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.LoginPath = "/Account/Login";
            });

            services.AddAuthentication(IdentityConstants.TwoFactorUserIdScheme)
            .AddCookie(IdentityConstants.TwoFactorUserIdScheme, options =>
            {
                options.Cookie.Name = IdentityConstants.TwoFactorUserIdScheme;
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.ExpireTimeSpan = TimeSpan.FromMinutes(5);
            });

            services.Configure<OpenIdConnectOptions>(AzureADDefaults.OpenIdScheme, options =>
            {
                options.Authority = options.Authority + "/v2.0/";
                options.TokenValidationParameters.ValidateIssuer = false;
                options.SignInScheme = IdentityConstants.ExternalScheme;
            });

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(20);
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            });

            //Strict-Transport-Security header
            services.AddHsts(options =>
            {
                options.Preload = true;
                options.IncludeSubDomains = true;
                options.MaxAge = TimeSpan.FromDays(365);
            });

            // cookie auth.
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(option =>
            {
                option.LoginPath = "/login/login";
                option.AccessDeniedPath = "/login/denied";
                option.Cookie.HttpOnly = true;
                option.Cookie.SameSite = SameSiteMode.Strict;
            });

            services.AddMvc(options =>
            {
                //Add automatic antiforgery token validation for every request excluding GET, HEAD, OPTIONS, and TRACE
                options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
                //String model binder for input sanitizing
                options.ModelBinderProviders.Insert(0, new StringModelBinderProvider());
                //DateTime model binder for dates from query string
                options.ModelBinderProviders.Insert(1, new DateTimeModelBinderProvider());
            })
            .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
            .AddDataAnnotationsLocalization();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v2", new OpenApiInfo { Title = "ProjectTemplate", Version = "v1.0" });
            });

            RegisterCustomDependencies(services, configuration);

            ConfigurationHelper.Initialize(configuration);

            return services;
        }

        private static void RegisterCustomDependencies(IServiceCollection services, IConfiguration configuration)
        {
            //Register repositories before adding services
            services.RegisterRepositories();

            services.AddTransient<UserService>();
            services.AddTransient<AuditLogService>();
            services.AddTransient<EmailService>();
            services.AddTransient<AttachmentService>();
            services.AddTransient<LoginService>();
            services.AddTransient<DropDownService>();
            services.AddTransient<ActionManagementService>();
            services.AddTransient<LoginImpersonateService>();
            services.AddTransient<ReportingService>();
            services.AddTransient<FileManagementService>();
            services.AddTransient<SessionService>();

            //PMP
            services.AddTransient<PMPDropDownService>();
            services.AddTransient<MunicipalityService>();
            services.AddTransient<PropertyDDLService>();
            services.AddTransient<PropertyService>();
            services.AddTransient<PropertyReportService>();
            services.AddTransient<PropertyLeaseDataDDLService>();
            services.AddTransient<PropertyLeaseDataService>();
            services.AddTransient<PropertyValueService>();
            services.AddTransient<PropertyLeaseDataReportService>();

            services.AddHttpClient();
            // BLOB
            services.AddScoped(_ => new BlobServiceClient(configuration.GetConnectionString("AzureBlobStorage")));

            services.Configure<MailSettings>(configuration.GetSection("MailSettings"));
        }
    }
}
