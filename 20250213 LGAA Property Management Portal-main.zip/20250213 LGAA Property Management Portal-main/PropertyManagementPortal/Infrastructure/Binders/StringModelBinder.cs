﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using PropertyManagementPortal.Infrastructure.Helpers;

namespace PropertyManagementPortal.Infrastructure.Binders
{
    public class StringModelBinder : IModelBinder
    {
        public Task BindModelAsync(ModelBindingContext bindingContext)
        {
            ValueProviderResult values = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);
            if (values.Length == 0) return Task.CompletedTask;

            string? stringValue = values.FirstValue;

            try
            {
                if (string.IsNullOrEmpty(stringValue)) return Task.CompletedTask;

                var sanitizedValue = UtilsHelper.GetSafeInput(stringValue);

                bindingContext.ModelState.SetModelValue(bindingContext.ModelName, stringValue, sanitizedValue);
                bindingContext.Result = ModelBindingResult.Success(sanitizedValue);
            }
            catch (FormatException ex)
            {
                bindingContext.ModelState.AddModelError("Format error", ex.Message);
            }

            return Task.CompletedTask;
        }
    }
}
