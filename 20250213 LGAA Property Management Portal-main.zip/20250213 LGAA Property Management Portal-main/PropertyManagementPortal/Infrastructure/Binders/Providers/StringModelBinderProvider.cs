﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace PropertyManagementPortal.Infrastructure.Binders.Providers
{
    public class StringModelBinderProvider : IModelBinderProvider
    {
        public IModelBinder? GetBinder(ModelBinderProviderContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            var dataType = context.Metadata.ModelType;
            return dataType == typeof(string) ? new StringModelBinder() : null;
        }
    }
}
