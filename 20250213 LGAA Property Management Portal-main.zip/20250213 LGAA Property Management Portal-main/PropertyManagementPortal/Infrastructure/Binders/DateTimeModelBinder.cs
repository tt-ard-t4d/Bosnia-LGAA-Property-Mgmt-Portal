﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Globalization;

namespace PropertyManagementPortal.Infrastructure.Binders
{
    public class DateTimeModelBinder : IModelBinder
    {
        private readonly DateTimeStyles _supportedStyles;

        public DateTimeModelBinder(DateTimeStyles supportedStyles)
        {
            _supportedStyles = supportedStyles;
        }

        public Task BindModelAsync(ModelBindingContext bindingContext)
        {
            if (bindingContext == null)
            {
                throw new ArgumentNullException(nameof(bindingContext));
            }

            var modelName = bindingContext.ModelName;
            var valueProviderResult = bindingContext.ValueProvider.GetValue(modelName);
            if (valueProviderResult == ValueProviderResult.None)
            {
                return Task.CompletedTask;
            }

            var modelState = bindingContext.ModelState;
            modelState.SetModelValue(modelName, valueProviderResult);

            var metadata = bindingContext.ModelMetadata;
            var type = metadata.UnderlyingOrModelType;
            var value = valueProviderResult.FirstValue;
            var culture = CultureInfo.CurrentCulture;

            DateTime? model = null;

            if (type == typeof(DateTime) && !string.IsNullOrEmpty(value))
            {
                try
                {
                    model = DateTime.Parse(value, culture, _supportedStyles);
                }
                catch (Exception ex)
                {
                    modelState.TryAddModelError(modelName, ex.Message);
                    return Task.CompletedTask;
                }
            }

            if (model == null && !metadata.IsReferenceOrNullableType)
            {
                modelState.TryAddModelError(modelName, metadata.ModelBindingMessageProvider.ValueMustNotBeNullAccessor(valueProviderResult.ToString()));
            }
            else
            {
                bindingContext.Result = ModelBindingResult.Success(model);
            }

            return Task.CompletedTask;
        }
    }
}
