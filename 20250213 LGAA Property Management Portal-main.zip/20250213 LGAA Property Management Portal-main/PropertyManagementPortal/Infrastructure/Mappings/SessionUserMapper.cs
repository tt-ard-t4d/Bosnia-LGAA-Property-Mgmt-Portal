﻿using Infrastructure.Helpers;
using Infrastructure.Models;
using Microsoft.IdentityModel.Abstractions;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Mappings
{
    public class SessionUserMapper
    {
        public UserData Map(User? model, List<UserDataAction> userActions, IConfiguration configuration)
        {
            if (model == null)
            {
                return new UserData();
            }

            return new UserData()
            {
                UserID = model.UserID,
                UserName = SEDManager.Unprotect(model.UserNameEnc, configuration),
                FirstName = SEDManager.Unprotect(model.FirstNameEnc, configuration),
                LastName = SEDManager.Unprotect(model.LastNameEnc, configuration),
                Email = SEDManager.Unprotect(model.EmailEnc, configuration),
                UserGroups = model.UserGroupUsers
                    .Where(r => r.Retired == false)
                    .Select(r => new UserDataGroup { UserGroupID = r.UserGroupID, UserGroupName = r.UserGroup.Name })
                    .ToList(),
                UserActions = userActions
            };
        }
    }
}
