﻿using Infrastructure.Helpers;
using Microsoft.Data.SqlClient.DataClassification;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Mappings.PMP
{
    public class PropertyLeaseDataMapper
    {
        public PropertyLeaseDataDTO Map(PropertyLeaseData? entity)
        {
            if (entity == null) return new PropertyLeaseDataDTO();

            return new PropertyLeaseDataDTO()
            {
                PropertyLeaseDataID = entity.PropertyLeaseDataID,
                PropertyID = entity.PropertyID,
                PropertyStatusID = entity.PropertyStatusID,
                PropertyUserName = entity.PropertyUserName,
                ContractNumber = entity.ContractNumber,
                ContractConclusionDate = entity.ContractConclusionDate,
                ContractDurationInMonths = entity.ContractDurationInMonths,
                PaymentFrequencyID = entity.PaymentFrequencyID,
                OtherContractualObligations = entity.OtherContractualObligations,
                PropertyUseBasisDocumentID = entity.PropertyUseBasisDocumentID,
                PropertyUseBasisID = entity.PropertyUseBasisID,
                PropertyUserGenderID = entity.PropertyUserGenderID,
                PropertyUserTypeID = entity.PropertyUserTypeID,
                ContractedValue = entity.ContractedValue,
                ContractTypeBasedOnUserStatusID = entity.ContractTypeBasedOnUserStatusID,
                ContractTypeID = entity.ContractTypeID,
                PropertyUserTypeOther = entity.PropertyUserTypeOther,
                SysCreatedByUserID = entity.SysCreatedByUserID,
                OldAttachments = entity.Attachments.Select(r => r.AzureFileID.ToString()).ToList()
            };
        }

        public PropertyLeaseData Map(PropertyLeaseDataDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new PropertyLeaseData()
            {
                PropertyLeaseDataID = model.PropertyLeaseDataID,
                PropertyID = model.PropertyID,
                PropertyStatusID = model.PropertyStatusID,
                PropertyUserName = model.PropertyUserName,
                ContractNumber = model.ContractNumber,
                ContractConclusionDate = model.ContractConclusionDate,
                ContractDurationInMonths = model.ContractDurationInMonths,
                PaymentFrequencyID = model.PaymentFrequencyID,
                OtherContractualObligations = model.OtherContractualObligations,
                PropertyUseBasisDocumentID = model.PropertyUseBasisDocumentID,
                PropertyUseBasisID = model.PropertyUseBasisID,
                PropertyUserGenderID = model.PropertyUserGenderID,
                PropertyUserTypeID = model.PropertyUserTypeID,
                ContractedValue = model.ContractedValue,
                ContractTypeBasedOnUserStatusID = model.ContractTypeBasedOnUserStatusID,
                ContractTypeID = model.ContractTypeID,
                PropertyUserTypeOther = model.PropertyUserTypeOther
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }

        public PropertyLeaseDataGridDTO MapGrid(PropertyLeaseData? entity)
        {
            if (entity == null) return new PropertyLeaseDataGridDTO();

            return new PropertyLeaseDataGridDTO()
            {
                PropertyLeaseDataID = entity.PropertyLeaseDataID,
                PropertyStatusID = entity.PropertyStatusID,
                PropertyStatus = entity.PropertyStatus.Value,
                DateCreated = entity.SysCreatedDate.ToShortDateString(),
                PropertyUseBasisDocument = entity.PropertyUseBasisDocument?.Value,
                PropertyUseBasis = entity.PropertyUseBasis?.Value,
                PropertyUserName = entity.PropertyUserName,
                PropertyUserGender = entity.PropertyUserGender?.Value,
                PropertyUserType = entity.PropertyUserType?.Value,
                ContractNumber = entity.ContractNumber,
                ContractConclusionDate = entity.ContractConclusionDate?.ToShortDateString(),
                ContractType = entity.ContractType?.Value,
                ContractDurationInMonths = entity.ContractDurationInMonths,
                ContractedValue = entity.ContractedValue,
                PaymentFrequency = entity.PaymentFrequency?.Value ?? string.Empty,
                ContractTypeBasedOnUserStatus = entity.ContractTypeBasedOnUserStatus?.Value,
                OtherContractualObligations = entity.OtherContractualObligations,
                PropertyUserTypeOther = entity.PropertyUserTypeOther,
                Attachments = entity.Attachments.Select(r => new AttachmentShowDTO() { Link = r.Link, Name = r.Title }).ToList()
            };
        }

        public ReportLeaseDataDTO MapReport(PropertyLeaseData entity)
        {
            return new ReportLeaseDataDTO
            {
                PropertyLeaseDataId = entity.PropertyLeaseDataID.ToString(),
                PropertyStatus = entity.PropertyStatus.Value,
                PropertyUserName = entity.PropertyUserName.Label(),
                ContractNumber = entity.ContractNumber.Label(),
                ContractConclusionDate = (entity.ContractConclusionDate?.ToShortDateString() ?? LabelsRes.NoData).Label(),
                ContractDurationInMonths = entity.ContractDurationInMonths.ToString().Label(),
                PaymentFrequency = entity.PaymentFrequency?.Value.Label() ?? LabelsRes.NoData,
                OtherContractualObligations = entity.OtherContractualObligations.Label(),
                PropertyUseBasisDocument = entity.PropertyUseBasisDocument?.Value.Label() ?? LabelsRes.NoData,
                PropertyUseBasis = entity.PropertyUseBasis?.Value.Label() ?? LabelsRes.NoData,
                PropertyUserGender = entity.PropertyUserGender?.Value.Label() ?? LabelsRes.NoData,
                PropertyUserType = entity.PropertyUserType?.Value.Label() ?? LabelsRes.NoData,
                ContractedValue = entity.ContractedValue.ToString().Label(),
                ContractTypeBasedOnUserStatus = entity.ContractTypeBasedOnUserStatus?.Value.Label() ?? LabelsRes.NoData,
                ContractType = entity.ContractType?.Value.Label() ?? LabelsRes.NoData,
                PropertyUserTypeOther = entity.PropertyUserTypeOther.Label(),
            };
        }
    }
}
