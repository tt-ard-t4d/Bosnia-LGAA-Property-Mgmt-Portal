﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.PropertyValue;

namespace PropertyManagementPortal.Infrastructure.Mappings.PMP
{
    public class PropertyValueMapper
    {
        public PropertyValueDTO Map(PropertyValue? entity)
        {
            if (entity == null) return new PropertyValueDTO();

            return new PropertyValueDTO()
            {
                PropertyValueID = entity.PropertyValueID,
                PropertyID = entity.PropertyID,
                CurrentYearBookkeepingValue = entity.CurrentYearBookkeepingValue,
                CurrentYearBookkeepingValueComment = entity.CurrentYearBookkeepingValueComment,
                CurrentYearEstimatedMarketValue = entity.CurrentYearEstimatedMarketValue,
                CurrentYearEstimatedMarketValueComment = entity.CurrentYearEstimatedMarketValueComment,
                EstimatedMaintenanceCost = entity.EstimatedMaintenanceCost,
                EstimatedMaintenanceCostComment = entity.EstimatedMaintenanceCostComment
            };
        }

        public PropertyValue Map(PropertyValueDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new PropertyValue()
            {
                PropertyValueID = model.PropertyValueID,
                PropertyID = model.PropertyID,
                CurrentYearBookkeepingValue = model.CurrentYearBookkeepingValue,
                CurrentYearBookkeepingValueComment = model.CurrentYearBookkeepingValueComment,
                CurrentYearEstimatedMarketValue = model.CurrentYearEstimatedMarketValue,
                CurrentYearEstimatedMarketValueComment = model.CurrentYearEstimatedMarketValueComment,
                EstimatedMaintenanceCost = model.EstimatedMaintenanceCost,
                EstimatedMaintenanceCostComment = model.EstimatedMaintenanceCostComment
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }

        public PropertyValueGridDTO MapGrid(PropertyValue? entity)
        {
            if (entity == null) return new PropertyValueGridDTO();

            return new PropertyValueGridDTO()
            {
                PropertyValueID = entity.PropertyValueID,
                PropertyID = entity.PropertyID,
                CurrentYearBookkeepingValue = entity.CurrentYearBookkeepingValue,
                CurrentYearBookkeepingValueComment = entity.CurrentYearBookkeepingValueComment,
                CurrentYearEstimatedMarketValue = entity.CurrentYearEstimatedMarketValue,
                CurrentYearEstimatedMarketValueComment = entity.CurrentYearEstimatedMarketValueComment,
                EstimatedMaintenanceCost = entity.EstimatedMaintenanceCost,
                EstimatedMaintenanceCostComment = entity.EstimatedMaintenanceCostComment,
                AdditionalInformation = string.Empty,
                SysCreatedDate = entity.SysCreatedDate,
            };
        }
    }
}
