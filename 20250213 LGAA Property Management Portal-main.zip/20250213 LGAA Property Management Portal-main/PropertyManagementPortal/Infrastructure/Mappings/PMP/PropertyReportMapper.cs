﻿using AngleSharp.Dom;
using DocumentFormat.OpenXml.Vml.Office;
using Microsoft.IdentityModel.Tokens;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Property.Reports;
using PropertyManagementPortal.Infrastructure.Resources;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Mappings.PMP
{
    public class PropertyReportMapper
    {
        public AgriculturalPropertyLeaseReportDTO MapAgriculturalReport(Property r, IConfiguration configuration)
        {
            var lastStatus = r.PropertyLeaseData.OrderByDescending(r => r.SysCreatedDate).First() ?? null;
            return new AgriculturalPropertyLeaseReportDTO
            {
                Address = SEDManager.Unprotect(r.LocationAddress, configuration) ?? "-",
                KO = r.KO ?? "-",
                KP = r.KP ?? "-",
                ZK = string.IsNullOrEmpty(r.PropertyRegister) ? "-" : r.PropertyRegister,
                Zone = r.Zone != null ? r.Zone.Name : "-",
                PropertyPurposeType = r.AL_LandType != null ? r.AL_LandType.Value : "-",
                CreditRatingCategory = r.AL_CreditRatingCategory != null ? r.AL_CreditRatingCategory?.Value : "-",
                LandUseAccordingRegulatoryPlan = r.AL_BL_LandUseAccordingRegulatoryPlan == null ? "-" : SEDManager.Unprotect(r.AL_BL_LandUseAccordingRegulatoryPlan, configuration),
                PropertyUser = (string.IsNullOrEmpty(lastStatus?.PropertyUserName) ? "-" : lastStatus?.PropertyUserName)!,
                PropertyUserGender = lastStatus != null && lastStatus.PropertyUserGender != null ? lastStatus?.PropertyUserGender?.Value : "-",
                ContractDuration = lastStatus != null && lastStatus.ContractDurationInMonths != null ? lastStatus?.ContractDurationInMonths.ToString() : "-",
                ContractType = lastStatus != null && lastStatus.ContractType != null ? lastStatus?.ContractType?.Value : "-",
                PaymentFrequency = (lastStatus is { PaymentFrequency: not null } ? lastStatus?.PaymentFrequency.ToString() : "-")!,
                ContractPayment = (lastStatus is { ContractedValue: not null } ? lastStatus?.ContractedValue.ToString() : "-")!,
                Comment = r.Comment ?? "-",
            };
        }

        public BuildingLandLeaseReportDTO MapBuildingReport(Property r, IConfiguration configuration)
        {
            var lastStatus = r.PropertyLeaseData.OrderByDescending(r => r.SysCreatedDate).First() ?? null;
            return new BuildingLandLeaseReportDTO
            {
                Address = SEDManager.Unprotect(r.LocationAddress, configuration),
                KO = r.KO ?? "-",
                KP = r.KP ?? "-",
                ZK = string.IsNullOrEmpty(r.PropertyRegister) ? "-" : r.PropertyRegister,
                Zone = r.Zone != null ? r.Zone.Name : "-",
                LandUseAccordingRegulatoryPlan = r.AL_BL_LandUseAccordingRegulatoryPlan == null ? "-" : SEDManager.Unprotect(r.AL_BL_LandUseAccordingRegulatoryPlan, configuration),
                PropertyUser = (string.IsNullOrEmpty(lastStatus?.PropertyUserName) ? "-" : lastStatus?.PropertyUserName)!,
                PropertyUserGender = (lastStatus?.PropertyUserGender != null ? lastStatus?.PropertyUserGender?.Value : "-")!,
                ContractDuration = (lastStatus is { ContractDurationInMonths: not null } ? lastStatus?.ContractDurationInMonths.ToString() : "-")!,
                ContractType = (lastStatus is { ContractType: not null } ? lastStatus?.ContractType?.Value : "-")!,
                PaymentFrequency = (lastStatus is { PaymentFrequency: not null } ? lastStatus?.PaymentFrequency.ToString() : "-")!,
                ContractPayment = (lastStatus is { ContractedValue: not null } ? lastStatus?.ContractedValue.ToString() : "-")!,
                Comment = r.Comment ?? "-",
            };
        }

        public OfficeBuildingLeaseReportDTO MapOfficeBuildingReport(Property r, IConfiguration configuration)
        {
            var lastStatus = r.PropertyLeaseData.OrderByDescending(r => r.SysCreatedDate).First() ?? null;
            return new OfficeBuildingLeaseReportDTO
            {
                Address = SEDManager.Unprotect(r.LocationAddress, configuration),
                KO = r.KO ?? "-",
                KP = r.KP ?? "-",
                Zone = r.Zone != null ? r.Zone.Name : "-",
                ContractDuration = (lastStatus is { ContractDurationInMonths: not null } ? lastStatus?.ContractDurationInMonths.ToString() : "-")!,
                ContractType = (lastStatus is { ContractType: not null } ? lastStatus?.ContractType?.Value : "-")!,
                PaymentFrequency = (lastStatus is { PaymentFrequency: not null } ? lastStatus?.PaymentFrequency?.Value : "-")!,
                ContractPayment = (lastStatus is { ContractedValue: not null } ? lastStatus?.ContractedValue.ToString() : "-")!,
                Comment = r.Comment ?? "-",
            };
        }

        public ResidentialBuildingLandLeaseReportDTO MapResidentialBuildingReport(Property r, IConfiguration configuration)
        {
            var lastStatus = r.PropertyLeaseData.OrderByDescending(r => r.SysCreatedDate).First() ?? null;
            return new ResidentialBuildingLandLeaseReportDTO
            {
                Address = SEDManager.Unprotect(r.LocationAddress, configuration),
                KO = r.KO ?? "-",
                KP = r.KP ?? "-",
                Zone = r.Zone != null ? r.Zone.Name : "-",
                ContractDuration = (lastStatus is { ContractDurationInMonths: not null } ? lastStatus?.ContractDurationInMonths.ToString() : "-")!,
                ContractType = (lastStatus is { ContractType: not null } ? lastStatus?.ContractType?.Value : "-")!,
                PaymentFrequency = (lastStatus is { PaymentFrequency: not null } ? lastStatus?.PaymentFrequency?.Value : "-")!,
                ContractPayment = (lastStatus is { ContractedValue: not null } ? lastStatus?.ContractedValue.ToString() : "-")!,
                Comment = r.Comment ?? "-",
            };
        }

        public BuildingLandTradeReportDTO MapBuildingTradeReport(PropertyLeaseData status, IConfiguration configuration)
        {
            return new BuildingLandTradeReportDTO()
            {
                Address = SEDManager.Unprotect(status.Property.LocationAddress, configuration),
                KO = status.Property.KO ?? "-",
                KP = status.Property.KP ?? "-",
                ZK = status.Property.PropertyRegister ?? "-",
                Zone = status.Property.Zone?.Name ?? "-",
                ContractNumber = status.ContractNumber ?? "-",
                ContractValue = (string.IsNullOrEmpty(status.ContractedValue.ToString()) ? "-" : status.ContractedValue.ToString())!,
                Comment = string.IsNullOrEmpty(status.Property.Comment) ? "-" : status.Property.Comment
            };
        }

        public OfficeBuildingTradeReportDTO MapOfficeBuildingTradeReport(PropertyLeaseData status, IConfiguration configuration)
        {
            return new OfficeBuildingTradeReportDTO()
            {
                Address = SEDManager.Unprotect(status.Property.LocationAddress, configuration) ?? "-",
                KO = status.Property.KO ?? "-",
                KP = status.Property.KP ?? "-",
                Zone = status.Property.Zone != null ? status.Property.Zone.Name : "-",
                OBS_RBA_SPF_PropertyTypeID = status.Property.OBS_RBA_SPF_PropertyTypeID != null ? status.Property.OBS_RBA_SPF_PropertyType?.Value ?? "-" : "-", 
                OBS_RBA_SPF_UnitNumber = status.Property.OBS_RBA_SPF_UnitNumber.ToString() ?? "-",
                ZK = string.IsNullOrEmpty(status.Property.PropertyRegister) ? "-" : status.Property.PropertyRegister,
                ContractNumber = status.ContractNumber ?? "-",
                PropertyUser = (string.IsNullOrEmpty(status?.PropertyUserName) ? "-" : status?.PropertyUserName)!,
                ContractedValue = (status is { ContractedValue: not null } ? status?.ContractedValue.ToString() : "-")!,
                Comment = string.IsNullOrEmpty(status.Property.Comment) ? "-" : status.Property.Comment
            };
        }

        public ResidentialBuildingTradeReportDTO MapResidentialBuildingTradeReport(PropertyLeaseData status, IConfiguration configuration)
        {
            return new ResidentialBuildingTradeReportDTO()
            {
                Address = SEDManager.Unprotect(status.Property.LocationAddress, configuration) ?? "-",
                KO = status.Property.KO ?? "-",
                KP = status.Property.KP ?? "-",
                Zone = status.Property.Zone != null ? status.Property.Zone.Name : "-",
                OBS_RBA_SPF_PropertyTypeID = status.Property.OBS_RBA_SPF_PropertyTypeID != null ? status.Property.OBS_RBA_SPF_PropertyType?.Value ?? "-" : "-",
                OBS_RBA_SPF_UnitNumber = status.Property.OBS_RBA_SPF_UnitNumber.ToString() ?? "-",
                ZK = string.IsNullOrEmpty(status.Property.PropertyRegister) ? "-" : status.Property.PropertyRegister,
                ContractNumber = status.ContractNumber ?? "-",
                PropertyUser = (string.IsNullOrEmpty(status?.PropertyUserName) ? "-" : status?.PropertyUserName)!,
                ContractedValue = (status is { ContractedValue: not null } ? status?.ContractedValue.ToString() : "-")!,
                Comment = string.IsNullOrEmpty(status.Property.Comment) ? "-" : status.Property.Comment
            };
        }

        public ExpropriatedRealEstateTradeReportDTO MapExpropriatedRealEstateTradeReport(PropertyLeaseData status, IConfiguration configuration)
        {
            return new ExpropriatedRealEstateTradeReportDTO()
            {
                Address = SEDManager.Unprotect(status.Property.LocationAddress, configuration) ?? "-",
                KO = status.Property.KO ?? "-",
                Zone = status.Property.Zone != null ? status.Property.Zone.Name : "-",
                ZK = string.IsNullOrEmpty(status.Property.PropertyRegister) ? "-" : status.Property.PropertyRegister,
                Comment = string.IsNullOrEmpty(status.Property.Comment) ? "-" : status.Property.Comment
            };
        }

        public DisputedPropertyTradeReportDTO MapDisputedPropertyTradeReport(PropertyLeaseData status, IConfiguration configuration)
        {
            return new DisputedPropertyTradeReportDTO()
            {
                Address = SEDManager.Unprotect(status.Property.LocationAddress, configuration) ?? "-",
                KO = status.Property.KO ?? "-",
                KP = status.Property.KP ?? "-",
                Zone = status.Property.Zone != null ? status.Property.Zone.Name : "-",
                DisputeTypeID = status.Property.DisputeTypeID != null ? status.Property.DisputeType?.Value ?? "-" : "-",
                Comment = string.IsNullOrEmpty(status.Property.Comment) ? "-" : status.Property.Comment
            };
        }
    }
}
