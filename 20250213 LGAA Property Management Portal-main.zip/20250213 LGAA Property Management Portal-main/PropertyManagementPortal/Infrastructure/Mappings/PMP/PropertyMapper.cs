﻿using System.Globalization;
using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Resources;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Mappings.PMP
{
    public class PropertyMapper
    {
        public PropertyDTO Map(Property? entity, IConfiguration configuration)
        {
            if (entity == null) { return new PropertyDTO(); }

            return new PropertyDTO()
            {
                PropertyID = entity.PropertyID,
                PropertyDisplayID = entity.PropertyDisplayID,
                PropertyCategoryID = entity.PropertyCategoryID,
                LocationAddress = SEDManager.Unprotect(entity.LocationAddress, configuration),
                KO = entity.KO,
                KP = entity.KP,
                OBS_RBA_SPF_UnitNumber = entity.OBS_RBA_SPF_UnitNumber,
                OBS_RBA_SPF_GardenArea = entity.OBS_RBA_SPF_GardenArea,
                PropertyRegister = entity.PropertyRegister,
                ZoneId = entity.Zone?.Id,
                Latitude = entity.Latitude,
                Longitude = entity.Longitude,
                PropertyArea = entity.PropertyArea,
                PropertyOwner = SEDManager.Unprotect(entity.PropertyOwner, configuration),
                PossessionBasisID = entity.PossessionBasisID,
                OwnershipTypeID = entity.OwnershipTypeID,
                IsDispute = entity.IsDispute,
                DisputeTypeID = entity.DisputeTypeID,
                UsurpationExists = entity.UsurpationExists,
                OwnershipRightsAcquisitionYear = entity.OwnershipRightsAcquisitionYear,
                OwnershipRightsAcquisitionLegalBasisID = entity.OwnershipRightsAcquisitionLegalBasisID,
                OwnershipRightsAcquisitionLegitimationInformation = entity.OwnershipRightsAcquisitionLegitimationInformation,
                IsNationalizedProperty = entity.IsNationalizedProperty,
                IsRestrictedDisposition = entity.IsRestrictedDisposition,
                RestrictedRealRightInformationID = entity.RestrictedRealRightInformationID,
                AL_CreditRatingCategoryID = entity.AL_CreditRatingCategoryID,
                AL_LandTypeID = entity.AL_LandTypeID,
                BL_HasConstructionRights = entity.BL_HasConstructionRights,
                BL_ConstructionRightsBasisID = entity.BL_ConstructionRightsBasisID,
                BL_ConstructionRightsHolder = entity.BL_ConstructionRightsHolder,
                OBS_RBA_SPF_PropertyTypeID = entity.OBS_RBA_SPF_PropertyTypeID,
                SPF_PropertyTypeID = entity.SPF_PropertyTypeID,
                OBS_RBA_SPF_NumberOfFloors = entity.OBS_RBA_SPF_NumberOfFloors,
                OBS_RBA_IsSharedObject = entity.OBS_RBA_IsSharedObject,
                OBS_RBA_SPF_EnergyClassID = entity.OBS_RBA_SPF_EnergyClassID,
                OBS_RBA_SPF_BuildYear = entity.OBS_RBA_SPF_BuildYear,
                OBS_RBA_SPF_ConditionID = entity.OBS_RBA_SPF_ConditionID,
                SPF_IsLegallyConstructed = entity.SPF_IsLegallyConstructed,
                MunicipalityID = entity.MunicipalityID,
                InstalledInfrastructureIDs = entity.PropertyInstalledInfrastructures.Where(r => r.Retired == false).Select(r => r.InstalledInfrastructureID).ToList(),
                Comment = entity.Comment,
                PropertyInstalledInfrastructuresOther = !String.IsNullOrEmpty(entity.PropertyInstalledInfrastructuresOther) ? SEDManager.Unprotect(entity.PropertyInstalledInfrastructuresOther, configuration) : null,
                RestrictedRealRightInformationOther = !String.IsNullOrEmpty(entity.RestrictedRealRightInformationOther) ? SEDManager.Unprotect(entity.RestrictedRealRightInformationOther, configuration) : null,
                AL_BL_LandUseAccordingRegulatoryPlan = !String.IsNullOrEmpty(entity.AL_BL_LandUseAccordingRegulatoryPlan) ? SEDManager.Unprotect(entity.AL_BL_LandUseAccordingRegulatoryPlan, configuration) : null,

                OldAttachments = entity.Attachments.Select(r => r.AzureFileID.ToString()).ToList()
            };
        }

        public Property Map(PropertyDTO model, IConfiguration configuration, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new Property()
            {
                PropertyID = model.PropertyID,
                PropertyDisplayID = model.PropertyDisplayID,
                PropertyCategoryID = model.PropertyCategoryID,
                LocationAddress = SEDManager.Protect(model.LocationAddress, configuration),
                KO = model.KO,
                KP = model.KP,
                OBS_RBA_SPF_UnitNumber = model.OBS_RBA_SPF_UnitNumber,
                OBS_RBA_SPF_GardenArea = model.OBS_RBA_SPF_GardenArea,
                PropertyRegister = model.PropertyRegister,
                ZoneId = model.ZoneId,
                Latitude = model.Latitude,
                Longitude = model.Longitude,
                PropertyArea = model.PropertyArea,
                PropertyOwner = SEDManager.Protect(model.PropertyOwner, configuration),
                PossessionBasisID = model.PossessionBasisID,
                OwnershipTypeID = model.OwnershipTypeID,
                IsDispute = model.IsDispute,
                DisputeTypeID = model.DisputeTypeID,
                UsurpationExists = model.UsurpationExists,
                OwnershipRightsAcquisitionYear = model.OwnershipRightsAcquisitionYear,
                OwnershipRightsAcquisitionLegalBasisID = model.OwnershipRightsAcquisitionLegalBasisID,
                OwnershipRightsAcquisitionLegitimationInformation = model.OwnershipRightsAcquisitionLegitimationInformation,
                IsNationalizedProperty = model.IsNationalizedProperty,
                IsRestrictedDisposition = model.IsRestrictedDisposition,
                RestrictedRealRightInformationID = model.RestrictedRealRightInformationID,
                AL_CreditRatingCategoryID = model.AL_CreditRatingCategoryID,
                AL_LandTypeID = model.AL_LandTypeID,
                BL_HasConstructionRights = model.BL_HasConstructionRights,
                BL_ConstructionRightsBasisID = model.BL_ConstructionRightsBasisID,
                BL_ConstructionRightsHolder = model.BL_ConstructionRightsHolder,
                OBS_RBA_SPF_PropertyTypeID = model.OBS_RBA_SPF_PropertyTypeID,
                SPF_PropertyTypeID = model.SPF_PropertyTypeID,
                OBS_RBA_SPF_NumberOfFloors = model.OBS_RBA_SPF_NumberOfFloors,
                OBS_RBA_IsSharedObject = model.OBS_RBA_IsSharedObject,
                OBS_RBA_SPF_EnergyClassID = model.OBS_RBA_SPF_EnergyClassID,
                OBS_RBA_SPF_BuildYear = model.OBS_RBA_SPF_BuildYear,
                OBS_RBA_SPF_ConditionID = model.OBS_RBA_SPF_ConditionID,
                SPF_IsLegallyConstructed = model.SPF_IsLegallyConstructed,
                MunicipalityID = model.MunicipalityID,
                Comment = model.Comment,
                PropertyInstalledInfrastructuresOther = model.InstalledInfrastructureIDs.Contains(12) ? !String.IsNullOrEmpty(model.PropertyInstalledInfrastructuresOther) ? SEDManager.Protect(model.PropertyInstalledInfrastructuresOther, configuration) : null : null,
                RestrictedRealRightInformationOther = model.RestrictedRealRightInformationID == 3 ? !String.IsNullOrEmpty(model.RestrictedRealRightInformationOther) ? SEDManager.Protect(model.RestrictedRealRightInformationOther, configuration) : null : null,
                AL_BL_LandUseAccordingRegulatoryPlan = model.PropertyCategoryID == 1 || model.PropertyCategoryID == 2 ? !String.IsNullOrEmpty(model.AL_BL_LandUseAccordingRegulatoryPlan) ? SEDManager.Protect(model.AL_BL_LandUseAccordingRegulatoryPlan, configuration) : null : null,
            };

            switch (operation)
            {
                case GlobalEnum.CrudOperation.Add:
                    entity.SysCreatedDate = DateTime.Now;
                    entity.SysCreatedByUserID = loggedUserId;
                    break;
                case GlobalEnum.CrudOperation.Edit:
                    entity.SysLastModifiedDate = DateTime.Now;
                    entity.SysLastModifiedByUserID = loggedUserId;
                    break;
                case GlobalEnum.CrudOperation.Delete:
                default:
                    throw new ArgumentOutOfRangeException(nameof(operation), operation, null);
            }

            return entity;
        }

        public PropertyGridDTO MapGrid(Property entity, IConfiguration configuration, int totalNumberOfRows)
        {
            var currentLeaseData = entity.PropertyLeaseData.Where(r => !r.Retired).OrderByDescending(r => r.SysCreatedDate).FirstOrDefault();

            return new PropertyGridDTO()
            {
                PropertyID = entity.PropertyID,
                PropertyCategoryID = entity.PropertyCategoryID,
                PropertyCategory = entity.PropertyCategory?.Value ?? string.Empty,
                PropertyDisplayID = entity.PropertyDisplayID,
                LocationAddress = SEDManager.Unprotect(entity.LocationAddress, configuration),
                PropertyOwner = SEDManager.Unprotect(entity.PropertyOwner, configuration),
                KO = entity.KO ?? "-",
                KP = entity.KP ?? "-",
                Status = currentLeaseData?.PropertyStatus?.Value ?? PropertyRes.NoStatus,
                StatusID = currentLeaseData?.PropertyStatusID ?? 0,
                CreatedDate = entity.SysCreatedDate.ToShortDateString(),
                Total = totalNumberOfRows
            };
        }

        public ShowPropertyDTO MapDetails(Property? entity, IConfiguration configuration)
        {
            return new ShowPropertyDTO()
            {
                PropertyID = entity?.PropertyID,
                PropertyDisplayID = entity.PropertyDisplayID,
                PropertyCategoryID = entity.PropertyCategoryID,
                PropertyCategory = entity.PropertyCategory.Value ?? LabelsRes.NoData,
                PropertyLatestStatus = entity.PropertyLeaseData.MaxBy(r => r.SysCreatedDate)?.PropertyStatus.Value ?? LabelsRes.NoData,
                PropertyLatestStatusID = entity.PropertyLeaseData.MaxBy(r => r.SysCreatedDate)?.PropertyStatus.PropertyStatusID ?? 0,
                LocationAddress = SEDManager.Unprotect(entity.LocationAddress, configuration) ?? LabelsRes.NoData,

                //First data set
                KO = entity.KO ?? LabelsRes.NoData,
                KP = entity.KP ?? LabelsRes.NoData,
                PropertyRegister = string.IsNullOrEmpty(entity.PropertyRegister) ? LabelsRes.NoData : entity.PropertyRegister,
                Zone = entity.Zone?.Name ?? LabelsRes.NoData,
                ShowGPS = entity is { Latitude: not null, Longitude: not null },
                Latitude = (entity.Latitude != null ? entity.Latitude?.ToString()?.Replace(",", ".") : string.Empty) ?? LabelsRes.NoData,
                Longitude = (entity.Longitude != null ? entity.Longitude?.ToString()?.Replace(",", ".") : string.Empty) ?? LabelsRes.NoData,
                PropertyArea = (string.IsNullOrEmpty(entity.PropertyArea.ToString()) ? LabelsRes.NoData : entity.PropertyArea.ToString()) ?? LabelsRes.NoData,
                OBS_RBA_SPF_NumberOfFloors = (string.IsNullOrEmpty(entity.OBS_RBA_SPF_NumberOfFloors.ToString()) ? LabelsRes.NoData : entity.OBS_RBA_SPF_NumberOfFloors.ToString()) ?? LabelsRes.NoData,
                OBS_RBA_SPF_PropertyType = entity.OBS_RBA_SPF_PropertyType?.Value ?? LabelsRes.NoData,
                SPF_PropertyType = entity.SPF_PropertyType?.Title ?? LabelsRes.NoData,
                OBS_RBA_IsSharedObject = entity.OBS_RBA_IsSharedObject == null ? LabelsRes.NoData : (bool)entity.OBS_RBA_IsSharedObject ? LabelsRes.Yes : LabelsRes.No,
                SPF_IsLegallyConstructed = entity.SPF_IsLegallyConstructed == null ? LabelsRes.NoData : (bool)entity.SPF_IsLegallyConstructed ? LabelsRes.Yes : LabelsRes.No,
                OBS_RBA_SPF_BuildYear = (string.IsNullOrEmpty(entity.OBS_RBA_SPF_BuildYear.ToString()) ? LabelsRes.NoData : entity.OBS_RBA_SPF_BuildYear.ToString()) ?? LabelsRes.NoData,
                OBS_RBA_SPF_Condition = entity.OBS_RBA_SPF_Condition?.Value ?? LabelsRes.NoData,
                OBS_RBA_SPF_GardenArea = (string.IsNullOrEmpty(entity.OBS_RBA_SPF_GardenArea.ToString()) ? LabelsRes.NoData : entity.OBS_RBA_SPF_GardenArea.ToString()) ?? LabelsRes.NoData,
                OBS_RBA_SPF_UnitNumber = entity.OBS_RBA_SPF_UnitNumber.ToString() ?? LabelsRes.NoData,

                //Second data set
                PropertyOwner = string.IsNullOrEmpty(SEDManager.Unprotect(entity.PropertyOwner, configuration)) ? LabelsRes.NoData : SEDManager.Unprotect(entity.PropertyOwner, configuration),
                PossessionBasis = entity.PossessionBasis?.Value ?? LabelsRes.NoData,
                OwnershipType = entity.OwnershipType?.Value ?? LabelsRes.NoData,
                IsDispute = entity.IsDispute == null ? LabelsRes.NoData : (bool)entity.IsDispute ? LabelsRes.Yes : LabelsRes.No,
                DisputeType = entity.DisputeType?.Value ?? LabelsRes.NoData,
                UsurpationExists = entity.UsurpationExists == null ? LabelsRes.NoData : (bool)entity.UsurpationExists ? LabelsRes.Yes : LabelsRes.No,
                OwnershipRightsAcquisitionYear = (string.IsNullOrEmpty(entity.OwnershipRightsAcquisitionYear.ToString()) ? LabelsRes.NoData : entity.OwnershipRightsAcquisitionYear.ToString()) ?? LabelsRes.NoData,
                OwnershipRightsAcquisitionLegalBasis = entity.OwnershipRightsAcquisitionLegalBasis?.Value ?? LabelsRes.NoData,
                OwnershipRightsAcquisitionLegitimationInformation = string.IsNullOrEmpty(entity.OwnershipRightsAcquisitionLegitimationInformation) ? LabelsRes.NoData : entity.OwnershipRightsAcquisitionLegitimationInformation,
                IsNationalizedProperty = entity.IsNationalizedProperty == null ? LabelsRes.NoData : (bool)entity.IsNationalizedProperty ? LabelsRes.Yes : LabelsRes.No,
                IsRestrictedDisposition = entity.IsRestrictedDisposition == null ? LabelsRes.NoData : (bool)entity.IsRestrictedDisposition ? LabelsRes.Yes : LabelsRes.No,
                RestrictedRealRightInformation = entity.RestrictedRealRightInformation?.Value ?? LabelsRes.NoData,

                //Third data set
                BookepingValue = entity.PropertyValues?.MaxBy(r => r.SysCreatedDate)?.CurrentYearBookkeepingValue.ToString(CultureInfo.CurrentCulture) ?? LabelsRes.NoData,
                MarketValue = entity.PropertyValues?.MaxBy(r => r.SysCreatedDate)?.CurrentYearEstimatedMarketValue.ToString(CultureInfo.CurrentCulture) ?? LabelsRes.NoData,
                MaintainanceCostEstimate = entity.PropertyValues?.MaxBy(r => r.SysCreatedDate)?.EstimatedMaintenanceCost.ToString(CultureInfo.CurrentCulture) ?? LabelsRes.NoData,

                AdditionalInformation = LabelsRes.NoData,

                //Forth data set
                Comment = (string.IsNullOrEmpty(entity.Comment) ? LabelsRes.NoData : entity.Comment) ?? LabelsRes.NoData,
                PropertyInstalledInfrastructuresOther =
                (string.IsNullOrEmpty(entity.PropertyInstalledInfrastructuresOther) ? LabelsRes.NoData : SEDManager.Unprotect(entity.PropertyInstalledInfrastructuresOther, configuration)) ?? LabelsRes.NoData,
                RestrictedRealRightInformationOther =
                (string.IsNullOrEmpty(entity.RestrictedRealRightInformationOther) ? LabelsRes.NoData : SEDManager.Unprotect(entity.RestrictedRealRightInformationOther, configuration)) ?? LabelsRes.NoData,

                AL_CreditRatingCategory = entity.AL_CreditRatingCategory?.Value ?? LabelsRes.NoData,
                AL_LandType = entity.AL_LandType?.Value ?? LabelsRes.NoData,
                BL_HasConstructionRights = entity.BL_HasConstructionRights == null ? LabelsRes.NoData : (bool)entity.BL_HasConstructionRights ? LabelsRes.Yes : LabelsRes.No,
                BL_ConstructionRightsBasis = entity.BL_ConstructionRightsBasis?.Value ?? LabelsRes.NoData,
                BL_ConstructionRightsHolder = entity.BL_ConstructionRightsHolder ?? LabelsRes.NoData,
                OBS_RBA_SPF_EnergyClass = entity.OBS_RBA_SPF_EnergyClass?.Value ?? LabelsRes.NoData,
                InstalledInfrastructure = entity.PropertyInstalledInfrastructures
                                            .Where(rel => !rel.Retired)
                                            .Select(rel => rel.InstalledInfrastructure.Value)
                                            .ToList(),

                AL_BL_LandUseAccordingRegulatoryPlan =
                (string.IsNullOrEmpty(entity.AL_BL_LandUseAccordingRegulatoryPlan) ? LabelsRes.NoData : SEDManager.Unprotect(entity.AL_BL_LandUseAccordingRegulatoryPlan, configuration)) ?? LabelsRes.NoData,

                Files = entity.Attachments.Select(r => new AttachmentShowDTO() { Link = r.Link, Name = r.Title }).ToList()
            };
        }
        public ReportPropertyDTO MapExport(Property? entity, IConfiguration configuration)
        {
            var latestLeaseData = entity.PropertyLeaseData.Where(r => !r.Retired).OrderByDescending(r => r.SysCreatedDate).FirstOrDefault();
            return new ReportPropertyDTO()
            {
                PropertyDisplayID = entity.PropertyDisplayID,
                PropertyCategory = entity.PropertyCategory.Value ?? LabelsRes.NoData,
                PropertyLatestStatus = latestLeaseData?.PropertyStatus.Value ?? LabelsRes.NoData,
                LocationAddress = SEDManager.Unprotect(entity.LocationAddress, configuration) ?? LabelsRes.NoData,

                //First data set
                KO = entity.KO ?? LabelsRes.NoData,
                KP = entity.KP ?? LabelsRes.NoData,
                PropertyRegister = entity.PropertyRegister ?? LabelsRes.NoData,
                Zone = entity.Zone?.Name ?? LabelsRes.NoData ?? LabelsRes.NoData,
                OBS_RBA_SPF_GardenArea = entity.OBS_RBA_SPF_GardenArea.ToString() ?? LabelsRes.NoData,
                OBS_RBA_SPF_UnitNumber = entity.OBS_RBA_SPF_UnitNumber.ToString() ?? LabelsRes.NoData,
                Latitude = entity.Longitude.ToString(),
                Longitude = entity.Latitude.ToString(),
                PropertyArea = entity.PropertyArea.ToString() ?? LabelsRes.NoData,
                OBS_RBA_SPF_NumberOfFloors = entity.OBS_RBA_SPF_NumberOfFloors.ToString() ?? LabelsRes.NoData,
                OBS_RBA_SPF_PropertyType = entity.OBS_RBA_SPF_PropertyType?.Value ?? LabelsRes.NoData,
                SPF_PropertyType = entity.SPF_PropertyType?.Title ?? LabelsRes.NoData,
                OBS_RBA_IsSharedObject = entity.OBS_RBA_IsSharedObject == null ? LabelsRes.NoData : (bool)entity.OBS_RBA_IsSharedObject ? LabelsRes.Yes : LabelsRes.No,
                SPF_IsLegallyConstructed = entity.SPF_IsLegallyConstructed == null ? LabelsRes.NoData : (bool)entity.SPF_IsLegallyConstructed ? LabelsRes.Yes : LabelsRes.No,
                OBS_RBA_SPF_BuildYear = entity.OBS_RBA_SPF_BuildYear.ToString() ?? LabelsRes.NoData,
                OBS_RBA_SPF_Condition = entity.OBS_RBA_SPF_Condition?.Value ?? LabelsRes.NoData,

                //Second data set
                PropertyOwner = SEDManager.Unprotect(entity.PropertyOwner, configuration) ?? LabelsRes.NoData,
                PossessionBasis = entity.PossessionBasis?.Value ?? LabelsRes.NoData,
                OwnershipType = entity.OwnershipType?.Value ?? LabelsRes.NoData,
                IsDispute = entity.IsDispute == null ? LabelsRes.NoData : (bool)entity.IsDispute ? LabelsRes.Yes : LabelsRes.No,
                DisputeType = entity.DisputeType?.Value ?? LabelsRes.NoData,
                UsurpationExists = entity.UsurpationExists == null ? LabelsRes.NoData : (bool)entity.UsurpationExists ? LabelsRes.Yes : LabelsRes.No,
                OwnershipRightsAcquisitionYear = entity.OwnershipRightsAcquisitionYear.ToString() ?? LabelsRes.NoData,
                OwnershipRightsAcquisitionLegalBasis = entity.OwnershipRightsAcquisitionLegalBasis?.Value ?? LabelsRes.NoData,
                OwnershipRightsAcquisitionLegitimationInformation = entity.OwnershipRightsAcquisitionLegitimationInformation ?? LabelsRes.NoData,
                IsNationalizedProperty = entity.IsNationalizedProperty == null ? LabelsRes.NoData : (bool)entity.IsNationalizedProperty ? LabelsRes.Yes : LabelsRes.No,
                IsRestrictedDisposition = entity.IsRestrictedDisposition == null ? LabelsRes.NoData : (bool)entity.IsRestrictedDisposition ? LabelsRes.Yes : LabelsRes.No,
                RestrictedRealRightInformation = entity.RestrictedRealRightInformation?.Value ?? LabelsRes.NoData,

                PropertyInstalledInfrastructuresOther =
                (string.IsNullOrEmpty(entity.PropertyInstalledInfrastructuresOther) ? LabelsRes.NoData : SEDManager.Unprotect(entity.PropertyInstalledInfrastructuresOther, configuration)) ?? LabelsRes.NoData,
                RestrictedRealRightInformationOther =
                (string.IsNullOrEmpty(entity.RestrictedRealRightInformationOther) ? LabelsRes.NoData : SEDManager.Unprotect(entity.RestrictedRealRightInformationOther, configuration)) ?? LabelsRes.NoData,


                //Third data set
                BookepingValue = entity.PropertyValues.MaxBy(r => r.SysCreatedDate)?.CurrentYearBookkeepingValue.ToString(CultureInfo.CurrentCulture) ?? LabelsRes.NoData,
                MarketValue = entity.PropertyValues.MaxBy(r => r.SysCreatedDate)?.CurrentYearEstimatedMarketValue.ToString(CultureInfo.CurrentCulture) ?? LabelsRes.NoData,
                MaintainanceCostEstimate = entity.PropertyValues.MaxBy(r => r.SysCreatedDate)?.EstimatedMaintenanceCost.ToString(CultureInfo.CurrentCulture) ?? LabelsRes.NoData,

                //Forth data set
                AL_CreditRatingCategory = entity.AL_CreditRatingCategory?.Value ?? LabelsRes.NoData,
                AL_LandType = entity.AL_LandType?.Value ?? LabelsRes.NoData,
                BL_HasConstructionRights = entity.BL_HasConstructionRights == null ? LabelsRes.NoData : (bool)entity.BL_HasConstructionRights ? LabelsRes.Yes : LabelsRes.No,
                BL_ConstructionRightsBasis = entity.BL_ConstructionRightsBasis?.Value ?? LabelsRes.NoData,
                BL_ConstructionRightsHolder = entity.BL_ConstructionRightsHolder ?? LabelsRes.NoData,
                OBS_RBA_SPF_EnergyClass = entity.OBS_RBA_SPF_EnergyClass?.Value ?? LabelsRes.NoData,
                InstalledInfrastructure = string.Join(", ", entity.PropertyInstalledInfrastructures
                                            .Where(rel => !rel.Retired)
                                            .Select(rel => rel.InstalledInfrastructure.Value)
                                            .ToList()),
                AL_BL_LandUseAccordingRegulatoryPlan =
                (string.IsNullOrEmpty(entity.AL_BL_LandUseAccordingRegulatoryPlan) ? LabelsRes.NoData : SEDManager.Unprotect(entity.AL_BL_LandUseAccordingRegulatoryPlan, configuration)) ?? LabelsRes.NoData,


                PropertyStatus = latestLeaseData?.PropertyStatus.Value ?? LabelsRes.NoData,
                PropertyUserName = latestLeaseData?.PropertyUserName.Label() ?? LabelsRes.NoData,
                ContractNumber = latestLeaseData?.ContractNumber.Label() ?? LabelsRes.NoData,
                ContractConclusionDate = (latestLeaseData?.ContractConclusionDate?.ToShortDateString() ?? LabelsRes.NoData).Label() ?? LabelsRes.NoData,
                ContractDurationInMonths = latestLeaseData?.ContractDurationInMonths.ToString().Label() ?? LabelsRes.NoData,
                PaymentFrequency = latestLeaseData?.PaymentFrequency?.Value.Label() ?? LabelsRes.NoData,
                OtherContractualObligations = latestLeaseData?.OtherContractualObligations.Label() ?? LabelsRes.NoData,
                PropertyUseBasisDocument = latestLeaseData?.PropertyUseBasisDocument?.Value.Label() ?? LabelsRes.NoData,
                PropertyUseBasis = latestLeaseData?.PropertyUseBasis?.Value.Label() ?? LabelsRes.NoData,
                PropertyUserGender = latestLeaseData?.PropertyUserGender?.Value.Label() ?? LabelsRes.NoData,
                PropertyUserType = latestLeaseData?.PropertyUserType?.Value.Label() ?? LabelsRes.NoData,
                ContractedValue = latestLeaseData?.ContractedValue.ToString().Label() ?? LabelsRes.NoData,
                ContractTypeBasedOnUserStatus = latestLeaseData?.ContractTypeBasedOnUserStatus?.Value.Label() ?? LabelsRes.NoData,
                ContractType = latestLeaseData?.ContractType?.Value.Label() ?? LabelsRes.NoData,
                PropertyUserTypeOther = latestLeaseData?.PropertyUserTypeOther.Label() ?? LabelsRes.NoData,
            };
        }
    }
}
