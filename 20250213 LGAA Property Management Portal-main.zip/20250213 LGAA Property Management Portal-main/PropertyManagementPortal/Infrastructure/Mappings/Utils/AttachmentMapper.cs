﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities.Utils;
using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.Infrastructure.Mappings.Utils
{
    public class AttachmentMapper
    {
        public AttachedFiles Map(IFormFile uploadedFile, Guid fileGuid, short attachmentType, Guid mainObjectId, Guid loggedUserId)
        {
            var file = new AttachedFiles()
            {
                AzureFileID = fileGuid,
                FileName = Path.GetFileNameWithoutExtension(uploadedFile.FileName),
                Extension = Path.GetExtension(uploadedFile.FileName),
                ContentType = uploadedFile.ContentType,
                Title = uploadedFile.FileName,
                Size = uploadedFile.Length,
                SysCreatedByUserID = loggedUserId,
                Retired = false,
            };

            switch (attachmentType)
            {
                case (short)GlobalEnum.AttachmentTypes.Property:
                    file.PropertyID = mainObjectId; break;
                case (short)GlobalEnum.AttachmentTypes.PropertyLeaseData:
                    file.PropertyLeaseDataID = mainObjectId; break;
                default:
                    throw new ArgumentException();
            }

            return file;
        }

        public FormFileDTO Map(AttachedFiles model)
        {
            return new();
        }
    }
}
