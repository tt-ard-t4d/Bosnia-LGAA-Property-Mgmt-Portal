﻿using Domain.Entities.Utils;
using DTO.Utils;

namespace Infrastructure.Mappings.Utils
{
    public class EmailNotificationMapper
    {
        public EmailNotificationMapper()
        {
        }

        public EmailNotificationDTO MapEmailNotification(EmailNotification emailnotification)
        {
            return new EmailNotificationDTO()
            {
                EmailNotificationID = emailnotification.EmailNotificationID,
                EmailDescription = emailnotification.EmailDescription,
                EmailSubject = emailnotification.EmailSubject,
                EmailText = emailnotification.EmailText,
                SysDateCreated = emailnotification.SysDateCreated,
                SysDateLastModified = emailnotification.SysDateLastModified,
                SysCreatedByUserID = emailnotification.SysCreatedByUserID,
                SysModifiedByUserID = emailnotification.SysModifiedByUserID,
                EmailStatus = emailnotification.EmailStatus
            };
        }

        public EmailNotificationDTO MapEmailNotification()
        {
            return new EmailNotificationDTO()
            {
                EmailNotificationID = 0
            };
        }

        public EmailNotification MapEmailNotification(EmailNotificationDTO emailnotification)
        {
            return new EmailNotification()
            {
                EmailNotificationID = emailnotification.EmailNotificationID,
                EmailDescription = emailnotification.EmailDescription,
                EmailSubject = emailnotification.EmailSubject,
                EmailText = emailnotification.EmailText,
                SysDateCreated = emailnotification.SysDateCreated,
                SysDateLastModified = emailnotification.SysDateLastModified,
                SysCreatedByUserID = emailnotification.SysCreatedByUserID,
                SysModifiedByUserID = emailnotification.SysModifiedByUserID,
                EmailStatus = emailnotification.EmailStatus

            };
        }
    }
}
