﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.Infrastructure.Mappings
{
    public class GridMapper
    {
        public GridDTO<T, S> MapGrid<T, S>(List<T> data, S search, PageDTO pager, bool isSelectable = false)
        {
            return new GridDTO<T, S>()
            {
                Data = data,
                Search = search,
                Pager = pager,
                IsSelectable = isSelectable
            };
        }
    }
}
