﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using NuGet.Packaging;
using PropertyManagementPortal.Domain.Contracts.Admin;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Models.StoredProcedures;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.Admin
{
    public class UserRepository : IUserRepository
    {
        private readonly DatabaseContext _dc;

        public UserRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public IQueryable<UserActionRel> GetUserActionRels()
        {
            return _dc.UserActions.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<UserGroupUserRel> GetUserGroupUserRels()
        {
            return _dc.UserGroupUsers.AsNoTracking().Where(r => r.Retired == false);
        }

        public User? GetUserByEmailCode(string guid)
        {
            return _dc.Users.AsNoTracking()
                .Include(r => r.UserGroupUsers).ThenInclude(r => r.UserGroup)
                .Include(r => r.UserActions).ThenInclude(r => r.Action)
                .Include(r => r.UserMunicipalities).ThenInclude(r => r.Municipality)
                .Where(r => r.Retired == false && r.EmailCode.ToString().Equals(guid)).FirstOrDefault();
        }

        public IQueryable<User> GetUserEmails(Guid impersonatedUserId)
        {
            return _dc.Users.Where(r => r.Retired == false && r.UserID != impersonatedUserId).AsNoTracking();
        }

        public (IQueryable<User>, int) GetUserGrid(SearchUserDTO args)
        {
            var res = _dc.Users
                .Include(r => r.UserActions)
                .Include(r => r.UserGroupUsers)
                .Include(r => r.UserMunicipalities)
                .AsNoTracking()
                .Where(r => r.Retired == false);

            if (args.UserGroupID > 0)
            {
                res = res.Where(r => r.UserGroupUsers
                .Where(g => g.Retired == false)
                .Select(g => g.UserGroupID)
                .Contains((short)args.UserGroupID));
            }

            if (args.MunicipalityID > 0)
            {
                res = res.Where(r => r.UserMunicipalities
                    .Where(m => m.Retired == false)
                    .Select(m => m.MunicipalityID)
                    .Contains(args.MunicipalityID));
            }

            return (res, res.Count());
        }

        public (IQueryable<User>, int) GetMunicipalityUsersGrid(SearchUserDTO args, List<int> userMunicipalities)
        {
            var res = _dc.Users
                .Include(r => r.UserMunicipalities)
                .Include(r => r.UserActions)
                .Include(r => r.UserGroupUsers)
                .AsNoTracking()
                .Where(r => r.Retired == false);

            //Only take users that belong to his municipality
            res = res.Where(r => r.UserMunicipalities.Any(r => userMunicipalities.Contains(r.MunicipalityID) && r.Retired == false));
            //Nema potrebe da gleda sistemske administratore
            res = res.Where(r => !r.UserGroupUsers.Any(r => r.UserGroupID == 1));

            if (args.UserGroupID > 0)
            {
                res = res.Where(r => r.UserGroupUsers
                .Where(g => g.Retired == false)
                .Select(g => g.UserGroupID)
                .Contains((short)args.UserGroupID));
            }

            if (args.MunicipalityID > 0)
            {
                res = res.Where(r => r.UserMunicipalities
                    .Where(m => m.Retired == false)
                    .Select(m => m.MunicipalityID)
                    .Contains(args.MunicipalityID));
            }

            return (res, res.Count());
        }

        public IQueryable<GetUserActions> GetUserActions(Guid userId)
        {
            return (
                    from uar in _dc.UserActions
                    join act in _dc.Actions on uar.ActionID equals act.ActionID
                    where uar.UserID == userId && uar.Retired == false && act.Retired == false
                    select new GetUserActions() { ActionID = uar.ActionID, ActionName = act.ActionName, ActionEnumerationName = act.ActionEnumerationName })

                .Union(
                    from ugar in _dc.UserGroupActions
                    join act in _dc.Actions on ugar.ActionID equals act.ActionID
                    join ugur in _dc.UserGroupUsers on ugar.UserGroupID equals ugur.UserGroupID
                    where ugur.UserID == userId && ugar.Retired == false && act.Retired == false && ugar.Retired == false
                    select new GetUserActions() { ActionID = ugar.ActionID, ActionName = act.ActionName, ActionEnumerationName = act.ActionEnumerationName }
                );
        }


        public User? GetUserById(Guid userId)
        {
            return _dc.Users
                .AsNoTracking()
                .Include(r => r.UserGroupUsers).ThenInclude(r => r.UserGroup)
                .Include(r => r.UserActions).ThenInclude(r => r.Action)
                .Include(r => r.UserMunicipalities).ThenInclude(r => r.Municipality)
                .FirstOrDefault(r => r.UserID == userId && r.Retired == false);
        }

        public User? GetUserByUserNameEnc(string userNameEnc)
        {
            return _dc.Users
                .AsNoTracking()
                .Include(r => r.UserGroupUsers).ThenInclude(r => r.UserGroup)
                .Include(r => r.UserActions).ThenInclude(r => r.Action)
                .Include(r => r.UserMunicipalities).ThenInclude(r => r.Municipality)
                .FirstOrDefault(r => r.UserNameEnc == userNameEnc && r.Retired == false);
        }

        public User? GetUserByEmailEnc(string emailEnc)
        {
            return _dc.Users
                .AsNoTracking()
                .Include(r => r.UserGroupUsers).ThenInclude(r => r.UserGroup)
                .Include(r => r.UserActions).ThenInclude(r => r.Action)
                .Include(r => r.UserMunicipalities).ThenInclude(r => r.Municipality)
                .FirstOrDefault(r => r.EmailEnc == emailEnc && r.Retired == false);
        }

        public RetValue Save(User entity, UserDTO vm, GlobalEnum.CrudOperation operation)
        {
            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.Users.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;

                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
                _dc.Entry(entity).Property(r => r.PasswordHash).IsModified = false;
                _dc.Entry(entity).Property(r => r.PasswordSalt).IsModified = false;
                _dc.Entry(entity).Property(r => r.EmailCode).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.Users.Add(entity);
            }

            AddEditUserGroups(ref entity, vm);
            AddEditMunicipalities(ref entity, vm);

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Guid = entity.UserID };
        }

        private void AddEditUserGroups(ref User entity, UserDTO vm)
        {
            var ids = vm.UserGroupIDs;

            //Get all relations (even retired), set retired to false if list of ids contains the relation
            var existing = _dc.UserGroupUsers.Where(r => r.UserID == vm.UserID);

            if (existing != null)
            {
                foreach (var item in existing)
                {
                    if (ids.Contains(item.UserGroupID))
                    {
                        item.Retired = false;
                        ids.Remove(item.UserGroupID);
                    }
                    else
                    {
                        item.Retired = true;
                    }
                }
            }

            if (ids != null)
            {
                var userGroups = _dc.UserGroups.Where(r => r.Retired == false && ids.Contains(r.UserGroupID));
                var addGroups = new List<UserGroupUserRel>();

                foreach (var item in userGroups)
                {
                    addGroups.Add(
                        new UserGroupUserRel()
                        {
                            User = entity,
                            UserGroup = item,
                            Retired = false
                        }
                    );
                }

                entity.UserGroupUsers ??= new List<UserGroupUserRel>();
                entity.UserGroupUsers.AddRange(addGroups);
            }
        }

        private void AddEditMunicipalities(ref User entity, UserDTO vm)
        {
            var ids = vm.MunicipalityIDs;

            var existing = _dc.UserMunicipalities.Where(r => r.UserID == vm.UserID);

            if (existing != null)
            {
                foreach (var item in existing)
                {
                    if (ids.Contains(item.MunicipalityID))
                    {
                        item.Retired = false;
                        ids.Remove(item.MunicipalityID);
                    }
                    else
                    {
                        item.Retired = true;
                    }
                }
            }

            if (ids != null)
            {
                var userMunicipalities = _dc.Municipalities.Where(r => r.Retired == false && ids.Contains(r.MunicipalityID));
                var addMunicipalities = new List<UserMunicipalityRel>();

                foreach (var item in userMunicipalities)
                {
                    addMunicipalities.Add(
                        new UserMunicipalityRel()
                        {
                            User = entity,
                            Municipality = item,
                            Retired = false
                        }
                    );
                }

                entity.UserMunicipalities ??= new List<UserMunicipalityRel>();
                entity.UserMunicipalities.AddRange(addMunicipalities);
            }
        }

        private void AddEditUserActions(ref User entity, UserDTO vm)
        {
            var ids = vm.UserActionIDs;

            //Get all relations (even retired), set retired to false if list of ids contains the relation
            var existing = _dc.UserActions.Where(r => r.UserID == vm.UserID);

            if (existing != null)
            {
                foreach (var item in existing)
                {
                    if (ids.Contains(item.ActionID))
                    {
                        item.Retired = false;
                        ids.Remove(item.ActionID);
                    }
                    else
                    {
                        item.Retired = true;
                    }
                }
            }

            if (ids != null)
            {
                var userActions = _dc.Actions.Where(r => r.Retired == false && ids.Contains(r.ActionID));
                var addActions = new List<UserActionRel>();

                foreach (var item in userActions)
                {
                    addActions.Add(
                        new UserActionRel()
                        {
                            User = entity,
                            Action = item,
                            Retired = false
                        }
                    );
                }

                entity.UserActions ??= new List<UserActionRel>();
                entity.UserActions.AddRange(addActions);
            }
        }

        public UserGroup? GetUserGroupById(int userGroupId)
        {
            return _dc.UserGroups
                .AsNoTracking()
                .FirstOrDefault(r => r.Retired == false && r.UserGroupID == userGroupId);
        }

        public User? GetDirectoryUserByEmail(string? email)
        {
            return _dc.Users
                .AsNoTracking()
                .Include(r => r.UserGroupUsers).ThenInclude(r => r.UserGroup)
                .Include(r => r.UserActions).ThenInclude(r => r.Action)
                .Include(r => r.UserMunicipalities).ThenInclude(r => r.Municipality)
                .FirstOrDefault(r => r.EmailEnc == email && r.IsDirectoryUser == true && r.Retired == false);
        }

        public RetValue ChangePassword(User entity, string password)
        {
            //Change existing email code
            entity.EmailCode = Guid.NewGuid();

            //Change password hash and salt
            string? salt = null;

            string hash = HashingUtils.HashPassword(password, out salt);

            entity.PasswordHash = hash;
            entity.PasswordSalt = salt;

            _dc.Users.Attach(entity);
            _dc.Entry(entity).Property(r => r.EmailCode).IsModified = true;
            _dc.Entry(entity).Property(r => r.PasswordHash).IsModified = true;
            _dc.Entry(entity).Property(r => r.PasswordSalt).IsModified = true;

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { IsError = false, ErrorMessage = "Password changed" };
        }

        public RetValue Delete(Guid userId, Guid loggedUserId)
        {
            var delete = _dc.Users.FirstOrDefault(r => r.UserID == userId);

            try
            {
                delete.Retired = true;
                delete.SysLastModifiedByUserID = loggedUserId;
                delete.SysLastModifiedDate = DateTime.Now;

                _dc.SaveChanges();

                return new RetValue()
                {
                    IsError = false,
                    Guid = delete.UserID,
                };
            }
            catch (Exception ex)
            {
                return new RetValue()
                {
                    IsError = true,
                    Guid = delete.UserID,
                    Exception = ex,
                    ErrorMessage = ex.Message
                };
            }
        }
    }
}
