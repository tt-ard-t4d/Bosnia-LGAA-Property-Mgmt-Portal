﻿using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.App
{
    public class PMPDropdownRepository : IPMPDropDownRepository
    {
        private readonly DatabaseContext _dc;

        public PMPDropdownRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public IQueryable<Municipality> GetAllMunicipalities()
        {
            return _dc.Municipalities.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<Entity> GetEntities()
        {
            return _dc.Entities.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId)
        {
            return _dc.UserMunicipalities.Include(r => r.Municipality).Where(r => r.Retired == false && r.UserID == userId).Select(r => r.Municipality);
        }
    }
}
