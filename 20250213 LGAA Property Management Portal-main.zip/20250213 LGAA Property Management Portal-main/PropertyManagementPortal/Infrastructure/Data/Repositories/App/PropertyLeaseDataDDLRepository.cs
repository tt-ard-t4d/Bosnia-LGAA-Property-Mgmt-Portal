﻿using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities.CodeBooks;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.App
{
    public class PropertyLeaseDataDDLRepository : IPropertyLeaseDataDDLRepository
    {
        private readonly DatabaseContext _dc;

        public PropertyLeaseDataDDLRepository(DatabaseContext dc)
        {
            _dc = dc;
        }
        public IQueryable<PropertyUserType> GetPropertyUserTypes()
        {
            return _dc.PropertyUserTypes.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PropertyUserGender> GetPropertyUserGenders()
        {
            return _dc.PropertyUserGenders.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<ContractTypeBasedOnUserStatus> GetContractTypesBasedOnUserStatus()
        {
            return _dc.ContractTypesBasedOnUserStatus.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<ContractType> GetContractTypes()
        {
            return _dc.ContractTypes.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PropertyStatus> GetPropertyStatuses()
        {
            return _dc.PropertyStatuses.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PropertyUseBasis> GetPropertyUseBases()
        {
            return _dc.PropertyUseBases.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PropertyUseBasisDocument> GetPropertyUseBasisDocuments()
        {
            return _dc.PropertyUseBasisDocuments.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PaymentFrequency> GetPaymentFrequencies()
        {
            return _dc.PaymentFrequencies.AsNoTracking().Where(r => r.Retired == false);
        }
    }
}
