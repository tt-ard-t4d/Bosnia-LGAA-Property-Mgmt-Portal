﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.Domain.Entities.CodeBooks;
using PropertyManagementPortal.Infrastructure.Helpers;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.App
{
    public class PropertyDDLRepository : IPropertyDDLRepository
    {
        private readonly DatabaseContext _dc;

        public PropertyDDLRepository(DatabaseContext dc)
        {
            _dc = dc;
        }
        public IQueryable<AL_CreditRatingCategory> GetAL_CreditRatingCategories()
        {
            return _dc.AL_CreditRatingCategories.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<DisputeType> GetDisputeTypes()
        {
            return _dc.DisputeTypes.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<OBS_RBA_SPF_PropertyType> GetOBS_RBA_SPF_PropertyTypes()
        {
            return _dc.OBS_PropertyTypes.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<SPF_PropertyType> GetSPF_PropertyTypes()
        {
            return _dc.SPF_PropertyTypes.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<OBS_RBA_SPF_EnergyClass> GetOBS_RBA_SPF_EnergyClasses()
        {
            return _dc.OBS_RBA_SPF_EnergyClasses.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<OwnershipRightsAcquisitionLegalBasis> GetOwnershipRightsAcquisitionLegalBases()
        {
            return _dc.OwnershipRightsAcquisitionLegalBases.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<OwnershipType> GetOwnershipTypes()
        {
            return _dc.OwnershipTypes.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PossessionBasis> GetPossessionBases()
        {
            return _dc.PossessionBases.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PropertyCategory> GetPropertyCategories()
        {
            return _dc.PropertyCategories.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<OBS_RBA_SPF_Condition> GetOBS_RBA_SPF_Conditions()
        {
            return _dc.OBS_RBA_SPF_Conditions.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<RestrictedRealRightInformation> GetRestrictedRealRightInformation()
        {
            return _dc.RestrictedRealRightInformation.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<BL_ConstructionRightsBasis> GetBLConstructionRightsBases()
        {
            return _dc.BL_ConstructionRightsBases.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<PropertyStatus> GetPropertyStatuses()
        {
            return _dc.PropertyStatuses.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId)
        {
            return _dc.UserMunicipalities
                .Include(r => r.Municipality)
                .Where(r => r.Retired == false && r.UserID == userId && r.Municipality.Retired == false)
                .Select(r => r.Municipality);
        }

        public IQueryable<InstalledInfrastructure> GetInstalledInfrastructures()
        {
            return _dc.InstalledInfrastructure.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<Zone> GetZones()
        {
            return _dc.Zones.AsNoTracking().Where(r => r.Retired == false);
        }

        public IQueryable<User> GetMunicipalityUsers(int municipalityId)
        {
            return _dc.Users
                .AsNoTracking()
                .Include(u => u.UserMunicipalities)
                .Include(u => u.UserGroupUsers)
                .Where(u =>
                    !u.Retired &&
                    !u.UserGroupUsers.Any(ug => ug.UserGroupID == (byte)ActionManagementEnum.UserGroups.Administrator && !ug.Retired) &&
                    u.UserMunicipalities.Any(um => um.MunicipalityID == municipalityId && !um.Retired)
                );
        }

        public IQueryable<User> GetAllUsers()
        {
            return _dc.Users
                .AsNoTracking()
                .Include(u => u.UserMunicipalities)
                .Include(u => u.UserGroupUsers)
                .Where(u =>
                    !u.Retired
                );
        }

        public IQueryable<AL_LandType> GetLandTypes()
        {
            return _dc.AL_LandTypes.AsNoTracking().Where(r => r.Retired == false);
        }
    }
}
