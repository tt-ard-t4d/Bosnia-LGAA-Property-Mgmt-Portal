﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.PropertyValue;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.App
{
    public class PropertyValueRepository : IPropertyValueRepository
    {
        private readonly DatabaseContext _dc;

        public PropertyValueRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public PropertyValue? GetPropertyValueById(Guid id)
        {
            return _dc.PropertyValues
                .OrderByDescending(r => r.SysCreatedDate)
                .FirstOrDefault(r => r.PropertyValueID.Equals(id) && r.Retired == false);
        }

        public (List<PropertyValue>, int) GetPropertyValueGrid(SearchPropertyValueDTO args, int numberOfObjectsPerPage)
        {
            var res = GetAllPropertyValuesForGrid(args);

            //Filter data - add filters later

            (var columnName, var direction) = UtilsHelper.GetSortOrder(args.SortBy);
            res = res.SortRows(columnName, direction);

            var totalNumberOfRows = res.Count();

            return (res.Page(numberOfObjectsPerPage, args.Page).ToList(), totalNumberOfRows);
        }

        private IQueryable<PropertyValue> GetAllPropertyValuesForGrid(SearchPropertyValueDTO args)
        {
            return _dc.PropertyValues
                //.Include(r => r.Property)
                .OrderByDescending(r => r.SysCreatedDate)
                .AsNoTracking()
                .Where(r => r.Retired == false && r.PropertyID == args.PropertyID);
        }

        public RetValue Save(PropertyValue entity, GlobalEnum.CrudOperation operation)
        {
            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.PropertyValues.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;
                _dc.Entry(entity).Property(r => r.PropertyValueID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
                _dc.Entry(entity).Property(r => r.Retired).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.PropertyValues.Add(entity);
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Guid = entity.PropertyValueID };
        }
        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            var delete = _dc.PropertyValues.FirstOrDefault(r => r.PropertyValueID == id);

            if (delete == null)
            {
                return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingItem };
            }

            try
            {
                delete.Retired = true;
                delete.SysLastModifiedByUserID = loggedUserId;
                delete.SysLastModifiedDate = DateTime.Now;

                _dc.SaveChanges();

                return new RetValue() { IsError = false, Guid = delete.PropertyID };
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }
        }
    }
}
