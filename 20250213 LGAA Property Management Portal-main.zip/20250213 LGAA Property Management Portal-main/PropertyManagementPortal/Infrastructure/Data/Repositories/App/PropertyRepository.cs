﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using NuGet.Packaging;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.Domain.Entities.CodeBooks;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.App
{
    public class PropertyRepository : IPropertyRepository
    {
        private readonly DatabaseContext _dc;

        public PropertyRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            var delete = _dc.Properties.FirstOrDefault(r => r.PropertyID == id);

            if (delete == null)
            {
                return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingItem };
            }

            try
            {
                delete.Retired = true;
                delete.SysLastModifiedByUserID = loggedUserId;
                delete.SysLastModifiedDate = DateTime.Now;

                _dc.SaveChanges();

                return new RetValue() { IsError = false, Guid = delete.PropertyID };
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }
        }

        public Property? GetPropertyById(Guid id)
        {
            return _dc.Properties.AsNoTracking()
                .Include(r => r.Attachments.Where(a => !a.Retired))
                .Include(r => r.PropertyInstalledInfrastructures.Where(p => !p.Retired))
                .ThenInclude(r => r.InstalledInfrastructure)
                .AsNoTracking()
                .FirstOrDefault(r => r.PropertyID.Equals(id) && r.Retired == false);
        }

        public Property? GetPropertyForStatusReport(Guid id)
        {
            return _dc.Properties.AsNoTracking()
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.PropertyStatus)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.PaymentFrequency)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.PropertyUseBasisDocument)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.PropertyUseBasis)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.PropertyUserGender)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.PropertyUserType)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.ContractTypeBasedOnUserStatus)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(p => p.ContractType)
                .AsNoTracking()
                .FirstOrDefault(r => r.PropertyID.Equals(id) && r.Retired == false);
        }

        public Property? GetPropertyDetailsById(Guid id)
        {
            return _dc.Properties
                .Include(r => r.PropertyCategory)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyStatus)
                .Include(r => r.Zone)
                .Include(r => r.OBS_RBA_SPF_PropertyType)
                .Include(r => r.OBS_RBA_SPF_Condition)
                .Include(r => r.PossessionBasis)
                .Include(r => r.OwnershipType)
                .Include(r => r.DisputeType)
                .Include(r => r.OwnershipRightsAcquisitionLegalBasis)
                .Include(r => r.RestrictedRealRightInformation)
                .Include(r => r.PropertyValues)
                .Include(r => r.AL_CreditRatingCategory)
                .Include(r => r.AL_LandType)
                .Include(r => r.BL_ConstructionRightsBasis)
                .Include(r => r.OBS_RBA_SPF_EnergyClass)
                .Include(r => r.Attachments.Where(a => !a.Retired))
                .Include(r => r.PropertyInstalledInfrastructures)
                .ThenInclude(pii => pii.InstalledInfrastructure)
                .AsNoTracking()
                .FirstOrDefault(r => r.PropertyID.Equals(id) && r.Retired == false);
        }

        public (List<Property>, int) GetPropertyGrid(SearchPropertyDTO args, Guid loggedUserGuid, IConfiguration configuration, int numberOfObjectsPerPage)
        {
            var res = GetAllPropertiesForGrid(args, loggedUserGuid);

            // Filter by MunicipalityID
            if (args.MunicipalityID > 0)
            {
                res = res.Where(p => p.MunicipalityID == args.MunicipalityID);
            }

            // Filter by PropertyCategoryID
            if (args.PropertyCategoryID > 0)
            {
                res = res.Where(p => p.PropertyCategoryID == args.PropertyCategoryID);
            }
            // Filter by StatusID
            if (args.StatusID > 0)
            {
                res = res.Where(p => p.PropertyLeaseData.Count() != 0 && p.PropertyLeaseData.OrderByDescending(data => data.SysCreatedDate).FirstOrDefault().PropertyStatusID == args.StatusID);
            }

            //Filter by users
            if (args.UserGuid != Guid.Empty)
            {
                res = res.Where(p => p.SysCreatedByUserID == args.UserGuid);
            }

            //SearchTerm Address and Owner filtering done outside of query because of the encrypted fields
            var resList = res.ToList();

            if (!string.IsNullOrWhiteSpace(args.SearchTerm))
            {
                string searchTerm = args.SearchTerm.ToLower();

                resList = resList.Where(p =>
                    (p.LocationAddress != null && SEDManager.Unprotect(p.LocationAddress, configuration).ToLower().Contains(searchTerm)) ||
                    (p.KO != null && p.KO.ToLower().Contains(searchTerm)) ||
                    (p.KP != null && p.KP.ToLower().Contains(searchTerm)) ||
                    (p.PropertyOwner != null && SEDManager.Unprotect(p.PropertyOwner, configuration).ToLower().Contains(searchTerm))
                ).ToList();
            }

            var totalNumberOfRows = resList.Count();
            resList = resList.AsQueryable().OrderByDescending(r => r.SysCreatedDate).ToList();

            return (resList.Page(numberOfObjectsPerPage, args.Page).ToList(), totalNumberOfRows);
        }

        private void SaveInstalledInfrastructure(ref Property entity, PropertyDTO vm)
        {
            var installedInfrastructureIDs = vm.InstalledInfrastructureIDs;

            //Get all relations (even retired) with tracking
            var existing = _dc.PropertyInstalledInfrastructureRel.Where(r => r.PropertyID == vm.PropertyID);

            if (existing != null)
            {
                foreach (var item in existing)
                {
                    if (installedInfrastructureIDs.Contains(item.InstalledInfrastructureID))
                    {
                        item.Retired = false;
                        installedInfrastructureIDs.Remove(item.InstalledInfrastructureID);
                    }
                    else
                    {
                        item.Retired = true;
                    }
                }
            }

            if (installedInfrastructureIDs != null)
            {
                var installedInfrastructures = _dc.InstalledInfrastructure.Where(r => r.Retired == false && installedInfrastructureIDs.Contains(r.InstalledInfrastructureID));
                var addActions = new List<PropertyInstalledInfrastructureRel>();

                foreach (var item in installedInfrastructures)
                {
                    addActions.Add(
                        new PropertyInstalledInfrastructureRel()
                        {
                            InstalledInfrastructure = item,
                            Property = entity,
                            Retired = false
                        }
                    );
                }

                entity.PropertyInstalledInfrastructures ??= new List<PropertyInstalledInfrastructureRel>();
                entity.PropertyInstalledInfrastructures.AddRange(addActions);
            }
        }

        public RetValue Save(Property entity, PropertyDTO vm, GlobalEnum.CrudOperation operation)
        {
            SaveInstalledInfrastructure(ref entity, vm);

            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.Properties.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;
                _dc.Entry(entity).Property(r => r.PropertyDisplayID).IsModified = false;
                _dc.Entry(entity).Property(r => r.PropertyID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
                _dc.Entry(entity).Property(r => r.Retired).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.Properties.Add(entity);
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Guid = entity.PropertyID };
        }

        private IQueryable<Property> GetAllPropertiesForGrid(SearchPropertyDTO args, Guid loggedUserGuid)
        {
            var userMunicipalities = GetUserMunicipalities(loggedUserGuid);

            return _dc.Properties
                .Include(r => r.PropertyCategory)
                .Include(r => r.Municipality)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyStatus)
                .AsNoTracking()
                .Where(r =>
                    r.Retired == false &&
                    r.Municipality.Retired == false &&
                    userMunicipalities.Contains(r.MunicipalityID) &&
                    r.SysCreatedDate >= args.StartDate &&
                    r.SysCreatedDate <= args.EndDate.AddDays(1)
                )
                .OrderByDescending(r => r.SysCreatedDate);
        }

        private List<int> GetUserMunicipalities(Guid userGuid)
        {
            return _dc.UserMunicipalities
                .Where(r => r.UserID == userGuid)
                .Select(r => r.MunicipalityID)
                .ToList();
        }

        public IQueryable<Property> GetPropertiesForReport(SearchPropertyDTO args, IConfiguration configuration)
        {
            //Takes the end date into account
            var res = _dc.Properties
                .Include(r => r.PropertyCategory)
                .Include(r => r.Zone)
                .Include(r => r.OBS_RBA_SPF_PropertyType)
                .Include(r => r.OBS_RBA_SPF_Condition)
                .Include(r => r.PossessionBasis)
                .Include(r => r.OwnershipType)
                .Include(r => r.DisputeType)
                .Include(r => r.OwnershipRightsAcquisitionLegalBasis)
                .Include(r => r.RestrictedRealRightInformation)
                .Include(r => r.PropertyValues)
                .Include(r => r.AL_CreditRatingCategory)
                .Include(r => r.AL_LandType)
                .Include(r => r.BL_ConstructionRightsBasis)
                .Include(r => r.OBS_RBA_SPF_EnergyClass)
                .Include(r => r.PropertyInstalledInfrastructures)
                .ThenInclude(pii => pii.InstalledInfrastructure)
                //Property lease data / Property status
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyStatus)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PaymentFrequency)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyUseBasisDocument)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyUseBasis)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyUserGender)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyUserType)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.ContractTypeBasedOnUserStatus)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.ContractType)
                .AsNoTracking()
                .AsSplitQuery()
                .OrderByDescending(r => r.SysCreatedDate)
                .Where(r =>
                    r.Retired == false &&
                    r.MunicipalityID == args.MunicipalityID &&
                    r.SysCreatedDate >= args.StartDate &&
                    r.SysCreatedDate <= args.EndDate.AddDays(1)
                );
                

            var resCheck = res.ToList();
            // Filter by PropertyCategoryID
            if (args.PropertyCategoryID > 0)
            {
                res = res.Where(p => p.PropertyCategoryID == args.PropertyCategoryID);
            }
            // Filter by StatusID
            if (args.StatusID > 0)
            {
                res = res.Where(p => p.PropertyLeaseData.Count() != 0 && p.PropertyLeaseData.OrderByDescending(data => data.SysCreatedDate).FirstOrDefault().PropertyStatusID == args.StatusID);
            }

            if (args.UserGuid != Guid.Empty)
            {
                res = res.Where(p => p.SysCreatedByUserID == args.UserGuid);
            }

            //SearchTerm Address and Owner filtering done outside of query because of the encrypted fields
            var resList = res.ToList();

            if (!string.IsNullOrWhiteSpace(args.SearchTerm))
            {
                string searchTerm = args.SearchTerm.ToLower();

                resList = resList.Where(p =>
                    (p.LocationAddress != null && SEDManager.Unprotect(p.LocationAddress, configuration).ToLower().Contains(searchTerm)) ||
                    (p.KO != null && p.KO.ToLower().Contains(searchTerm)) ||
                    (p.KP != null && p.KP.ToLower().Contains(searchTerm)) ||
                    (p.PropertyOwner != null && SEDManager.Unprotect(p.PropertyOwner, configuration).ToLower().Contains(searchTerm))
                ).ToList();
            }

            return res;
        }

        public List<Property> GetPropertiesByType(GlobalEnum.PropertyCategories poljoprivrednoZemljiste, int municipalityId)
        {
            var res = _dc.Properties
                .Include(r => r.Zone)
                .Include(r => r.PropertyCategory)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyStatus)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(c => c.ContractType)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pf => pf.PaymentFrequency)
                .Include(r => r.OBS_RBA_SPF_PropertyType)
                .Include(r => r.OBS_RBA_SPF_Condition)
                .Include(r => r.PossessionBasis)
                .Include(r => r.OwnershipType)
                .Include(r => r.DisputeType)
                .Include(r => r.OwnershipRightsAcquisitionLegalBasis)
                .Include(r => r.RestrictedRealRightInformation)
                .Include(r => r.PropertyValues)
                .Include(r => r.AL_CreditRatingCategory)
                .Include(r => r.AL_LandType)
                .Include(r => r.BL_ConstructionRightsBasis)
                .Include(r => r.OBS_RBA_SPF_EnergyClass)
                .Include(r => r.PropertyInstalledInfrastructures)
                .ThenInclude(pii => pii.InstalledInfrastructure)
                .OrderByDescending(r => r.SysCreatedDate)
                .AsNoTracking()
                .Where(r =>
                    r.Retired == false && r.MunicipalityID == municipalityId &&
                    r.PropertyCategoryID == (int)poljoprivrednoZemljiste
                );

            return res.ToList(); ;
        }

        public List<Property> GetAllProperties(int municipalityId)
        {
            var res = _dc.Properties
                .Include(r => r.Zone)
                .Include(r => r.PropertyCategory)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pld => pld.PropertyStatus)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(c => c.ContractType)
                .Include(r => r.PropertyLeaseData)
                .ThenInclude(pf => pf.PaymentFrequency)
                .Include(r => r.OBS_RBA_SPF_PropertyType)
                .Include(r => r.OBS_RBA_SPF_Condition)
                .Include(r => r.PossessionBasis)
                .Include(r => r.OwnershipType)
                .Include(r => r.DisputeType)
                .Include(r => r.OwnershipRightsAcquisitionLegalBasis)
                .Include(r => r.RestrictedRealRightInformation)
                .Include(r => r.PropertyValues)
                .Include(r => r.AL_CreditRatingCategory)
                .Include(r => r.AL_LandType)
                .Include(r => r.BL_ConstructionRightsBasis)
                .Include(r => r.OBS_RBA_SPF_EnergyClass)
                .Include(r => r.PropertyInstalledInfrastructures)
                .ThenInclude(pii => pii.InstalledInfrastructure)
                .OrderByDescending(r => r.SysCreatedDate)
                .AsNoTracking()
                .Where(r =>
                    r.Retired == false && r.MunicipalityID == municipalityId
                );

            return res.ToList(); ;
        }
    }
}