﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.App
{
    public class PropertyLeaseDataRepository : IPropertyLeaseDataRepository
    {
        private readonly DatabaseContext _dc;

        public PropertyLeaseDataRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            var delete = _dc.PropertyLeaseData.FirstOrDefault(r => r.PropertyLeaseDataID == id);

            if (delete == null)
            {
                return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingItem };
            }

            try
            {
                delete.Retired = true;
                delete.SysLastModifiedByUserID = loggedUserId;
                delete.SysLastModifiedDate = DateTime.Now;

                _dc.SaveChanges();

                return new RetValue() { IsError = false, Guid = delete.PropertyID };
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }
        }

        public IQueryable<PropertyLeaseData> GetAllPropertyLeaseData()
        {
            return _dc.PropertyLeaseData
                .AsNoTracking()
                .Where(r => r.Retired == false);
        }


        public PropertyLeaseData? GetPropertyLeaseDataById(Guid id)
        {
            return _dc.PropertyLeaseData
                .AsNoTracking()
                .Include(r => r.Attachments.Where(a => !a.Retired))
                .FirstOrDefault(r => r.PropertyLeaseDataID.Equals(id) && r.Retired == false);
        }

        public (List<PropertyLeaseData>, int) GetPropertyLeaseDataGrid(SearchPropertyLeaseDataDTO args, int numberOfObjectsPerPage)
        {
            var res = _dc.PropertyLeaseData.Where(r => r.PropertyID.Equals(args.PropertyID) && r.Retired == false)
                .Include(r => r.PropertyStatus)
                .Include(r => r.PropertyUseBasisDocument)
                .Include(r => r.PropertyUseBasis)
                .Include(r => r.PropertyUserGender)
                .Include(r => r.PropertyUserType)
                .Include(r => r.ContractType)
                .Include(r => r.PaymentFrequency)
                .Include(r => r.ContractTypeBasedOnUserStatus)
                .Include(r => r.Attachments.Where(a => !a.Retired));

            var ret = res.OrderByDescending(r => r.SysCreatedDate);

            return (ret.ToList(), ret.Count());
        }

        public RetValue Save(PropertyLeaseData entity, GlobalEnum.CrudOperation operation)
        {
            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.PropertyLeaseData.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;
                _dc.Entry(entity).Property(r => r.PropertyLeaseDataID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
                _dc.Entry(entity).Property(r => r.Retired).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.PropertyLeaseData.Add(entity);
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Guid = entity.PropertyLeaseDataID };
        }
    }
}
