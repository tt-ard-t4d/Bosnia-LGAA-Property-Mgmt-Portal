﻿using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Contracts.Utils;
using PropertyManagementPortal.Domain.Entities.Utils;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Infrastructure.Data.Repositories.Utils
{
    public class AttachmentRepository : IAttachmentRepository
    {
        private DatabaseContext _dc;

        public AttachmentRepository(DatabaseContext dc)
        {
            _dc = dc;
        }


        public RetValue DeleteFile(Guid fileId)
        {
            var file = _dc.Attachments.FirstOrDefault(r => r.AzureFileID == fileId);
            if (file == null)
            {
                return new RetValue { IsError = true, ErrorMessage = "File not found" };
            }
            file.Retired = true;
            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue();
        }

        public RetValue Save(AttachedFiles entity)
        {
            _dc.Attachments.Add(entity);

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }
            return new RetValue() { Id = entity.AttachedFileID };
        }

        public AttachmentShowDTO GetFileFromDB(Guid fileId)
        {
            var file = _dc.Attachments.AsNoTracking().FirstOrDefault(r => r.AzureFileID == fileId);
            if (file == null)
                return new AttachmentShowDTO();
            return new AttachmentShowDTO()
            {
                Id = file.AzureFileID,
                Name = file.Title,
                MimeType = file.ContentType,
                Link = file.Link
            };
        }

    }
}
