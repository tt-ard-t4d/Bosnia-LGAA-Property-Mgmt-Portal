﻿
using Domain.Contracts;
using Domain.Entities.Utils;
using DTO.Utils;
using Infrastructure.Mappings.Utils;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Data.Repositories
{
    public class AuditLogEnumerationRepository : IAuditLogEnumerationRepository
    {
        private DatabaseContext dc;
        public AuditLogEnumerationRepository(DatabaseContext ctx)
        {
            dc = ctx;

        }

        /// <summary>
        /// Get item from AuditLogEnumeration
        /// </summary>
        /// <returns>Mapped List AuditLogEnumeration items</returns>
        public List<AuditLogEnumerationDTO> GetAllAuditLogEnumeration()
        {
            List<AuditLogEnumerationDTO> auditLogEnumNew = new List<AuditLogEnumerationDTO>();
            var auditLogEnumMapper = new AuditLogEnumerationMapper();

            List<AuditLogEnumeration> auditLogEnum = dc.AuditLogEnumerations.AsNoTracking().ToList();

            if (auditLogEnum != null)
            {
                foreach (var item in auditLogEnum)
                {
                    auditLogEnumNew.Add(auditLogEnumMapper.MapAuditLogEnumeration(item));
                }
            }

            return auditLogEnumNew;

        }

        /// <summary>
        /// Get item AuditLogEnumeration by id 
        /// </summary>
        /// <param name="id">ID AuditLogEnumeration</param>
        /// <returns>Mapped AuditLogEnumeration item</returns>
        public AuditLogEnumerationDTO GetAuditLogEnumerationItem(int? id)
        {
            var auditLogEnumMapper = new AuditLogEnumerationMapper();
            AuditLogEnumeration auditLogEnum = dc.AuditLogEnumerations.AsNoTracking().FirstOrDefault(s => s.AuditLogEnumerationID == id);

            if (auditLogEnum != null)
                return auditLogEnumMapper.MapAuditLogEnumeration(auditLogEnum);
            else
                return auditLogEnumMapper.MapAuditLogEnumeration();
        }

        public void SaveAuditLogEnumeration(AuditLogEnumerationDTO auditLogEnum)
        {
            var auditLogEnumMapper = new AuditLogEnumerationMapper();
            AuditLogEnumeration _auditLogEnum = auditLogEnumMapper.MapAuditLogEnumeration(auditLogEnum);

            if (_auditLogEnum.AuditLogEnumerationID > 0)
            {
                _auditLogEnum.SysLastModifiedDate = DateTime.Now;
                //_auditLogEnum.SysLastModifiedByUserID = loggedUserId;
                _auditLogEnum.SysLastModifiedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f");
                dc.AuditLogEnumerations.Attach(_auditLogEnum);
                dc.Entry(_auditLogEnum).State = EntityState.Modified;
            }
            else
            {
                dc.AuditLogEnumerations.Add(_auditLogEnum);
            }

            dc.SaveChanges();
        }

      
    }
}
