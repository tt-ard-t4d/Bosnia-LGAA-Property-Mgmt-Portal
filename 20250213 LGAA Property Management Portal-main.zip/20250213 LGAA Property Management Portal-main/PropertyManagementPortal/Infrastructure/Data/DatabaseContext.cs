﻿using Domain.Entities.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.ValueGeneration;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.Domain.Entities.CodeBooks;
using PropertyManagementPortal.Domain.Entities.Utils;
using PropertyManagementPortal.Infrastructure.Data;
using PropertyManagementPortal.Infrastructure.Models.StoredProcedures;
using System.Reflection;


namespace Infrastructure.Data
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions options) : base(options)
        {
            this.ChangeTracker.LazyLoadingEnabled = false;
        }

        //UTILS

        public DbSet<EmailNotification> EmailNotifications { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }
        public DbSet<AuditLogEnumeration> AuditLogEnumerations { get; set; }
        public DbSet<AttachedFiles> Attachments { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<PropertyManagementPortal.Domain.Entities.Action> Actions { get; set; }
        public DbSet<ActionHistory> ActionsHistory { get; set; }
        public DbSet<UserGroupUserRel> UserGroupUsers { get; set; }
        public DbSet<UserGroupActionRel> UserGroupActions { get; set; }
        public DbSet<UserActionRel> UserActions { get; set; }

        //APP
        public DbSet<Entity> Entities { get; set; }
        public DbSet<Municipality> Municipalities { get; set; }
        public DbSet<UserMunicipalityRel> UserMunicipalities { get; set; }
        public DbSet<Property> Properties { get; set; }
        public DbSet<DisputeType> DisputeTypes { get; set; }
        public DbSet<OwnershipRightsAcquisitionLegalBasis> OwnershipRightsAcquisitionLegalBases { get; set; }
        public DbSet<OwnershipType> OwnershipTypes { get; set; }
        public DbSet<PossessionBasis> PossessionBases { get; set; }
        public DbSet<PropertyCategory> PropertyCategories { get; set; }
        public DbSet<RestrictedRealRightInformation> RestrictedRealRightInformation { get; set; }
        public DbSet<PropertyStatus> PropertyStatuses { get; set; }
        public DbSet<PropertyUseBasisDocument> PropertyUseBasisDocuments { get; set; }
        public DbSet<PropertyUseBasis> PropertyUseBases { get; set; }
        public DbSet<PropertyLeaseData> PropertyLeaseData { get; set; }
        public DbSet<PropertyValue> PropertyValues { get; set; }
        public DbSet<BL_ConstructionRightsBasis> BL_ConstructionRightsBases { get; set; }
        public DbSet<AL_CreditRatingCategory> AL_CreditRatingCategories { get; set; }
        public DbSet<AL_LandType> AL_LandTypes { get; set; }
        public DbSet<OBS_RBA_SPF_PropertyType> OBS_PropertyTypes { get; set; }
        public DbSet<OBS_RBA_SPF_EnergyClass> OBS_RBA_SPF_EnergyClasses { get; set; }
        public DbSet<OBS_RBA_SPF_Condition> OBS_RBA_SPF_Conditions { get; set; }
        public DbSet<PropertyUserGender> PropertyUserGenders { get; set; }
        public DbSet<PropertyUserType> PropertyUserTypes { get; set; }
        public DbSet<ContractTypeBasedOnUserStatus> ContractTypesBasedOnUserStatus { get; set; }
        public DbSet<ContractType> ContractTypes { get; set; }
        public DbSet<PaymentFrequency> PaymentFrequencies { get; set; }
        public DbSet<InstalledInfrastructure> InstalledInfrastructure { get; set; }
        public DbSet<PropertyInstalledInfrastructureRel> PropertyInstalledInfrastructureRel { get; set; }

        public DbSet<SPF_PropertyType> SPF_PropertyTypes { get; set; }
        public DbSet<Zone> Zones { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region <!--- Configure stored procedure return models --->

            modelBuilder.Entity<GetUserActions>().HasNoKey().ToView(null);

            #endregion

            #region <!--- Configure Primary Keys --->

            modelBuilder.Entity<PropertyManagementPortal.Domain.Entities.Action>(r =>
            {
                r.ToTable("Actions", "dbo", r =>
                {
                    r.HasTrigger("ActionsHistoryInsert");
                    r.HasTrigger("ActionsHistoryUpdate");
                });

                r.HasKey(r => r.ActionID);
                r.HasIndex(r => r.ActionName).IsUnique();
                r.HasIndex(r => r.ActionEnumerationName).IsUnique();
                r.Property(r => r.ActionID).ValueGeneratedOnAdd();
            });


            modelBuilder.Entity<User>(r =>
            {
                r.ToTable("Users", "dbo");
                r.HasKey(r => r.UserID);
                r.Property(r => r.UserID).HasValueGenerator<GuidValueGenerator>();
                r.Property(r => r.EmailCode).HasValueGenerator<GuidValueGenerator>();
            });

            modelBuilder.Entity<UserActionRel>(r =>
            {
                r.ToTable("UserActionRel", "dbo");
                r.HasKey(r => r.UserAndActionID);
                r.Property(r => r.UserAndActionID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserGroup>(r =>
            {
                r.ToTable("UserGroups", "dbo");
                r.HasKey(r => r.UserGroupID);
                r.Property(r => r.UserGroupID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserGroupActionRel>(r =>
            {
                r.ToTable("UserGroupActionRel", "dbo");
                r.HasKey(r => r.UserGroupAndActionID);
                r.Property(r => r.UserGroupAndActionID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserGroupUserRel>(r =>
            {
                r.ToTable("UserGroupUserRel", "dbo");
                r.HasKey(r => r.UserAndGroupID);
                r.Property(r => r.UserAndGroupID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<AuditLog>(r =>
            {
                r.ToTable("AuditLogs", "dbo");
                r.HasKey(r => r.AuditLogID);
                r.Property(r => r.AuditLogID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<AuditLogEnumeration>(r =>
            {
                r.ToTable("AuditLogEnumerations", "dbo");
                r.HasKey(r => r.AuditLogEnumerationID);
                r.Property(r => r.AuditLogEnumerationID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<EmailNotification>(r =>
            {
                r.ToTable("EmailNotifications", "dbo");
                r.HasKey(r => r.EmailNotificationID);
                r.Property(r => r.EmailNotificationID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<AttachedFiles>(r =>
            {
                r.ToTable("AttachedFiles", "dbo");
                r.HasKey(r => r.AttachedFileID);
                r.Property(r => r.AttachedFileID).ValueGeneratedOnAdd();
                r.Property(r => r.FileName).HasMaxLength(250);
                r.Property(r => r.Extension).HasMaxLength(50);
                r.Property(r => r.Title).HasMaxLength(1500);
            });


            modelBuilder.Entity<Entity>(r =>
            {
                r.ToTable("Entities", "mm");
                r.HasKey(r => r.EntityID);
            });

            modelBuilder.Entity<Municipality>(r =>
            {
                r.ToTable("Municipalities", "mm");
                r.HasKey(r => r.MunicipalityID);
                r.HasIndex(r => r.Slug).IsUnique();
                r.Property(r => r.MunicipalityID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserMunicipalityRel>(r =>
            {
                r.ToTable("UserMunicipalityRel", "mm");
                r.HasKey(r => r.UserAndMunicipalityID);
                r.Property(r => r.UserAndMunicipalityID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<LocalGovernmentUnit>(r =>
            {
                r.ToTable("LocalGovernmentUnits", "mm");
                r.HasKey(r => r.LocalGovernmentUnitID);
            });

            modelBuilder.Entity<AL_CreditRatingCategory>(r =>
            {
                r.ToTable("AL_CreditRatingCategories", "pmp");
                r.HasKey(r => r.AL_CreditRatingCategoryID);
            });

            modelBuilder.Entity<AL_LandType>(r =>
            {
                r.ToTable("AL_LandTypes", "pmp");
                r.HasKey(r => r.AL_LandTypeID);
            });

            modelBuilder.Entity<BL_ConstructionRightsBasis>(r =>
            {
                r.ToTable("BL_ConstructionRightsBases", "pmp");
                r.HasKey(r => r.BL_ConstructionRightsBasisID);
            });

            modelBuilder.Entity<DisputeType>(r =>
            {
                r.ToTable("DisputeTypes", "pmp");
                r.HasKey(r => r.DisputeTypeID);
            });

            modelBuilder.Entity<OBS_RBA_SPF_PropertyType>(r =>
            {
                r.ToTable("OBS_RBA_SPF_PropertyTypes", "pmp");
                r.HasKey(r => r.OBS_RBA_SPF_PropertyTypeID);
            });

            modelBuilder.Entity<OBS_RBA_SPF_EnergyClass>(r =>
            {
                r.ToTable("OBS_RBA_SPF_EnergyClasses", "pmp");
                r.HasKey(r => r.OBS_RBA_SPF_EnergyClassID);
            });

            modelBuilder.Entity<Zone>(r =>
            {
                r.ToTable("Zones", "pmp");
                r.HasKey(r => r.Id);
            });

            modelBuilder.Entity<SPF_PropertyType>(r =>
            {
                r.ToTable("SPF_PropertyTypes", "pmp");
                r.HasKey(r => r.Id);
            });

            modelBuilder.Entity<OwnershipRightsAcquisitionLegalBasis>(r =>
                {
                    r.ToTable("OwnershipRightsAcquisitionLegalBases", "pmp");
                    r.HasKey(r => r.OwnershipRightsAcquisitionLegalBasisID);
                });

            modelBuilder.Entity<OwnershipType>(r =>
            {
                r.ToTable("OwnershipTypes", "pmp");
                r.HasKey(r => r.OwnershipTypeID);
            });

            modelBuilder.Entity<PossessionBasis>(r =>
            {
                r.ToTable("PossessionBases", "pmp");
                r.HasKey(r => r.PossessionBasisID);
            });

            modelBuilder.Entity<Property>(r =>
            {
                r.ToTable("Properties", "pmp");
                r.HasKey(r => r.PropertyID);
                r.Property(r => r.PropertyID).HasValueGenerator(typeof(SequentialGuidValueGenerator));
                r.Property(r => r.PropertyDisplayID).ValueGeneratedOnAdd().Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Throw);
                r.Property(r => r.Comment).HasMaxLength(65000);
            });

            modelBuilder.Entity<PropertyCategory>(r =>
            {
                r.ToTable("PropertyCategories", "pmp");
                r.HasKey(r => r.PropertyCategoryID);
            });

            modelBuilder.Entity<OBS_RBA_SPF_Condition>(r =>
            {
                r.ToTable("OBS_RBA_SPF_Conditions", "pmp");
                r.HasKey(r => r.OBS_RBA_SPF_ConditionID);
            });

            modelBuilder.Entity<RestrictedRealRightInformation>(r =>
            {
                r.ToTable("RestrictedRealRightInformation", "pmp");
                r.HasKey(r => r.RestrictedRealRightInformationID);
            });

            modelBuilder.Entity<PropertyLeaseData>(r =>
            {
                r.ToTable("PropertyLeaseData", "pmp");
                r.HasKey(r => r.PropertyLeaseDataID);
                r.Property(r => r.PropertyLeaseDataID).HasValueGenerator(typeof(SequentialGuidValueGenerator));
            });

            modelBuilder.Entity<PropertyStatus>(r =>
            {
                r.ToTable("PropertyStatuses", "pmp");
                r.HasKey(r => r.PropertyStatusID);
            });

            modelBuilder.Entity<PropertyUseBasisDocument>(r =>
            {
                r.ToTable("PropertyUseBasisDocuments", "pmp");
                r.HasKey(r => r.PropertyUseBasisDocumentID);
            });

            modelBuilder.Entity<PropertyUseBasis>(r =>
            {
                r.ToTable("PropertyUseBases", "pmp");
                r.HasKey(r => r.PropertyUseBasisID);
            });

            modelBuilder.Entity<PropertyUserGender>(r =>
            {
                r.ToTable("PropertyUserGenders", "pmp");
                r.HasKey(r => r.PropertyUserGenderID);
            });

            modelBuilder.Entity<PropertyUserType>(r =>
            {
                r.ToTable("PropertyUserTypes", "pmp");
                r.HasKey(r => r.PropertyUserTypeID);
            });

            modelBuilder.Entity<ContractTypeBasedOnUserStatus>(r =>
            {
                r.ToTable("ContractTypesBasedOnUserStatus", "pmp");
                r.HasKey(r => r.ContractTypeBasedOnUserStatusID);
            });

            modelBuilder.Entity<ContractType>(r =>
            {
                r.ToTable("ContractTypes", "pmp");
                r.HasKey(r => r.ContractTypeID);
            });

            modelBuilder.Entity<PropertyValue>(r =>
            {
                r.ToTable("PropertyValues", "pmp");
                r.HasKey(r => r.PropertyValueID);
                r.Property(r => r.PropertyValueID).HasValueGenerator(typeof(SequentialGuidValueGenerator));
            });

            modelBuilder.Entity<PaymentFrequency>(r =>
            {
                r.ToTable("PaymentFrequencies", "pmp");
                r.HasKey(r => r.PaymentFrequencyID);
            });

            modelBuilder.Entity<InstalledInfrastructure>(r =>
            {
                r.ToTable("InstalledInfrastructure", "pmp");
                r.HasKey(r => r.InstalledInfrastructureID);
            });

            modelBuilder.Entity<PropertyInstalledInfrastructureRel>(r =>
            {
                r.ToTable("PropertyInstalledInfrastructureRel", "pmp");
                r.HasKey(r => r.PropertyInstalledInfrastructureID);
                r.Property(r => r.PropertyInstalledInfrastructureID).ValueGeneratedOnAdd();
            });

            #endregion

            #region <!--- Configure one-to-many relations --->

            modelBuilder.Entity<Entity>()
                .HasMany(r => r.Municipalities)
                .WithOne(r => r.Entity)
                .HasForeignKey(r => r.EntityID);

            modelBuilder.Entity<LocalGovernmentUnit>()
                .HasMany(r => r.Municipalities)
                .WithOne(r => r.LocalGovernmentUnit)
                .HasForeignKey(r => r.LocalGovernmentUnitID);

            modelBuilder.Entity<PropertyCategory>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.PropertyCategory)
                .HasForeignKey(r => r.PropertyCategoryID);

            modelBuilder.Entity<PossessionBasis>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.PossessionBasis)
                .HasForeignKey(r => r.PossessionBasisID);

            modelBuilder.Entity<OwnershipType>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.OwnershipType)
                .HasForeignKey(r => r.OwnershipTypeID);

            modelBuilder.Entity<DisputeType>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.DisputeType)
                .HasForeignKey(r => r.DisputeTypeID);

            modelBuilder.Entity<OwnershipRightsAcquisitionLegalBasis>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.OwnershipRightsAcquisitionLegalBasis)
                .HasForeignKey(r => r.OwnershipRightsAcquisitionLegalBasisID);

            modelBuilder.Entity<RestrictedRealRightInformation>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.RestrictedRealRightInformation)
                .HasForeignKey(r => r.RestrictedRealRightInformationID);

            modelBuilder.Entity<AL_CreditRatingCategory>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.AL_CreditRatingCategory)
                .HasForeignKey(r => r.AL_CreditRatingCategoryID);

            modelBuilder.Entity<AL_LandType>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.AL_LandType)
                .HasForeignKey(r => r.AL_LandTypeID);

            modelBuilder.Entity<BL_ConstructionRightsBasis>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.BL_ConstructionRightsBasis)
                .HasForeignKey(r => r.BL_ConstructionRightsBasisID);

            modelBuilder.Entity<OBS_RBA_SPF_PropertyType>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.OBS_RBA_SPF_PropertyType)
                .HasForeignKey(r => r.OBS_RBA_SPF_PropertyTypeID);

            modelBuilder.Entity<OBS_RBA_SPF_EnergyClass>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.OBS_RBA_SPF_EnergyClass)
                .HasForeignKey(r => r.OBS_RBA_SPF_EnergyClassID);

            modelBuilder.Entity<OBS_RBA_SPF_Condition>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.OBS_RBA_SPF_Condition)
                .HasForeignKey(r => r.OBS_RBA_SPF_ConditionID);

            modelBuilder.Entity<PropertyStatus>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.PropertyStatus)
               .HasForeignKey(r => r.PropertyStatusID);

            modelBuilder.Entity<PropertyUseBasisDocument>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.PropertyUseBasisDocument)
               .HasForeignKey(r => r.PropertyUseBasisDocumentID);

            modelBuilder.Entity<PropertyUseBasis>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.PropertyUseBasis)
               .HasForeignKey(r => r.PropertyUseBasisID);

            modelBuilder.Entity<PropertyUserGender>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.PropertyUserGender)
               .HasForeignKey(r => r.PropertyUserGenderID);

            modelBuilder.Entity<PropertyUserType>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.PropertyUserType)
               .HasForeignKey(r => r.PropertyUserTypeID);

            modelBuilder.Entity<ContractTypeBasedOnUserStatus>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.ContractTypeBasedOnUserStatus)
               .HasForeignKey(r => r.ContractTypeBasedOnUserStatusID);

            modelBuilder.Entity<ContractType>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.ContractType)
               .HasForeignKey(r => r.ContractTypeID);

            modelBuilder.Entity<PaymentFrequency>()
               .HasMany(r => r.PropertyLeaseData)
               .WithOne(r => r.PaymentFrequency)
               .HasForeignKey(r => r.PaymentFrequencyID);

            modelBuilder.Entity<Property>()
                .HasMany(r => r.PropertyLeaseData)
                .WithOne(r => r.Property)
                .HasForeignKey(r => r.PropertyID);

            modelBuilder.Entity<Property>()
                .HasMany(r => r.PropertyValues)
                .WithOne(r => r.Property)
                .HasForeignKey(r => r.PropertyID);

            modelBuilder.Entity<Zone>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.Zone)
                .HasForeignKey(r => r.ZoneId);

            modelBuilder.Entity<SPF_PropertyType>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.SPF_PropertyType)
                .HasForeignKey(r => r.SPF_PropertyTypeID);

            modelBuilder.Entity<Property>()
                .HasMany(r => r.Attachments)
                .WithOne(r => r.Property)
                .HasForeignKey(r => r.PropertyID);

            modelBuilder.Entity<PropertyLeaseData>()
                .HasMany(r => r.Attachments)
                .WithOne(r => r.PropertyLeaseData)
                .HasForeignKey(r => r.PropertyLeaseDataID);

            modelBuilder.Entity<Municipality>()
                .HasMany(r => r.Properties)
                .WithOne(r => r.Municipality)
                .HasForeignKey(r => r.MunicipalityID);

            #endregion

            #region <!--- Configure many-to-many relations --->

            //Adding many-to-many relation to UserRoleUserRel
            modelBuilder.Entity<UserGroupUserRel>()
                .HasOne(ur => ur.UserGroup)
                .WithMany(r => r.UserGroupUsers)
                .HasForeignKey(ur => ur.UserGroupID);
            modelBuilder.Entity<UserGroupUserRel>()
                .HasOne(ur => ur.User)
                .WithMany(r => r.UserGroupUsers)
                .HasForeignKey(ur => ur.UserID);

            //Adding many-to-many relation to UserGroupActionRel
            modelBuilder.Entity<UserGroupActionRel>()
                .HasOne(ur => ur.UserGroup)
                .WithMany(r => r.UserGroupActions)
                .HasForeignKey(ur => ur.UserGroupID);
            modelBuilder.Entity<UserGroupActionRel>()
                .HasOne(ur => ur.Action)
                .WithMany(r => r.UserGroupActions)
                .HasForeignKey(ur => ur.ActionID);

            //Adding many-to-many relation to UserActionRel
            modelBuilder.Entity<UserActionRel>()
                .HasOne(ur => ur.User)
                .WithMany(r => r.UserActions)
                .HasForeignKey(ur => ur.UserID);
            modelBuilder.Entity<UserActionRel>()
                .HasOne(ur => ur.Action)
                .WithMany(r => r.UserActions)
                .HasForeignKey(ur => ur.ActionID);

            //Adding many-to-many relation to UserMunicipalityRel
            modelBuilder.Entity<UserMunicipalityRel>()
                .HasOne(r => r.User)
                .WithMany(r => r.UserMunicipalities)
                .HasForeignKey(r => r.UserID);
            modelBuilder.Entity<UserMunicipalityRel>()
                .HasOne(r => r.Municipality)
                .WithMany(r => r.UserMunicipalities)
                .HasForeignKey(r => r.MunicipalityID);

            // Adding many-to-many relation to PropertyInstalledInfrastructureRel
            modelBuilder.Entity<PropertyInstalledInfrastructureRel>()
                .HasOne(r => r.Property)
                .WithMany(r => r.PropertyInstalledInfrastructures)
                .HasForeignKey(r => r.PropertyID);

            modelBuilder.Entity<PropertyInstalledInfrastructureRel>()
                .HasOne(r => r.InstalledInfrastructure)
                .WithMany(r => r.PropertyInstalledInfrastructures)
                .HasForeignKey(r => r.InstalledInfrastructureID);


            #endregion


            Assembly assemblyWithConfigurations = GetType().Assembly;
            modelBuilder.ApplyConfigurationsFromAssembly(assemblyWithConfigurations);


            //Removing cascade delete
            foreach (var relationship in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }


            ConfigureHistoryTables(modelBuilder);

            modelBuilder.ConfigureDefaultFields();
            modelBuilder.Seed();
            modelBuilder.SeedPMPData();
            modelBuilder.SeedDropdownData();


            base.OnModelCreating(modelBuilder);
        }

        private void ConfigureHistoryTables(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ActionHistory>(r =>
            {
                r.HasKey(r => r.HistoryID);
                r.Property(r => r.HistoryID).ValueGeneratedOnAdd();
                r.ToTable("ActionsHistory", "dbo");
            });
        }
    }
}
