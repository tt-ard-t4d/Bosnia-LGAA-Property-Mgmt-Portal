﻿using Microsoft.EntityFrameworkCore;

namespace PropertyManagementPortal.Infrastructure.Data
{
    public static class EntityFieldTypeConfiguration
    {
        public static void ConfigureDefaultFields(this ModelBuilder builder)
        {
            // Set all date to datetime
            var dates = builder.Model.GetEntityTypes().SelectMany(t => t.GetProperties()).Where(p => p.ClrType == typeof(DateTime));
            const string DateTimeConfig = "timestamp";
            foreach (var property in dates)
                property.SetColumnType(DateTimeConfig);

            var nullDates = builder.Model.GetEntityTypes().SelectMany(t => t.GetProperties()).Where(p => p.ClrType == typeof(DateTime?));
            foreach (var property in nullDates)
                property.SetColumnType(DateTimeConfig);

            // Set Decimal Precision
            var decimals = builder.Model.GetEntityTypes().SelectMany(t => t.GetProperties()).Where(p => p.ClrType == typeof(decimal));
            const string DecimalConfig = "decimal(18, 2)";
            foreach (var property in decimals)
                property.SetColumnType(DecimalConfig);
        }
    }
}
