﻿using Domain.Entities.Utils;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.Domain.Entities.CodeBooks;
using Action = PropertyManagementPortal.Domain.Entities.Action;

namespace PropertyManagementPortal.Infrastructure.Data
{
    public static class ModelBuilderExtensions
    {

        
        public static void Seed(this ModelBuilder builder)
        {
            DateTime defaultCreateDate = new DateTime(2024,1,1);
            builder.Entity<UserGroup>(ur =>
            {
                ur.HasData(
                    new UserGroup()
                    {
                        UserGroupID = 1,
                        Name = "System Administrator",
                        SysCreatedDate = defaultCreateDate,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        Retired = false
                    },
                    new UserGroup()
                    {
                        UserGroupID = 2,
                        Name = "LGU Administrator",
                        SysCreatedDate = defaultCreateDate,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        Retired = false
                    },
                    new UserGroup()
                    {
                        UserGroupID = 3,
                        Name = "LGU User",
                        SysCreatedDate = defaultCreateDate,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        Retired = false
                    },
                    new UserGroup()
                    {
                        UserGroupID = 4,
                        Name = "LGAA Consultant",
                        SysCreatedDate = defaultCreateDate,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        Retired = false
                    }
                );
            });

            builder.Entity<Action>(ur =>
            {
                ur.HasData(
                    new Action
                    {
                        ActionID = 1,
                        ActionName = "Create User",
                        ActionEnumerationName = "ADMIN_USER_CREATE",
                        Description = "",
                        Retired = false,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = defaultCreateDate
                    },
                    new Action
                    {
                        ActionID = 2,
                        ActionName = "View User",
                        ActionEnumerationName = "ADMIN_USER_READ",
                        Description = "",
                        Retired = false,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = defaultCreateDate
                    },
                    new Action
                    {
                        ActionID = 3,
                        ActionName = "Edit User",
                        ActionEnumerationName = "ADMIN_USER_EDIT",
                        Description = "",
                        Retired = false,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = defaultCreateDate
                    },
                    new Action
                    {
                        ActionID = 4,
                        ActionName = "Delete User",
                        ActionEnumerationName = "ADMIN_USER_DELETE",
                        Description = "",
                        Retired = false,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = defaultCreateDate
                    },
                    new Action
                    {
                        ActionID = 5,
                        ActionName = "Users Overview",
                        ActionEnumerationName = "ADMIN_USERS_OVERVIEW",
                        Description = "",
                        Retired = false,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = defaultCreateDate
                    }
                );
            });

            builder.Entity<UserGroupActionRel>(ur =>
            {
                ur.HasData(
                    new UserGroupActionRel { UserGroupAndActionID = 1, UserGroupID = 1, ActionID = 1, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 2, UserGroupID = 1, ActionID = 2, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 3, UserGroupID = 1, ActionID = 3, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 4, UserGroupID = 1, ActionID = 4, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 5, UserGroupID = 1, ActionID = 5, Retired = false }
                );
            });

            builder.Entity<UserActionRel>(ur =>
            {
                ur.HasData(
                    new UserActionRel
                    {
                        UserAndActionID = 1,
                        UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        ActionID = 5
                    },
                    new UserActionRel
                    { UserAndActionID = 2, UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), ActionID = 4 }
                );
            });

            builder.Entity<User>().HasData(
                new User()
                {
                    UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    FirstNameEnc = "vOIUBnFT5Y809QUJqH4AzQ==",
                    LastNameEnc = "vOIUBnFT5Y809QUJqH4AzQ==",
                    UserNameEnc = "1/ZVbp32LhD77H7MGNgKmw==",
                    EmailEnc = "St6/v49lrqKXW5W7ytqLHA==",
                    PasswordHash =
                        "5367F0A6E0BFBA425D5584C4B8A0F8A872B4885C90783FD698060A483146D29DD352665D9A220DDDD5EEE2D82DDCB06C213AA36381CAEF4E6B5F00CE3843FD45",
                    PasswordSalt =
                        "gWnj99aObNTLFxxcohCDq1dAaFXu1J1gTpZCYEa7pcATr/xD48yzNcfG96c+WhcZBIkEa7rKpwzvaG2wsT3LqQ==",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    EmailCode = new Guid("ef496512-1eaf-4d17-9ba1-422cffb755a6"),
                    SysCreatedDate = defaultCreateDate,
                    ValidFrom = defaultCreateDate,
                    ValidTo = defaultCreateDate.AddDays(100000),
                    LanguageId = 1
                }
            );

            builder.Entity<UserGroupUserRel>().HasData(
                new UserGroupUserRel()
                {
                    UserAndGroupID = 1,
                    UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    UserGroupID = 1,
                    Retired = false
                }
            );


            builder.Entity<EmailNotification>().HasData(
                new EmailNotification()
                {
                    EmailNotificationID = (int)GlobalEnum.Email.EmailPasswordSetup,
                    EmailDescription = "EmailPasswordSetup",
                    EmailSubject = "Setup your password",
                    EmailText =
                        "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n        /* Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Registrovani ste na Portalu za upravljanje imovine kao korisnik.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <b><Username></b>\r\n                                                    \r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Ljubazno Vas molimo da kreirate Vašu lozinku za pristup Portalu. Lozinku će te kreirati tako što kliknete na sljedeći <a href=\"<ConfirmationLink>\">link</a> i slijedite uputstva sistema.\r\n                                                    <br>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>",
                    SysDateCreated = defaultCreateDate,
                    SysCreatedByUserID = 1,
                    EmailStatus = (short)GlobalEnum.EmailStatus.Actual
                },
                new EmailNotification()
                {
                    EmailNotificationID = (int)GlobalEnum.Email.EmailPasswordReset,
                    EmailDescription = "EmailPasswordReset",
                    EmailSubject = "Reset your password",
                    EmailText =
                        "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n            /*\r\n                                  Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Poštovani <Name>,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Kako bi izvršili promjenu Vaše lozinke molimo Vas da pratite sljedeći <a href=\"<ConfirmationLink>\">LINK</a>.\r\n                                                    <br>\r\n                                                    Vaše korisničko ime je: <Username>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>",
                    SysDateCreated = defaultCreateDate,
                    SysCreatedByUserID = 1,
                    EmailStatus = (short)GlobalEnum.EmailStatus.Actual
                }
            );

            builder.Entity<AuditLogEnumeration>().HasData(
                new AuditLogEnumeration
                {
                    AuditLogEnumerationID = 1,
                    AuditLogEnumerationDescription = "Log-in",
                    AuditLogEnumerationText = "User <username> logged in.",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    SysLastModifiedByUserID = null,
                    SysLastModifiedDate = null,
                    Retired = false
                },
                new AuditLogEnumeration
                {
                    AuditLogEnumerationID = 2,
                    AuditLogEnumerationDescription = "Log-out",
                    AuditLogEnumerationText = "User <username> logged out.",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    SysLastModifiedByUserID = null,
                    SysLastModifiedDate = null,
                    Retired = false
                },
                new AuditLogEnumeration
                {
                    AuditLogEnumerationID = 3,
                    AuditLogEnumerationDescription = "User registration",
                    AuditLogEnumerationText = "User <username> has been registered.",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    SysLastModifiedByUserID = null,
                    SysLastModifiedDate = null,
                    Retired = false
                },
                new AuditLogEnumeration
                {
                    AuditLogEnumerationID = 4,
                    AuditLogEnumerationDescription = "User creation",
                    AuditLogEnumerationText = "User <username> has been created.",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    SysLastModifiedByUserID = null,
                    SysLastModifiedDate = null,
                    Retired = false
                },
                new AuditLogEnumeration
                {
                    AuditLogEnumerationID = 5,
                    AuditLogEnumerationDescription = "Email notifications sent",
                    AuditLogEnumerationText = "Email notification <emailNotificationName> has been sent to <username>.",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    SysLastModifiedByUserID = null,
                    SysLastModifiedDate = null,
                    Retired = false
                },
                new AuditLogEnumeration
                {
                    AuditLogEnumerationID = 6,
                    AuditLogEnumerationDescription = "Forgotten password reset",
                    AuditLogEnumerationText = "User <username> requested password reset.",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    SysLastModifiedByUserID = null,
                    SysLastModifiedDate = null,
                    Retired = false
                }
            );


            var key = "MySecretPassword";
        }

        public static void SeedPMPData(this ModelBuilder builder)
        {
            Guid defaultUserId = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f");
            DateTime defaultCreateDate = new DateTime(2024, 1, 1);

            #region PoliticalStructureLelvels
            builder.Entity<Entity>().HasData(

                new Entity()
                {
                    EntityID = 1,
                    EntityName = "Federacija Bosne i Hercegovine",
                    Retired = false
                },
                new Entity()
                {
                    EntityID = 2,
                    EntityName = "Republika Srpska",
                    Retired = false
                }
            );

            builder.Entity<LocalGovernmentUnit>().HasData(

                new LocalGovernmentUnit()
                {
                    LocalGovernmentUnitID = 1,
                    LocalGovernmentUnitName = "Općina"
                },
                new LocalGovernmentUnit()
                {
                    LocalGovernmentUnitID = 2,
                    LocalGovernmentUnitName = "Grad"
                }
            );

            #endregion

            #region Municipalities
            builder.Entity<Municipality>().HasData(
                new Municipality()
                {
                    MunicipalityID = 1,
                    EntityID = 2,
                    Slug = "trebinje",
                    MunicipalityName = "Trebinje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 2,
                    EntityID = 2,
                    Slug = "bileca",
                    MunicipalityName = "Bileća",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 3,
                    EntityID = 2,
                    Slug = "ljubinje",
                    MunicipalityName = "Ljubinje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 4,
                    EntityID = 2,
                    Slug = "berkovici",
                    MunicipalityName = "Berkovići",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 5,
                    EntityID = 2,
                    Slug = "gacko",
                    MunicipalityName = "Gacko",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 6,
                    EntityID = 2,
                    Slug = "nevesinje",
                    MunicipalityName = "Nevesinje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 7,
                    EntityID = 2,
                    Slug = "istocni-mostar",
                    MunicipalityName = "Istočni Mostar",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 8,
                    EntityID = 2,
                    Slug = "foca",
                    MunicipalityName = "Foča",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 9,
                    EntityID = 2,
                    Slug = "cajnice",
                    MunicipalityName = "Čajniče",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 10,
                    EntityID = 2,
                    Slug = "milici",
                    MunicipalityName = "Milići",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 11,
                    EntityID = 2,
                    Slug = "srebrenica",
                    MunicipalityName = "Srebrenica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 12,
                    EntityID = 2,
                    Slug = "bratunac",
                    MunicipalityName = "Bratunac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 13,
                    EntityID = 2,
                    Slug = "vlasenica",
                    MunicipalityName = "Vlasenica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 14,
                    EntityID = 2,
                    Slug = "sekovici",
                    MunicipalityName = "Šekovići",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 15,
                    EntityID = 2,
                    Slug = "osmaci",
                    MunicipalityName = "Osmaci",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 16,
                    EntityID = 2,
                    Slug = "zvornik",
                    MunicipalityName = "Zvornik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 17,
                    EntityID = 2,
                    Slug = "lopare",
                    MunicipalityName = "Lopare",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 18,
                    EntityID = 2,
                    Slug = "ugljevik",
                    MunicipalityName = "Ugljevik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 19,
                    EntityID = 2,
                    Slug = "bijeljina",
                    MunicipalityName = "Bijeljina",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 20,
                    EntityID = 2,
                    Slug = "srbac",
                    MunicipalityName = "Srbac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 21,
                    EntityID = 2,
                    Slug = "prnjavor",
                    MunicipalityName = "Prnjavor",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 22,
                    EntityID = 2,
                    Slug = "laktasi",
                    MunicipalityName = "Laktaši",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 23,
                    EntityID = 2,
                    Slug = "teslic",
                    MunicipalityName = "Teslić",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 24,
                    EntityID = 2,
                    Slug = "celinac",
                    MunicipalityName = "Čelinac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 25,
                    EntityID = 2,
                    Slug = "kotor-varos",
                    MunicipalityName = "Kotor Varoš",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 26,
                    EntityID = 2,
                    Slug = "knezevo",
                    MunicipalityName = "Kneževo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 27,
                    EntityID = 2,
                    Slug = "kupres-rs",
                    MunicipalityName = "Kupres",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 28,
                    EntityID = 2,
                    Slug = "sipovo",
                    MunicipalityName = "Šipovo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 29,
                    EntityID = 2,
                    Slug = "jezero",
                    MunicipalityName = "Jezero",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 30,
                    EntityID = 2,
                    Slug = "mrkonjic-grad",
                    MunicipalityName = "Mrkonjić Grad",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 31,
                    EntityID = 2,
                    Slug = "istocni-drvar",
                    MunicipalityName = "Istočni Drvar",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 32,
                    EntityID = 2,
                    Slug = "petrovac",
                    MunicipalityName = "Petrovac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 33,
                    EntityID = 2,
                    Slug = "ribnik",
                    MunicipalityName = "Ribnik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 34,
                    EntityID = 2,
                    Slug = "banja-luka",
                    MunicipalityName = "Banja Luka",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 35,
                    EntityID = 2,
                    Slug = "gradiska",
                    MunicipalityName = "Gradiška",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 36,
                    EntityID = 2,
                    Slug = "kozarska-dubica",
                    MunicipalityName = "Kozarska Dubica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 37,
                    EntityID = 2,
                    Slug = "kostajnica",
                    MunicipalityName = "Kostajnica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 38,
                    EntityID = 2,
                    Slug = "krupa-na-uni",
                    MunicipalityName = "Krupa na Uni",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 39,
                    EntityID = 2,
                    Slug = "novi-grad-rs",
                    MunicipalityName = "Novi Grad",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 40,
                    EntityID = 2,
                    Slug = "prijedor",
                    MunicipalityName = "Prijedor",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 41,
                    EntityID = 2,
                    Slug = "ostra-luka",
                    MunicipalityName = "Oštra Luka",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 42,
                    EntityID = 2,
                    Slug = "kalinovik",
                    MunicipalityName = "Kalinovik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 43,
                    EntityID = 2,
                    Slug = "ustipraca",
                    MunicipalityName = "Ustiprača",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 44,
                    EntityID = 2,
                    Slug = "istocna-ilidza",
                    MunicipalityName = "Istočna Ilidža",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 45,
                    EntityID = 2,
                    Slug = "istocno-novo-sarajevo",
                    MunicipalityName = "Istočno Novo Sarajevo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 46,
                    EntityID = 2,
                    Slug = "trnovo-rs",
                    MunicipalityName = "Trnovo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 47,
                    EntityID = 2,
                    Slug = "pale",
                    MunicipalityName = "Pale",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 48,
                    EntityID = 2,
                    Slug = "rogatica",
                    MunicipalityName = "Rogatica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 49,
                    EntityID = 2,
                    Slug = "istocni-stari-grad",
                    MunicipalityName = "Istočni Stari Grad",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 50,
                    EntityID = 2,
                    Slug = "sokolac",
                    MunicipalityName = "Sokolac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 51,
                    EntityID = 2,
                    Slug = "han-pijesak",
                    MunicipalityName = "Han Pijesak",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 52,
                    EntityID = 2,
                    Slug = "rudo",
                    MunicipalityName = "Rudo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 53,
                    EntityID = 2,
                    Slug = "visegrad",
                    MunicipalityName = "Višegrad",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 54,
                    EntityID = 2,
                    Slug = "samac",
                    MunicipalityName = "Šamac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 55,
                    EntityID = 2,
                    Slug = "petrovo",
                    MunicipalityName = "Petrovo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 56,
                    EntityID = 2,
                    Slug = "doboj",
                    MunicipalityName = "Doboj",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 57,
                    EntityID = 2,
                    Slug = "brod",
                    MunicipalityName = "Brod",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 58,
                    EntityID = 2,
                    Slug = "derventa",
                    MunicipalityName = "Derventa",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 59,
                    EntityID = 2,
                    Slug = "pelagicevo",
                    MunicipalityName = "Pelagićevo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 60,
                    EntityID = 2,
                    Slug = "donji-zabar",
                    MunicipalityName = "Donji Žabar",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 61,
                    EntityID = 2,
                    Slug = "vukosavlje",
                    MunicipalityName = "Vukosavlje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 62,
                    EntityID = 2,
                    Slug = "modrica",
                    MunicipalityName = "Modriča",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 63,
                    EntityID = 1,
                    Slug = "foca-ustikolina",
                    MunicipalityName = "Foča-Ustikolina",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 64,
                    EntityID = 1,
                    Slug = "gorazde",
                    MunicipalityName = "Goražde",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 65,
                    EntityID = 1,
                    Slug = "pale-praca",
                    MunicipalityName = "Pale-Prača",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 66,
                    EntityID = 1,
                    Slug = "stari-grad",
                    MunicipalityName = "Stari Grad Sarajevo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 67,
                    EntityID = 1,
                    Slug = "centar",
                    MunicipalityName = "Centar Sarajevo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 68,
                    EntityID = 1,
                    Slug = "novo-sarajevo",
                    MunicipalityName = "Novo Sarajevo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 69,
                    EntityID = 1,
                    Slug = "novi-grad",
                    MunicipalityName = "Novi Grad Sarajevo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 70,
                    EntityID = 1,
                    Slug = "trnovo-fbih",
                    MunicipalityName = "Trnovo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 71,
                    EntityID = 1,
                    Slug = "ilijas",
                    MunicipalityName = "Ilijaš",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 72,
                    EntityID = 1,
                    Slug = "hadzici",
                    MunicipalityName = "Hadžići",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 73,
                    EntityID = 1,
                    Slug = "ilidza",
                    MunicipalityName = "Ilidža",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 74,
                    EntityID = 1,
                    Slug = "vogosca",
                    MunicipalityName = "Vogošća",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 75,
                    EntityID = 1,
                    Slug = "gornji-vakuf-uskoplje",
                    MunicipalityName = "Gornji Vakuf-Uskoplje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 76,
                    EntityID = 1,
                    Slug = "fojnica",
                    MunicipalityName = "Fojnica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 77,
                    EntityID = 1,
                    Slug = "kresevo",
                    MunicipalityName = "Kreševo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 78,
                    EntityID = 1,
                    Slug = "kiseljak",
                    MunicipalityName = "Kiseljak",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 79,
                    EntityID = 1,
                    Slug = "busovaca",
                    MunicipalityName = "Busovača",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 80,
                    EntityID = 1,
                    Slug = "vitez",
                    MunicipalityName = "Vitez",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 81,
                    EntityID = 1,
                    Slug = "novi-travnik",
                    MunicipalityName = "Novi Travnik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 82,
                    EntityID = 1,
                    Slug = "bugojno",
                    MunicipalityName = "Bugojno",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 83,
                    EntityID = 1,
                    Slug = "donji-vakuf",
                    MunicipalityName = "Donji Vakuf",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 84,
                    EntityID = 1,
                    Slug = "jajce",
                    MunicipalityName = "Jajce",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 85,
                    EntityID = 1,
                    Slug = "dobretici",
                    MunicipalityName = "Dobretići",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 86,
                    EntityID = 1,
                    Slug = "travnik",
                    MunicipalityName = "Travnik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 87,
                    EntityID = 1,
                    Slug = "breza",
                    MunicipalityName = "Breza",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 88,
                    EntityID = 1,
                    Slug = "olovo",
                    MunicipalityName = "Olovo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 89,
                    EntityID = 1,
                    Slug = "vares",
                    MunicipalityName = "Vareš",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 90,
                    EntityID = 1,
                    Slug = "visoko",
                    MunicipalityName = "Visoko",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 91,
                    EntityID = 1,
                    Slug = "kakanj",
                    MunicipalityName = "Kakanj",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 92,
                    EntityID = 1,
                    Slug = "zenica",
                    MunicipalityName = "Zenica",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 93,
                    EntityID = 1,
                    Slug = "zavidovici",
                    MunicipalityName = "Zavidovići",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 94,
                    EntityID = 1,
                    Slug = "zepce",
                    MunicipalityName = "Žepče",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 95,
                    EntityID = 1,
                    Slug = "maglaj",
                    MunicipalityName = "Maglaj",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 96,
                    EntityID = 1,
                    Slug = "tesanj",
                    MunicipalityName = "Tešanj",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 97,
                    EntityID = 1,
                    Slug = "doboj-jug",
                    MunicipalityName = "Doboj-Jug",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 98,
                    EntityID = 1,
                    Slug = "usora",
                    MunicipalityName = "Usora",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 99,
                    EntityID = 1,
                    Slug = "ljubuski",
                    MunicipalityName = "Ljubuški",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 100,
                    EntityID = 1,
                    Slug = "grude",
                    MunicipalityName = "Grude",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 101,
                    EntityID = 1,
                    Slug = "siroki-brijeg",
                    MunicipalityName = "Široki Brijeg",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 102,
                    EntityID = 1,
                    Slug = "posusje",
                    MunicipalityName = "Posušje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 103,
                    EntityID = 1,
                    Slug = "neum",
                    MunicipalityName = "Neum",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 104,
                    EntityID = 1,
                    Slug = "ravno",
                    MunicipalityName = "Ravno",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 105,
                    EntityID = 1,
                    Slug = "stolac",
                    MunicipalityName = "Stolac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 106,
                    EntityID = 1,
                    Slug = "mostar",
                    MunicipalityName = "Mostar",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 107,
                    EntityID = 1,
                    Slug = "konjic",
                    MunicipalityName = "Konjic",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 108,
                    EntityID = 1,
                    Slug = "capljina",
                    MunicipalityName = "Čapljina",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 109,
                    EntityID = 1,
                    Slug = "citluk",
                    MunicipalityName = "Čitluk",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 110,
                    EntityID = 1,
                    Slug = "jablanica",
                    MunicipalityName = "Jablanica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 111,
                    EntityID = 1,
                    Slug = "prozor-rama",
                    MunicipalityName = "Prozor-Rama",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 112,
                    EntityID = 1,
                    Slug = "tomislavgrad",
                    MunicipalityName = "Tomislavgrad",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 113,
                    EntityID = 1,
                    Slug = "kupres",
                    MunicipalityName = "Kupres",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 114,
                    EntityID = 1,
                    Slug = "livno",
                    MunicipalityName = "Livno",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 115,
                    EntityID = 1,
                    Slug = "glamoc",
                    MunicipalityName = "Glamoč",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 116,
                    EntityID = 1,
                    Slug = "bosansko-grahovo",
                    MunicipalityName = "Bosansko Grahovo",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 117,
                    EntityID = 1,
                    Slug = "drvar",
                    MunicipalityName = "Drvar",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 118,
                    EntityID = 1,
                    Slug = "kladanj",
                    MunicipalityName = "Kladanj",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 119,
                    EntityID = 1,
                    Slug = "banovici",
                    MunicipalityName = "Banovići",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 120,
                    EntityID = 1,
                    Slug = "zivinice",
                    MunicipalityName = "Živinice",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 121,
                    EntityID = 1,
                    Slug = "lukavac",
                    MunicipalityName = "Lukavac",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 122,
                    EntityID = 1,
                    Slug = "kalesija",
                    MunicipalityName = "Kalesija",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 123,
                    EntityID = 1,
                    Slug = "sapna",
                    MunicipalityName = "Sapna",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 124,
                    EntityID = 1,
                    Slug = "teocak",
                    MunicipalityName = "Teočak",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 125,
                    EntityID = 1,
                    Slug = "tuzla",
                    MunicipalityName = "Tuzla",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 126,
                    EntityID = 1,
                    Slug = "celic",
                    MunicipalityName = "Čelić",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 127,
                    EntityID = 1,
                    Slug = "srebrenik",
                    MunicipalityName = "Srebrenik",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 128,
                    EntityID = 1,
                    Slug = "doboj-istok",
                    MunicipalityName = "Doboj-Istok",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 129,
                    EntityID = 1,
                    Slug = "gracanica",
                    MunicipalityName = "Gračanica",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 130,
                    EntityID = 1,
                    Slug = "gradacac",
                    MunicipalityName = "Gradačac",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new Municipality()
                {
                    MunicipalityID = 131,
                    EntityID = 1,
                    Slug = "kljuc",
                    MunicipalityName = "Ključ",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 132,
                    EntityID = 1,
                    Slug = "sanski-most",
                    MunicipalityName = "Sanski Most",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 133,
                    EntityID = 1,
                    Slug = "bosanski-petrovac",
                    MunicipalityName = "Bosanski Petrovac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 134,
                    EntityID = 1,
                    Slug = "bihac",
                    MunicipalityName = "Bihać",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 135,
                    EntityID = 1,
                    Slug = "cazin",
                    MunicipalityName = "Cazin",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 136,
                    EntityID = 1,
                    Slug = "buzim",
                    MunicipalityName = "Bužim",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 137,
                    EntityID = 1,
                    Slug = "bosanska-krupa",
                    MunicipalityName = "Bosanska Krupa",
                    LocalGovernmentUnitID = 2,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 138,
                    EntityID = 1,
                    Slug = "velika-kladusa",
                    MunicipalityName = "Velika Kladuša",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 139,
                    EntityID = 1,
                    Slug = "orasje",
                    MunicipalityName = "Orašje",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 140,
                    EntityID = 1,
                    Slug = "odzak",
                    MunicipalityName = "Odžak",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 141,
                    EntityID = 1,
                    Slug = "domaljevac-samac",
                    MunicipalityName = "Domaljevac-Šamac",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                },
                new Municipality()
                {
                    MunicipalityID = 142,
                    EntityID = 1,
                    Slug = "brcko",
                    MunicipalityName = "Brčko",
                    LocalGovernmentUnitID = 1,
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    SysCreatedDate = defaultCreateDate,
                    Retired = true
                }
            );
            #endregion
        }

        public static void SeedDropdownData(this ModelBuilder builder)
        {
            Guid defaultUserId = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f");
            DateTime defaultCreateDate = new DateTime(2024, 1,1);

            builder.Entity<PropertyCategory>().HasData(

                new PropertyCategory()
                {
                    PropertyCategoryID = 1,
                    Value = "Poljoprivredno zemljište",
                    Code = "AL",
                    InternalName = "Agricultural land",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyCategory()
                {
                    PropertyCategoryID = 2,
                    Value = "Građevinsko zemljište",
                    Code = "BL",
                    InternalName = "Building land",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyCategory()
                {
                    PropertyCategoryID = 3,
                    Value = "Poslovne zgrade-prostori",
                    Code = "OBS",
                    InternalName = "Office buildings/spaces",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyCategory()
                {
                    PropertyCategoryID = 4,
                    Value = "Stambene zgrade-stanovi",
                    Code = "RBA",
                    InternalName = "Residential buildings/apartments",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyCategory()
                {
                    PropertyCategoryID = 5,
                    Value = "Objekti posebne namjene",
                    Code = "SPF",
                    InternalName = "Special purpose facilities",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );
            builder.Entity<PossessionBasis>().HasData(

                new PossessionBasis()
                {
                    PossessionBasisID = 1,
                    Value = "Svojina",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PossessionBasis()
                {
                    PossessionBasisID = 2,
                    Value = "Pravo korištenja",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PossessionBasis()
                {
                    PossessionBasisID = 3,
                    Value = "Posjed",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PossessionBasis()
                {
                    PossessionBasisID = 4,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );


            builder.Entity<OwnershipType>().HasData(

                new OwnershipType()
                {
                    OwnershipTypeID = 1,
                    Value = "Isključivo vlasništvo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipType()
                {
                    OwnershipTypeID = 2,
                    Value = "Suvlasništvo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipType()
                {
                    OwnershipTypeID = 3,
                    Value = "Zajedničko",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipType()
                {
                    OwnershipTypeID = 4,
                    Value = "Izvanknjižno",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<DisputeType>().HasData(

                new DisputeType()
                {
                    DisputeTypeID = 1,
                    Value = "Upravni postupak",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new DisputeType()
                {
                    DisputeTypeID = 2,
                    Value = "Sudski postupak",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new DisputeType()
                {
                    DisputeTypeID = 3,
                    Value = "Upravni spor",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new DisputeType()
                {
                    DisputeTypeID = 4,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );


            builder.Entity<OwnershipRightsAcquisitionLegalBasis>().HasData(

                new OwnershipRightsAcquisitionLegalBasis()
                {
                    OwnershipRightsAcquisitionLegalBasisID = 1,
                    Value = "Ugovor o zamjeni",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipRightsAcquisitionLegalBasis()
                {
                    OwnershipRightsAcquisitionLegalBasisID = 2,
                    Value = "Kupoprodajni ugovor",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipRightsAcquisitionLegalBasis()
                {
                    OwnershipRightsAcquisitionLegalBasisID = 3,
                    Value = "Nasljeđivanje",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipRightsAcquisitionLegalBasis()
                {
                    OwnershipRightsAcquisitionLegalBasisID = 4,
                    Value = "Eksproprijacija",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OwnershipRightsAcquisitionLegalBasis()
                {
                    OwnershipRightsAcquisitionLegalBasisID = 5,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }

            );
            builder.Entity<RestrictedRealRightInformation>().HasData(

                new RestrictedRealRightInformation()
                {
                    RestrictedRealRightInformationID = 1,
                    Value = "Zalog",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new RestrictedRealRightInformation()
                {
                    RestrictedRealRightInformationID = 2,
                    Value = "Služnost",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new RestrictedRealRightInformation()
                {
                    RestrictedRealRightInformationID = 3,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<AL_CreditRatingCategory>().HasData(

                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 1,
                    Value = "I bonitetna kategorija(90 - 100 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 2,
                    Value = "II bonitetna kategorija(80 - 90 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 3,
                    Value = "III bonitetna kategorija(60 - 80 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 4,
                    Value = "IV bonitetna kategorija(40 - 60 bodova), koju čine: -IVa bonitetna potkategorija; -IVb bonitetna potkategorija;",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 5,
                    Value = "V bonitetna kategorija(30 - 40 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 6,
                    Value = "VI bonitetna kategorija(20 - 30 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 7,
                    Value = "VII bonitetna kategorija(10 - 20 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_CreditRatingCategory()
                {
                    AL_CreditRatingCategoryID = 8,
                    Value = "VIII bonitetna kategorija(do 10 bodova)",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<AL_LandType>().HasData(
                new AL_LandType()
                {
                    AL_LandTypeID = 1,
                    Value = "Oranice",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 2,
                    Value = "Bašte",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 3,
                    Value = "Voćnjaci",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 4,
                    Value = "Vinogradi",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 5,
                    Value = "Livade",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 6,
                    Value = "Pašnjaci",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 7,
                    Value = "Bare",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 8,
                    Value = "Trske",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 9,
                    Value = "Močvare",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AL_LandType()
                {
                    AL_LandTypeID = 10,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<BL_ConstructionRightsBasis>().HasData(
                 new BL_ConstructionRightsBasis()
                 {
                     BL_ConstructionRightsBasisID = 1,
                     Value = "Ugovor",
                     SysCreatedByUserID = defaultUserId,
                     SysCreatedDate = defaultCreateDate,
                     Retired = false
                 },
                 new BL_ConstructionRightsBasis()
                 {
                     BL_ConstructionRightsBasisID = 2,
                     Value = "Odluka",
                     SysCreatedByUserID = defaultUserId,
                     SysCreatedDate = defaultCreateDate,
                     Retired = false
                 },
                 new BL_ConstructionRightsBasis()
                 {
                     BL_ConstructionRightsBasisID = 3,
                     Value = "Drugo",
                     SysCreatedByUserID = defaultUserId,
                     SysCreatedDate = defaultCreateDate,
                     Retired = false
                 }
             );


            builder.Entity<OBS_RBA_SPF_PropertyType>().HasData(

                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 1,
                    Value = "Zgrada",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 2,
                    Value = "Poslovni prostor",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 3,
                    Value = "Stan",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 4,
                    Value = "Garaža",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 5,
                    Value = "Javna zgrada - obdanište",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 6,
                    Value = "Pozorište",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 7,
                    Value = "Biblioteka",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 8,
                    Value = "Dom kulture",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_PropertyType()
                {
                    OBS_RBA_SPF_PropertyTypeID = 9,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<OBS_RBA_SPF_EnergyClass>().HasData(

                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 1,
                    Value = "A+",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 2,
                    Value = "A",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 3,
                    Value = "B",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 4,
                    Value = "C",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 5,
                    Value = "D",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 6,
                    Value = "E",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 7,
                    Value = "F",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_EnergyClass()
                {
                    OBS_RBA_SPF_EnergyClassID = 8,
                    Value = "G",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<OBS_RBA_SPF_Condition>().HasData(

                new OBS_RBA_SPF_Condition()
                {
                    OBS_RBA_SPF_ConditionID = 1,
                    Value = "Potpuno funkcionalan/adaptiran",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_Condition()
                {
                    OBS_RBA_SPF_ConditionID = 2,
                    Value = "Sa oštećenjima - postoji mogućnost korištenja",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_Condition()
                {
                    OBS_RBA_SPF_ConditionID = 3,
                    Value = "Ruiniran/devastiran - ne postoji mogućnost korištenja u postojećem stanju",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new OBS_RBA_SPF_Condition()
                {
                    OBS_RBA_SPF_ConditionID = 4,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );


            builder.Entity<PropertyUseBasisDocument>().HasData(

                new PropertyUseBasisDocument()
                {
                    PropertyUseBasisDocumentID = 1,
                    Value = "Ugovor",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUseBasisDocument()
                {
                    PropertyUseBasisDocumentID = 2,
                    Value = "Odluka",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUseBasisDocument()
                {
                    PropertyUseBasisDocumentID = 3,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<PropertyUseBasis>().HasData(

                new PropertyUseBasis()
                {
                    PropertyUseBasisID = 1,
                    Value = "Zakup",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUseBasis()
                {
                    PropertyUseBasisID = 2,
                    Value = "Podzakup",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUseBasis()
                {
                    PropertyUseBasisID = 3,
                    Value = "Koncesija",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUseBasis()
                {
                    PropertyUseBasisID = 4,
                    Value = "Prodaja",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUseBasis()
                {
                    PropertyUseBasisID = 5,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<PropertyUserGender>().HasData(

                new PropertyUserGender()
                {
                    PropertyUserGenderID = 1,
                    Value = "Ženski",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserGender()
                {
                    PropertyUserGenderID = 2,
                    Value = "Muški",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserGender()
                {
                    PropertyUserGenderID = 3,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<PropertyUserType>().HasData(

                new PropertyUserType()
                {
                    PropertyUserTypeID = 1,
                    Value = "Poslovni subjekt",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserType()
                {
                    PropertyUserTypeID = 2,
                    Value = "Udruženje",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserType()
                {
                    PropertyUserTypeID = 3,
                    Value = "Obrt/Preduzetnik",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserType()
                {
                    PropertyUserTypeID = 4,
                    Value = "Zadruga",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserType()
                {
                    PropertyUserTypeID = 5,
                    Value = "Fizičko lice",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyUserType()
                {
                    PropertyUserTypeID = 6,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<ContractTypeBasedOnUserStatus>().HasData(

                new ContractTypeBasedOnUserStatus()
                {
                    ContractTypeBasedOnUserStatusID = 1,
                    Value = "Komercijalna cijena",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new ContractTypeBasedOnUserStatus()
                {
                    ContractTypeBasedOnUserStatusID = 2,
                    Value = "Subvencionirana cijena - socijalna kategorija",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new ContractTypeBasedOnUserStatus()
                {
                    ContractTypeBasedOnUserStatusID = 3,
                    Value = "Bez naknade",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new ContractTypeBasedOnUserStatus()
                {
                    ContractTypeBasedOnUserStatusID = 4,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<ContractType>().HasData(

                new ContractType()
                {
                    ContractTypeID = 1,
                    Value = "Ugovor o prodaji",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new ContractType()
                {
                    ContractTypeID = 2,
                    Value = "Ugovor o najmu/zakupu/podzakupu",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new ContractType()
                {
                    ContractTypeID = 3,
                    Value = "Ugovor o koncesiji",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new ContractType()
                {
                    ContractTypeID = 4,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<PaymentFrequency>().HasData(

                new PaymentFrequency()
                {
                    PaymentFrequencyID = 1,
                    Value = "Jednokratno",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PaymentFrequency()
                {
                    PaymentFrequencyID = 2,
                    Value = "Mjesečno",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PaymentFrequency()
                {
                    PaymentFrequencyID = 3,
                    Value = "Kvartalno",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PaymentFrequency()
                {
                    PaymentFrequencyID = 4,
                    Value = "Godišnje",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PaymentFrequency()
                {
                    PaymentFrequencyID = 5,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            builder.Entity<PropertyStatus>().HasData(

                new PropertyStatus()
                {
                    PropertyStatusID = 1,
                    Value = "U upotrebi",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyStatus()
                {
                    PropertyStatusID = 2,
                    Value = "Slobodno za korištenje",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyStatus()
                {
                    PropertyStatusID = 3,
                    Value = "Slobodno za korištenje - potpuno funkcionalan",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyStatus()
                {
                    PropertyStatusID = 4,
                    Value = "Slobodan za korištenje - sa oštećenjima",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyStatus()
                {
                    PropertyStatusID = 5,
                    Value = "Ruiniran/devastiran - ne postoji mogućnost korištenja u postojećm stanju",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new PropertyStatus()
                {
                    PropertyStatusID = 6,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );




            builder.Entity<InstalledInfrastructure>().HasData(

                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 1,
                    Value = "Pristupni put",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 2,
                    Value = "Elektro mreža",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 3,
                    Value = "Sistem navodnjavanja",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 4,
                    Value = "Sistem zasjenjivanja",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 5,
                    Value = "Protugradne mreže",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 6,
                    Value = "Sistem zaštite od mraza",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 7,
                    Value = "Pristup - putna komunikacija",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 8,
                    Value = "Elektro priključak",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 9,
                    Value = "Vodovod",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 10,
                    Value = "Kanalizacija",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 11,
                    Value = "Centralno grijanje",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 12,
                    Value = "Toplovod",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new InstalledInfrastructure()
                {
                    InstalledInfrastructureID = 13,
                    Value = "Drugo",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );

            List<Zone> zoneList = new();
            for (int i = 1; i <= 10; i++)
            {
                zoneList.Add(new Zone()
                {
                    Id = (byte)i,
                    Name = $"Zona {i}",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                });
            }

            builder.Entity<Zone>().HasData(zoneList);

            builder.Entity<SPF_PropertyType>().HasData(
                new SPF_PropertyType()
                {
                    Id = 1,
                    Title = "Zgrada - Cjelina",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new SPF_PropertyType()
                {
                    Id = 2,
                    Title = "Dio nekretnine - Prostor",
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );
        }
    }
}
