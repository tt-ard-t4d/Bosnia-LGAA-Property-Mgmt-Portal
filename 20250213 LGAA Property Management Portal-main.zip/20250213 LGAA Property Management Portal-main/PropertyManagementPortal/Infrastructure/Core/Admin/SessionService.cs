﻿using Infrastructure.Models;
using PropertyManagementPortal.Domain.Contracts.Admin;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;

namespace PropertyManagementPortal.Infrastructure.Core.Admin
{
    public class SessionService
    {
        private readonly UserService _userService;

        public SessionService(UserService userService)
        {
            _userService = userService;            
        }

        public void SessionUpdateOnGroupActionUpdate(HttpContext httpContext, ActionAssignmentDTO model)
        {
            bool loggedUserInGroup = httpContext.Session.CheckIsInUserGroup(model.UserGroupID);
            var loggedUserId = httpContext.User.Identity.GetLoggedUserId();

            if (loggedUserInGroup)
            {
                UserData userData = _userService.GetUserDataByUserId(loggedUserId);
                httpContext.Session.SetUserData(userData);
            }
        }

        public void SessionUpdateOnUserActionUpdate(HttpContext httpContext, ActionAssignmentDTO model)
        {
            var loggedUserId = httpContext.User.Identity.GetLoggedUserId();

            if (loggedUserId != model.UserID) return;

            UserData userData = _userService.GetUserDataByUserId(loggedUserId);
            httpContext.Session.SetUserData(userData);
        }

        public void SessionUpdateOnUserUpdate(HttpContext httpContext, Guid userId)
        {
            var loggedUserId = httpContext.User.Identity.GetLoggedUserId();

            if (userId != loggedUserId) return;

            UserData userData = _userService.GetUserDataByUserId(loggedUserId);
            httpContext.Session.SetUserData(userData);
        }
    }
}
