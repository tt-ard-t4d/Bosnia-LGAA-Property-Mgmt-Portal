﻿using Infrastructure.Helpers;
using Infrastructure.Models;
using Microsoft.CodeAnalysis.Elfie.Model.Tree;
using PropertyManagementPortal.Domain.Contracts.Admin;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings;
using PropertyManagementPortal.Infrastructure.Mappings.Admin;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Core.Admin
{
    public class ActionManagementService
    {
        private readonly IActionManagementRepository _actionManagementRepository;
        private readonly IUserRepository _userRepository;

        public ActionManagementService(IActionManagementRepository actionManagementRepository, IUserRepository userRepository)
        {
            _actionManagementRepository = actionManagementRepository;
            _userRepository = userRepository;
        }

        #region <!-- Action -->

        public List<ItemDDL> GetActionsForUser(Guid userId)
        {
            var actions = _actionManagementRepository.GetActionsForUser(userId);

            return actions.Select(r => new ItemDDL() { Id = r.ActionID, Value = $"{r.ActionName} ({r.ActionEnumerationName})" }).ToList();
        }

        public List<ItemDDL> GetActionsForUserGroup(int userGroupId)
        {
            var actions = _actionManagementRepository.GetActionsForUserGroup(userGroupId);

            return actions.Select(r => new ItemDDL() { Id = r.ActionID, Value = $"{r.ActionName} ({r.ActionEnumerationName})" }).ToList();
        }

        public ActionDTO GetAction(int actionId)
        {
            var map = new ActionMapper();
            var entity = _actionManagementRepository.GetAction(actionId);

            return map.Map(entity);
        }

        public GridDTO<ActionGridDTO, SearchActionDTO> GetActionGrid(SearchActionDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<ActionGridDTO, SearchActionDTO>();
            (var retVal, var totalNumberOfRows) = _actionManagementRepository.GetActionGrid(args);
            var pager = new PageDTO(totalNumberOfRows, pageNumber, numberOfObjectsPerPage);

            var map = new ActionMapper();
            var grid = retVal.Select(r => map.Map(r, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public GridDTO<ActionGridDTO, SearchActionDTO> GetActionTemporalGrid(SearchActionDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<ActionGridDTO, SearchActionDTO>();
            (var retVal, var totalNumberOfRows) = _actionManagementRepository.GetTemporalActionGrid(args);
            var pager = new PageDTO(totalNumberOfRows, pageNumber, numberOfObjectsPerPage);

            var map = new ActionMapper();
            var grid = retVal.Select(r => map.MapHistory(r, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public RetValue SaveAction(ActionDTO model, Guid loggedUserId)
        {
            var operation = GlobalEnum.CrudOperation.Add;
            var map = new ActionMapper();

            if (model.ActionID > 0)
            {
                operation = GlobalEnum.CrudOperation.Edit;
            }

            var entity = map.Map(model, operation, loggedUserId);

            return _actionManagementRepository.SaveAction(entity, operation);
        }

        #endregion

        #region <!-- User group -->

        public GridDTO<UserGroupGridDTO, SearchUserGroupDTO> GetUserGroupGrid(SearchUserGroupDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<UserGroupGridDTO, SearchUserGroupDTO>();
            (var retVal, var totalNumberOfRows) = _actionManagementRepository.GetUserGroupGrid(args);
            var pager = new PageDTO(totalNumberOfRows, pageNumber, numberOfObjectsPerPage);

            var map = new UserGroupMapper();
            var grid = retVal.Select(r => map.Map(r, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public UserGroupDTO GetUserGroup(int userGroupId)
        {
            var map = new UserGroupMapper();
            var entity = _actionManagementRepository.GetUserGroup(userGroupId);

            return map.Map(entity);
        }

        public RetValue SaveUserGroup(UserGroupDTO model, Guid loggedUserId)
        {
            var operation = GlobalEnum.CrudOperation.Add;
            var map = new UserGroupMapper();

            if (model.UserGroupID > 0)
            {
                operation = GlobalEnum.CrudOperation.Edit;
            }

            var entity = map.Map(model, operation, loggedUserId);

            return _actionManagementRepository.SaveUserGroup(entity, operation);
        }

        #endregion

        #region <!-- Action management -->

        public RetValue SaveActionsForUserGroup(ActionAssignmentDTO model)
        {
            var userGroup = _userRepository.GetUserGroupById(model.UserGroupID);
            
            if (userGroup != null)
            {
                return _actionManagementRepository.SaveActionsForUserGroup(userGroup, model);
            }

            return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingUserGroup };
        }

        public RetValue SaveActionsForUser(ActionAssignmentDTO model)
        {
            var user = _userRepository.GetUserById(model.UserID);

            if (user != null)
            {
                return _actionManagementRepository.SaveActionsForUser(user, model);
            }

            return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingUser };
        }

        #endregion
    }
}
