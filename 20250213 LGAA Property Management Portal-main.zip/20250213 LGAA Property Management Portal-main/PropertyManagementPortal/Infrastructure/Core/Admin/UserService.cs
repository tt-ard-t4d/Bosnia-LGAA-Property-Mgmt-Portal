﻿using Infrastructure.Core;
using Infrastructure.Helpers;
using Infrastructure.Models;
using PropertyManagementPortal.Domain.Contracts.Admin;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Data.Repositories.Admin;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings;
using PropertyManagementPortal.Infrastructure.Mappings.Admin;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Models.StoredProcedures;
using PropertyManagementPortal.Infrastructure.Resources;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Core.Admin
{
    public class UserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;
        private readonly EmailService _emailService;

        public UserService(IUserRepository userRepository, IConfiguration configuration, EmailService emailService)
        {
            _userRepository = userRepository;
            _configuration = configuration;
            _emailService = emailService;
        }


        public UserDTO GetUser(Guid userId)
        {
            var map = new UserMapper();
            var entity = _userRepository.GetUserById(userId);

            return map.Map(entity, _configuration);
        }

        public UserDTO GetUserByEmailCode(string emailCode)
        {
            var map = new UserMapper();
            var entity = _userRepository.GetUserByEmailCode(emailCode);

            return map.Map(entity, _configuration);
        }


        public UserData GetUserDataByEmailEnc(string emailEnc)
        {
            var map = new SessionUserMapper();
            var entity = _userRepository.GetUserByEmailEnc(emailEnc);

            var userActions = entity != null ? GetUserActions(entity.UserID) : new List<UserDataAction>();

            return map.Map(entity, userActions, _configuration);
        }

        public UserDTO GetUserByEmailEnc(string emailEnc)
        {
            var map = new UserMapper();
            var entity = _userRepository.GetUserByEmailEnc(emailEnc);

            return map.Map(entity, _configuration);
        }

        public UserData GetUserDataByUserId(Guid userId)
        {
            var map = new SessionUserMapper();
            var entity = _userRepository.GetUserById(userId);

            var userActions = GetUserActions(userId);

            return map.Map(entity, userActions, _configuration);
        }


        //Get all actions from user group and actions directly related
        public List<UserDataAction> GetUserActions(Guid userId)
        {
            IQueryable<GetUserActions> actions = _userRepository.GetUserActions(userId);

            return actions.ToList()
                .Select(r => new UserDataAction() { ActionID = r.ActionID, ActionEnumerationName = r.ActionEnumerationName }).ToList();
        }

        public List<UserDTO> GetUserEmails(Guid impersonatedUserId)
        {
            var map = new UserMapper();
            var users = _userRepository.GetUserEmails(impersonatedUserId);

            return users.Select(r => map.MapEmail(r, _configuration)).ToList();
        }

        public List<int>? GetUserMunicipalities(Guid userId)
        {
            return _userRepository.GetUserById(userId)?.UserMunicipalities.Where(r=>r.Retired == false).Select(r=>r.MunicipalityID).ToList();
        }

        public GridDTO<UserGridDTO, SearchUserDTO> GetAllUsersGrid(SearchUserDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<UserGridDTO, SearchUserDTO>();

            (var retVal, var totalNumberOfRows) = _userRepository.GetUserGrid(args);
            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new UserMapper();
            var paged = retVal.Page(numberOfObjectsPerPage, args.Page);
            var grid = paged.Select(c => map.MapGrid(c, _configuration, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public GridDTO<UserGridDTO, SearchUserDTO> GetMunicipalityUsersGrid(SearchUserDTO args, Guid userId)
        {
            var userMunicipalities = GetUserMunicipalities(userId);
            if (userMunicipalities == null)
            {
                return new()
                {
                    Search = args,
                };
            }

            var ret = new GridDTO<UserGridDTO, SearchUserDTO>();

            (var retVal, var totalNumberOfRows) = _userRepository.GetMunicipalityUsersGrid(args, userMunicipalities);
            var pager = new PageDTO(totalNumberOfRows, args.Page, Constants.NumberOfObjectsPerPage);

            var map = new UserMapper();
            var paged = retVal.Page(Constants.NumberOfObjectsPerPage, args.Page);
            var grid = paged.Select(c => map.MapGrid(c, _configuration, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public RetValue Save(UserDTO model, Guid loggedUserId)
        {
            var map = new UserMapper();
            var operation = GlobalEnum.CrudOperation.Add;

            if (model.UserID != Guid.Empty)
            {
                operation = GlobalEnum.CrudOperation.Edit;
            }

            var validationRes = ValidateUser(model, operation);
            if (validationRes.IsError) return validationRes;

            var userExists = CheckIfUserExists(model, operation);
            if (userExists.IsError) return userExists;

            var entity = map.Map(model, _configuration, operation, loggedUserId);

            var res = _userRepository.Save(entity, model, operation);

            if (!res.IsError && operation == GlobalEnum.CrudOperation.Add && model.UserChoicePassword)
            {
                var newUser = GetUser(res.Guid);
                _emailService.SendEmailPasswordSetup01(newUser);
            }

            return res;
        }

        public RetValue ValidateUser(UserDTO model, GlobalEnum.CrudOperation operation)
        {
            if (model.UserChoicePassword == false && operation == GlobalEnum.CrudOperation.Add)
            {
                if (string.IsNullOrEmpty(model.Password) || string.IsNullOrEmpty(model.RepeatPassword))
                {
                    return new RetValue() { IsError = true, ErrorMessage = MessageRes.EmptyPasswordOrRepeatPassword };
                }

                if (!model.Password.Equals(model.RepeatPassword))
                {
                    return new RetValue() { IsError = true, ErrorMessage = MessageRes.PasswordAndRepeatPasswordMismatch };
                }
            }

            return new RetValue() { IsError = false };
        }

        public RetValue CheckIfUserExists(UserDTO model, GlobalEnum.CrudOperation operation)
        {
            if (operation == GlobalEnum.CrudOperation.Add)
            {
                var emailEnc = SEDManager.Protect(model.Email.Trim().ToLower(), _configuration);
                var userByEmail = _userRepository.GetUserByEmailEnc(emailEnc);

                if (userByEmail != null)
                {
                    return new RetValue() { IsError = true, ErrorMessage = MessageRes.UserEmailExists };
                }

                var usernameEnc = SEDManager.Protect(model.UserName, _configuration);
                var userByUsername = _userRepository.GetUserByUserNameEnc(usernameEnc);

                if (userByUsername != null)
                {
                    return new RetValue() { IsError = true, ErrorMessage = MessageRes.UserUsernameExists };
                }
            }

            return new RetValue() { IsError = false };
        }

        public RetValue ResetPassword(ResetPasswordDTO resetPassword)
        {
            if (string.IsNullOrEmpty(resetPassword.Password) || string.IsNullOrEmpty(resetPassword.RepeatPassword))
            {
                return new RetValue() { IsError = true, ErrorMessage = "Enter password" };
            }

            if (!resetPassword.Password.Equals(resetPassword.RepeatPassword))
            {
                return new RetValue() { IsError = true, ErrorMessage = "Passwords don't match" };
            }

            if (string.IsNullOrEmpty(resetPassword.VerificationCode))
            {
                return new RetValue() { IsError = true, ErrorMessage = "Verification code missing" };
            }

            var user = _userRepository.GetUserByEmailCode(resetPassword.VerificationCode);

            if (user == null) return new RetValue() { IsError = true, ErrorMessage = "User not found" };

            return _userRepository.ChangePassword(user, resetPassword.Password);
        }

        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            if (id == loggedUserId)
            {
                return new RetValue { IsError = true, ErrorMessage = "Nije moguće obrisati svoj račun!" };
            }

            return _userRepository.Delete(id, loggedUserId);
        }

        
    }
}
