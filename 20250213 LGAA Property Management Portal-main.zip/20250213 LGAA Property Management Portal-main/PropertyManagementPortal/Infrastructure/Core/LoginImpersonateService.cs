﻿using Infrastructure.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using System.Security.Claims;

namespace PropertyManagementPortal.Infrastructure.Core
{
    public class LoginImpersonateService
    {
        public ClaimsPrincipal AddClaims(UserData user, ClaimsPrincipal powerAdmin)
        {
            var claimImpersonatedUserId = powerAdmin.FindFirst(CustomClaimTypes.CurrentImpersonatedUserId);
            var claimImpersonatedUserEmail = powerAdmin.FindFirst(CustomClaimTypes.CurrentImpersonatedUserEmail);

            var userClaim = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, user.UserName.ToString()),
                new Claim(CustomClaimTypes.UserId, user.UserID.ToString(), ClaimValueTypes.Integer),
                new Claim(CustomClaimTypes.Email, user.Email.ToString()),
                claimImpersonatedUserId,
                claimImpersonatedUserEmail
            };

            var userIdentity = new ClaimsIdentity(userClaim, CookieAuthenticationDefaults.AuthenticationScheme);
            var userPrincipal = new ClaimsPrincipal(userIdentity);

            return userPrincipal;
        }
    }
}
