﻿
using Domain.Contracts;
using DTO.Utils;
using Infrastructure.Data.Repositories;
using Infrastructure.Mappings.Utils;
using Infrastructure.Models.Utils.Audit;
using Infrastructure.Settings.Utils;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings;

namespace Infrastructure.Core
{
    public class AuditLogService
    {
        private readonly IAuditLogRepository _auditLogRep;
        private readonly IAuditLogEnumerationRepository _auditLogEnumRep;
        private readonly IConfiguration _configuration;
        public AuditLogService(IAuditLogRepository auditLogRep, IAuditLogEnumerationRepository auditLogEnumRep, IConfiguration configuration)
        {
            _auditLogRep = auditLogRep;
            _auditLogEnumRep = auditLogEnumRep;
            _configuration = configuration;
        }


        #region <-- Private -->

        public GridDTO<AuditLogGridDTO, SearchAuditLogDTO> GetAuditLogGrid(SearchAuditLogDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<AuditLogGridDTO, SearchAuditLogDTO>();
            (var retVal, var totalNumberOfRows) = _auditLogRep.GetAuditLogGrid(args);
            var pager = new PageDTO(totalNumberOfRows, pageNumber, numberOfObjectsPerPage);

            var map = new AuditLogMapper();
            var grid = retVal.Select(c => map.MapGrid(c, _configuration, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }


        private void SendAuditLog(int auditLogEnumID, List<AuditData> auditLogItems, long? relatedItemID)
        {
            var auditLogEnum = _auditLogEnumRep.GetAuditLogEnumerationItem(auditLogEnumID);
           
                foreach (var item in auditLogItems)
                {
                    SendAudit(item, auditLogEnum, auditLogEnumID, relatedItemID);
                }
            
        }

        private bool SendAudit(AuditData auditData, AuditLogEnumerationDTO auditLogEnum, int? auditLogEnumID, long? relatedItemID)
        {
            var htmlTemplate = auditLogEnum.AuditLogEnumerationText;

            foreach (var item in auditData.ItemData)
            {
                var key = '<' + item.Key + '>';

                if (!String.IsNullOrEmpty(htmlTemplate))
                    htmlTemplate = htmlTemplate.Replace(key, item.Value.ToString());


            }

            try
            {
                AuditLogDTO auditLog = new AuditLogDTO();
                auditLog.AuditLogEnumerationID = auditLogEnumID;
                auditLog.AuditLogText = htmlTemplate;
                auditLog.RelatedItemID = relatedItemID;

                _auditLogRep.SaveAuditLog(auditLog);

                return true;
            }
            catch (Exception ex)
            {
                //Log Exception Details
                return false;
            }
        }

     
        #endregion
    }
}
