﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Office2019.Word.Cid;
using PropertyManagementPortal.Domain.Contracts.Utils;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Mappings.Utils;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Core.Utils
{
    public class AttachmentService
    {
        private readonly IAttachmentRepository _attachmentRepository;
        private readonly IConfiguration _configuration;
        private readonly BlobServiceClient _blobClient;

        public AttachmentService(IAttachmentRepository ar, BlobServiceClient blobClient, IConfiguration configuration)
        {
            _attachmentRepository = ar;
            _blobClient = blobClient;
            _configuration = configuration;
        }

        public RetValue DeleteFiles(List<string>? toDelete)
        {
            if (toDelete == null || toDelete.Count == 0)
                return new RetValue { ErrorMessage = "No files to delete", IsError = false };

            foreach (var file in toDelete)
            {
                var val = _attachmentRepository.DeleteFile(Guid.Parse(file));
                if (val.IsError)
                {
                    return val;
                }
            }


            return new RetValue();
        }

        public RetValue SaveFiles(IFormFileCollection attachments, AttachmentSaveDTO saveInfo)
        {
            var map = new AttachmentMapper();
            List<FormFileDTO> items = new();
            var containerName = _configuration.GetValue<string>("FileContainerName") ?? string.Empty;
            var ret = new RetValue();
            foreach (var item in attachments)
            {
                var uid = Guid.NewGuid();
                var fileName = uid + "_" + item.FileName;
                // upload file to blob
                var resUpload = UploadBlob(fileName, item, containerName);
                if (resUpload is true)
                {
                    // add file to DB
                    var entity = map.Map(item, uid, saveInfo.AttachmentType, saveInfo.ContentID, saveInfo.LoggedUserId);
                    entity.Link = GetBlob($"{uid}_{entity.FileName}{entity.Extension}", containerName,
                        $"{entity.FileName}{entity.Extension}");
                    var save = _attachmentRepository.Save(entity);
                    if (save.IsError)
                    {
                        return new RetValue() { IsError = true, ErrorMessage = FileRes.DBError };
                    }

                    entity.AttachedFileID = save.Id;
                    items.Add(map.Map(entity));
                }
                else
                {
                    ret.IsError = true;
                    ret.ErrorMessage = FileRes.ServerNotFound;
                    DeleteFiles(items.Select(r => r.FileGUID.ToString()).ToList()!);
                    break;
                }
            }

            return ret;
        }

        private bool UploadBlob(string fileName, IFormFile file, string containerName)
        {
            var containerClient = _blobClient.GetBlobContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(fileName);
            var httpHeaders = new BlobHttpHeaders()
            {
                ContentType = file.ContentType,
            };
            try
            {
                var res = blobClient.Upload(file.OpenReadStream(), httpHeaders);

                if (res != null)
                {
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }

            return false;
        }

        public string GetBlob(string name, string containerName, string friendlyName)
        {
            // this will allow us access to the storage container
            var containerClient = _blobClient.GetBlobContainerClient(containerName);

            // this will allow us access to the file inside the container via the file name
            var blobClient = containerClient.GetBlobClient(name);

            var httpHeaders = new BlobHttpHeaders()
            {
                ContentDisposition = $"attachment; filename={friendlyName}"
            };

            return blobClient.Uri.AbsoluteUri;

        }

        public AttachmentShowDTO GetFileById(Guid fileId)
        {
            return _attachmentRepository.GetFileFromDB(fileId);
        }
    }

}