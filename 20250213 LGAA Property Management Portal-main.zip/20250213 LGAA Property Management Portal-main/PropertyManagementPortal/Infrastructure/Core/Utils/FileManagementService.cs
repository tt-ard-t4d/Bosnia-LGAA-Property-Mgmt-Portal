﻿using PropertyManagementPortal.Domain.Contracts.Utils;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Mappings.Admin;
using PropertyManagementPortal.Infrastructure.Mappings;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings.Utils;

namespace PropertyManagementPortal.Infrastructure.Core.Utils
{
    public class FileManagementService
    {

    }
}
