﻿using PropertyManagementPortal.Domain.Contracts.Utils;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Core.Utils
{
    public class DropDownService
    {
        private readonly IDropDownRepository _dropDownRepository;
        private readonly IConfiguration _configuration;

        public DropDownService(IDropDownRepository dropDownRepository, IConfiguration configuration)
        {
            _dropDownRepository = dropDownRepository;
            _configuration = configuration;
        }

        public List<ItemDDL> GetUserGroups(bool isSystemAdministrator)
        {
            var res = _dropDownRepository.GetUserGroups();
            if (!isSystemAdministrator)
            {
                res = res.Where(r => r.UserGroupID != 1);
            }
            return res.Select(r => new ItemDDL() { Id = r.UserGroupID, Value = r.Name }).ToList();
        }

        public List<ItemDDL> GetActions()
        {
            return _dropDownRepository.GetActions().Select(r => new ItemDDL() { Id = r.ActionID, Value = $"{r.ActionName} ({r.ActionEnumerationName})" }).ToList();
        }

        public List<ItemDDL> GetUsers()
        {
            return _dropDownRepository.GetUsers()
                .Select(r => new ItemDDL()
                {
                    Guid = r.UserID,
                    Value =
                $"{SEDManager.Unprotect(r.UserNameEnc, _configuration)} (" +
                $"{SEDManager.Unprotect(r.FirstNameEnc, _configuration)} " +
                $"{SEDManager.Unprotect(r.LastNameEnc, _configuration)})"
                })
                .ToList();
        }

        public List<ItemDDL> GetUserEmails()
        {
            return _dropDownRepository.GetUsers().Select(r => new ItemDDL() { Guid = r.UserID, Value = SEDManager.Unprotect(r.EmailEnc, _configuration) }).ToList();
        }

        public List<ItemDDL> GetAuditType()
        {
            return _dropDownRepository.GetAllAuditLogsEnumeration().Select(r => new ItemDDL { Id = r.AuditLogEnumerationID, Value = r.AuditLogEnumerationDescription }).ToList();
        }

        public List<ItemDDL> GetMunicipalities()
        {
            return _dropDownRepository.GetMunicipalities()
                .Select(r =>
                    new ItemDDL()
                    {
                        Id = r.MunicipalityID,
                        Value = r.MunicipalityName
                    })
                .ToList();
        }
    }
}
