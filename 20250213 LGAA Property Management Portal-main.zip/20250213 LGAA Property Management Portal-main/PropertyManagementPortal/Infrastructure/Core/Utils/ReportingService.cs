﻿using ClosedXML.Excel;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Core.Utils
{
    public class ReportingService
    {
        public Tuple<MemoryStream, string> CreateDefaultReport<T>(List<T> data, string reportName, List<string> ignoreProperties = null) where T : class, new()
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                var ws = wb.Worksheets.Add(ReportingRes.DefaultSheetName);
                ReportHelper.CreateHeader(ref ws, data, ignoreProperties);
                ReportHelper.CreateRows(ref ws, data, 2, ignoreProperties);

                ws.Columns().AdjustToContents();
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string fileName = reportName + "-" + DateTime.Now.ToString("yyyy-MM-dd") + "-" + DateTime.Now.ToString("HH-mm-ss") + ".xlsx";
                    return Tuple.Create(stream, fileName);
                }
            }
        }
    }
}
