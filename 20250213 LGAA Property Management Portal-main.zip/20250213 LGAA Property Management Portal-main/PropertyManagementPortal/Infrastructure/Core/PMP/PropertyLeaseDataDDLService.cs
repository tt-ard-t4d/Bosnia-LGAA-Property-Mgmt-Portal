﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyLeaseDataDDLService
    {
        private readonly IPropertyLeaseDataDDLRepository _repository;

        public PropertyLeaseDataDDLService(IPropertyLeaseDataDDLRepository repository)
        {
            _repository = repository;
        }

        public List<ItemDDL> GetPropertyUserTypes()
        {
            return _repository.GetPropertyUserTypes().Select(r => new ItemDDL() { Id = r.PropertyUserTypeID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetPropertyUserGenders()
        {
            return _repository.GetPropertyUserGenders().Select(r => new ItemDDL() { Id = r.PropertyUserGenderID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetContractTypesBasedOnUserStatus()
        {
            return _repository.GetContractTypesBasedOnUserStatus().Select(r => new ItemDDL() { Id = r.ContractTypeBasedOnUserStatusID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetContractTypes(byte propertyCategoryID)
        {
            var types = _repository.GetContractTypes();
            if (propertyCategoryID == (byte)GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste)
            {
                types = types.Where(r => r.ContractTypeID != (byte)GlobalEnum.ContractTypes.UgovorOProdaji);
            }
            return types.Select(r => new ItemDDL() { Id = r.ContractTypeID, Value = r.Value }).ToList(); ;
        }

        public List<ItemDDL> GetPropertyStatuses(byte propertyCategoryId)
        {
            var statuses = _repository.GetPropertyStatuses().Select(r => new ItemDDL() { Id = r.PropertyStatusID, Value = r.Value }).ToList();
            if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste || propertyCategoryId == (byte)GlobalEnum.PropertyCategories.GradjevinskoZemljiste)
            {
                statuses = statuses.Where(r =>
                    r.Id == (byte)GlobalEnum.PropertyStatuses.UUpotrebi ||
                    r.Id == (byte)GlobalEnum.PropertyStatuses.Slobodan
                ).ToList();
            }
            else if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.PoslovneZgrade)
            {
                statuses = statuses.Where(r =>
                    r.Id == (byte)GlobalEnum.PropertyStatuses.UUpotrebi ||
                    r.Id == (byte)GlobalEnum.PropertyStatuses.SlobodanFunkcionalan ||
                    r.Id == (byte)GlobalEnum.PropertyStatuses.SlobodanOstecen ||
                    r.Id == (byte)GlobalEnum.PropertyStatuses.Ruiniran
                ).ToList();
            }
            else if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.StambeneZgrade || propertyCategoryId == (byte)GlobalEnum.PropertyCategories.OstaliObjekti)
            {
                statuses = statuses.Where(r =>
                    r.Id == (byte)GlobalEnum.PropertyStatuses.UUpotrebi ||
                    r.Id == (byte)GlobalEnum.PropertyStatuses.Slobodan ||
                    r.Id == (byte)GlobalEnum.PropertyStatuses.Drugo
                ).ToList();
            }
            return statuses;
        }

        public List<ItemDDL> GetPropertyUseBases(byte propertyCategoryID)
        {
            var bases = _repository.GetPropertyUseBases();
            if (propertyCategoryID == (byte)GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste)
            {
                bases = bases.Where(r => r.PropertyUseBasisID != (byte)GlobalEnum.PropertyUseBasis.Prodaja);
            }
            return bases.Select(r => new ItemDDL() { Id = r.PropertyUseBasisID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetPropertyUseBasisDocuments()
        {
            return _repository.GetPropertyUseBasisDocuments().Select(r => new ItemDDL() { Id = r.PropertyUseBasisDocumentID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetPaymentFrequencies()
        {
            return _repository.GetPaymentFrequencies().Select(r => new ItemDDL() { Id = r.PaymentFrequencyID, Value = r.Value }).ToList();
        }
    }
}
