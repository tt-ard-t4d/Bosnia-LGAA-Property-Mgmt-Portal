﻿using Newtonsoft.Json;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.Municipality;
using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PMPDropDownService
    {
        private readonly IPMPDropDownRepository _repository;
        private readonly IMunicipalityRepository _municipalityRepository;

        public PMPDropDownService(IPMPDropDownRepository repository, IMunicipalityRepository municipalityRepository)
        {
            _repository = repository;
            _municipalityRepository = municipalityRepository;
        }

        public List<ItemDDL> GetEntities()
        {
            return _repository.GetEntities().Select(r => new ItemDDL() { Id = r.EntityID, Value = r.EntityName }).ToList();
        }

        public List<ItemDDL> GetMunicipalitiesForUser(Guid userId)
        {
            return _repository.GetMunicipalitiesForUser(userId).Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName, Code = r.Slug }).ToList();
        }

        public List<ItemDDL> GetAllMunicipalities()
        {
            return _repository.GetAllMunicipalities().Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName, Code = r.Slug }).ToList();
        }

        public List<ItemDDL> GetRetiredMunicipalities()
        {
            return _municipalityRepository.GetRetiredMunicipalities().Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName, Code = r.Slug }).ToList();
        }
        public List<ItemDDL> CreateYearDDL(int startingYear)
        {
            var years = new List<ItemDDL>();
            var currentYear = DateTime.Now.Year;

            for (int i = currentYear + 1; i >= startingYear; i--)
            {
                years.Add(new ItemDDL { Id = i, Value = i.ToString() });
            }

            return years;
        }

        public List<ItemDDL> GetSlugs()
        {
            using (StreamReader r = new("wwwroot/static-data/minicipality-slugs.json"))
            {
                string json = r.ReadToEnd();
                MunicipalitySlugDTO obj = JsonConvert.DeserializeObject<MunicipalitySlugDTO>(json);
                return obj.Slugs.Select(r => new ItemDDL() { Value = r }).ToList();
            }
        }
    }
}
