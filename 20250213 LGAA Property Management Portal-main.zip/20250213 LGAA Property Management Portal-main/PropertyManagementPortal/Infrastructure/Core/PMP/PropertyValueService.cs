﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.DTO.PropertyValue;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings;
using PropertyManagementPortal.Infrastructure.Mappings.PMP;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyValueService
    {
        private readonly IPropertyValueRepository _repository;
        private readonly PropertyService _propertyService;
        private readonly IConfiguration _configuration;
        public PropertyValueService(IPropertyValueRepository repository, IConfiguration configuration, PropertyService propertyService)
        {
            _repository = repository;
            _propertyService = propertyService;
            _configuration = configuration;
        }

        public PropertyValueDTO GetPropertyValueById(Guid id)
        {
            var map = new PropertyValueMapper();
            var entity = _repository.GetPropertyValueById(id);
            return map.Map(entity);
        }


        public GridDTO<PropertyValueGridDTO, SearchPropertyValueDTO> GetPropertyValuesGrid(SearchPropertyValueDTO args, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<PropertyValueGridDTO, SearchPropertyValueDTO>();
            (var retVal, var totalNumberOfRows) = _repository.GetPropertyValueGrid(args, numberOfObjectsPerPage);

            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new PropertyValueMapper();
            var grid = retVal.Select(c => map.MapGrid(c)).ToList();

            args.Address = _propertyService.GetPropertyAddress(args.PropertyID);

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public RetValue Save(PropertyValueDTO model, Guid loggedUserId)
        {
            var map = new PropertyValueMapper();
            var operation = model.PropertyValueID==Guid.Empty ? GlobalEnum.CrudOperation.Add : GlobalEnum.CrudOperation.Edit;

            var entity = map.Map(model, operation, loggedUserId);

            return _repository.Save(entity, operation);
        }

        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            return _repository.Delete(id, loggedUserId);
        }
    }
}
