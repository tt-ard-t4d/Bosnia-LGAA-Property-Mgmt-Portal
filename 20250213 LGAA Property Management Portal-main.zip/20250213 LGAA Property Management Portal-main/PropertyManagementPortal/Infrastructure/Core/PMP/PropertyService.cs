﻿using Infrastructure.Helpers;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Mappings;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.Infrastructure.Mappings.PMP;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Utility;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyService
    {
        private readonly IPropertyRepository _repository;
        private readonly IMunicipalityRepository _municipalityRepository;
        private readonly IConfiguration _configuration;
        private readonly AttachmentService _attachmentService;

        public PropertyService(IPropertyRepository repository, IConfiguration configuration, AttachmentService atts, IMunicipalityRepository mr)
        {
            _repository = repository;
            _configuration = configuration;
            _attachmentService = atts;
            _municipalityRepository = mr;
        }

        public PropertyDTO GetPropertyById(Guid id)
        {
            var map = new PropertyMapper();
            var entity = _repository.GetPropertyById(id);

            return map.Map(entity, _configuration);
        }

        public ShowPropertyDTO? GetPropertyDetails(Guid id)
        {
            var map = new PropertyMapper();
            var entity = _repository.GetPropertyDetailsById(id);

            return entity == null ? null : map.MapDetails(entity, _configuration);
        }

        public GridDTO<PropertyGridDTO, SearchPropertyDTO> GetPropertyGrid(SearchPropertyDTO args, Guid loggedUserGuid, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var (retVal, totalNumberOfRows) = _repository.GetPropertyGrid(args, loggedUserGuid, _configuration, numberOfObjectsPerPage);

            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new PropertyMapper();
            var grid = retVal.Select(c => map.MapGrid(c, _configuration, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            var ret = gridMap.MapGrid(grid, args, pager);

            ret.Title = args.MunicipalityID == 0 ? PropertyRes.AdministratorPropertyView : ParseTitle(args);

            return ret;
        }

        private string ParseTitle(SearchPropertyDTO args)
        {
            var municipality = _municipalityRepository.GetMunicipalityById(args.MunicipalityID);
            var lguType = municipality?.LocalGovernmentUnit.LocalGovernmentUnitName;

            if (lguType == "Općina" && municipality?.Entity.EntityID == (int)GlobalEnum.Entity.RS)
                lguType = "Opština";
            return $"{lguType} {municipality?.MunicipalityName}";
        }

        public RetValue Save(PropertyDTO model, Guid loggedUserId)
        {
            var map = new PropertyMapper();
            var operation = (model.PropertyID != Guid.Empty) ? GlobalEnum.CrudOperation.Edit : GlobalEnum.CrudOperation.Add;
            var entity = map.Map(model, _configuration, operation, loggedUserId);

            _attachmentService.DeleteFiles(model.DeleteAttachmentIDs);

            var property = _repository.Save(entity, model, operation);

            if (property.IsError || model.Attachments == null || !model.Attachments.Any())
            {
                return property;
            }

            var saveInfo = new AttachmentSaveDTO()
            {
                ContentID = property.Guid,
                LoggedUserId = loggedUserId,
                AttachmentType = (short)GlobalEnum.AttachmentTypes.Property,
            };

            var documents = _attachmentService.SaveFiles(model.Attachments, saveInfo);
            if (documents.IsError)
            {
                Delete(property.Guid, loggedUserId);
                return documents;
            }

            return property;

        }

        public string GetPropertyAddress(Guid propertyId)
        {
            var encryptedAddress = _repository.GetPropertyById(propertyId)?.LocationAddress;
            return encryptedAddress == null ? string.Empty : SEDManager.Unprotect(encryptedAddress, _configuration);
        }

        public byte? GetCategory(Guid propertyID)
        {
            var entity = _repository.GetPropertyById(propertyID);
            return entity?.PropertyCategoryID;
        }

        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            return _repository.Delete(id, loggedUserId);
        }
    }
}
