﻿using Infrastructure.Helpers;
using Microsoft.IdentityModel.Tokens;
using PropertyManagementPortal.Domain.Contracts.Admin;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.DTO.Property.Reports;
using PropertyManagementPortal.Infrastructure.Mappings.PMP;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyReportService
    {

        private readonly IPropertyRepository _propertyRepository;
        private readonly IUserRepository _userRepository;
        private readonly IMunicipalityRepository _municipalityRepository;
        private readonly IConfiguration _configuration;
        public PropertyReportService(IPropertyRepository propertyRepository, IUserRepository userRepository, IMunicipalityRepository municipalityRepository, IConfiguration configuration)
        {
            _propertyRepository = propertyRepository;
            _configuration = configuration;
            _municipalityRepository = municipalityRepository;
            _userRepository = userRepository;
        }

        public List<ReportPropertyDTO> GetPropertyForExport(SearchPropertyDTO args)
        {
            var retVal = _propertyRepository.GetPropertiesForReport(args, _configuration);
            var map = new PropertyMapper();
            return retVal.Select(r => map.MapExport(r, _configuration)).ToList();
        }

        public List<string> GetIgnoredFieldsForProperty(SearchPropertyDTO args)
        {
            switch (args.PropertyCategoryID)
            {
                case (byte)GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste:
                    return new()
                    {
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_GardenArea),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_BuildYear),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_PropertyType),
                        nameof(ReportPropertyDTO.SPF_PropertyType),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_UnitNumber),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_NumberOfFloors),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_Condition),
                        nameof(ReportPropertyDTO.OBS_RBA_IsSharedObject),
                        nameof(ReportPropertyDTO.SPF_IsLegallyConstructed),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_EnergyClass),
                        nameof(ReportPropertyDTO.BL_HasConstructionRights),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsBasis),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsHolder)
                    };
                case (byte)GlobalEnum.PropertyCategories.GradjevinskoZemljiste:
                    return new()
                    {
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_GardenArea),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_BuildYear),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_PropertyType),
                        nameof(ReportPropertyDTO.SPF_PropertyType),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_UnitNumber),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_NumberOfFloors),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_Condition),
                        nameof(ReportPropertyDTO.OBS_RBA_IsSharedObject),
                        nameof(ReportPropertyDTO.SPF_IsLegallyConstructed),
                        nameof(ReportPropertyDTO.AL_CreditRatingCategory),
                        nameof(ReportPropertyDTO.AL_LandType),
                        nameof(ReportPropertyDTO.OBS_RBA_SPF_EnergyClass),
                    };
                case (byte)GlobalEnum.PropertyCategories.PoslovneZgrade:
                    return new()
                    {
                        nameof(ReportPropertyDTO.AL_BL_LandUseAccordingRegulatoryPlan),
                        nameof(ReportPropertyDTO.SPF_PropertyType),
                        nameof(ReportPropertyDTO.SPF_IsLegallyConstructed),
                        nameof(ReportPropertyDTO.AL_CreditRatingCategory),
                        nameof(ReportPropertyDTO.AL_LandType),
                        nameof(ReportPropertyDTO.BL_HasConstructionRights),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsBasis),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsHolder),
                    };
                case (byte)GlobalEnum.PropertyCategories.StambeneZgrade:
                    return new()
                    {
                        nameof(ReportPropertyDTO.AL_BL_LandUseAccordingRegulatoryPlan),
                        nameof(ReportPropertyDTO.SPF_PropertyType),
                        nameof(ReportPropertyDTO.SPF_IsLegallyConstructed),
                        nameof(ReportPropertyDTO.AL_CreditRatingCategory),
                        nameof(ReportPropertyDTO.AL_LandType),
                        nameof(ReportPropertyDTO.BL_HasConstructionRights),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsBasis),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsHolder),
                    };
                case (byte)GlobalEnum.PropertyCategories.OstaliObjekti:
                    return new()
                    {
                        nameof(ReportPropertyDTO.AL_BL_LandUseAccordingRegulatoryPlan),
                        nameof(ReportPropertyDTO.OBS_RBA_IsSharedObject),
                        nameof(ReportPropertyDTO.AL_CreditRatingCategory),
                        nameof(ReportPropertyDTO.AL_LandType),
                        nameof(ReportPropertyDTO.BL_HasConstructionRights),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsBasis),
                        nameof(ReportPropertyDTO.BL_ConstructionRightsHolder),
                    };
            }

            return new List<string>();
        }

        #region PDF reports

        public (List<AgriculturalPropertyLeaseReportDTO>, LGUReportDTO) GenerateALLeaseReport(int municipalityId, Guid userId)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste, municipalityId);
            var total = properties.Count;
            properties = properties
                .Where(r => !r.PropertyLeaseData.IsNullOrEmpty())
                .Select(r => new
                {
                    Property = r,
                    FilteredLeaseData = r.PropertyLeaseData
                        .Where(p =>
                            p.ContractTypeID is (byte)GlobalEnum.ContractTypes.UgovorONajmuZakupuPodzakupu or (byte)GlobalEnum.ContractTypes.UgovorOKoncesiji
                        ).MaxBy(p => p.SysCreatedDate)
                })
                .Where(result => result.FilteredLeaseData != null && result.FilteredLeaseData.PropertyStatus.PropertyStatusID != (byte)GlobalEnum.PropertyStatuses.Slobodan)
                .Select(result => result.Property)
                .ToList();

            var mapper = new PropertyReportMapper();
            var propertyReportList = properties.Select(r => mapper.MapAgriculturalReport(r, _configuration)).ToList();

            var lgu = GetLGUInfo(municipalityId, userId, total);

            return (propertyReportList, lgu);
        }

        public (List<BuildingLandLeaseReportDTO>, LGUReportDTO) GenerateBLLeaseReport(int municipalityId, Guid userId)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.GradjevinskoZemljiste, municipalityId);
            var total = properties.Count;
            properties = properties
                .Where(r => !r.PropertyLeaseData.IsNullOrEmpty())
                .Select(r => new
                {
                    Property = r,
                    FilteredLeaseData = r.PropertyLeaseData
                        .Where(p =>
                            p.ContractTypeID is (byte)GlobalEnum.ContractTypes.UgovorONajmuZakupuPodzakupu or (byte)GlobalEnum.ContractTypes.UgovorOKoncesiji
                        ).MaxBy(p => p.SysCreatedDate)
                })
                .Where(result => result.FilteredLeaseData != null && result.FilteredLeaseData.PropertyStatus.PropertyStatusID != (byte)GlobalEnum.PropertyStatuses.Slobodan)
                .Select(result => result.Property)
                .ToList();

            var mapper = new PropertyReportMapper();
            var propertyReportList = properties.Select(r => mapper.MapBuildingReport(r, _configuration)).ToList();

            var lgu = GetLGUInfo(municipalityId, userId, total);

            return (propertyReportList, lgu);
        }

        public (List<OfficeBuildingLeaseReportDTO>, LGUReportDTO) GenerateOBSLeaseReport(int municipalityId, Guid userId)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.PoslovneZgrade, municipalityId);
            var total = properties.Count;
            properties = properties
                    .Where(r => !r.PropertyLeaseData.IsNullOrEmpty())
                    .Select(r => new
                    {
                        Property = r,
                        FilteredLeaseData = r.PropertyLeaseData
                            .Where(p =>
                                p.ContractTypeID is (byte)GlobalEnum.ContractTypes.UgovorONajmuZakupuPodzakupu or (byte)GlobalEnum.ContractTypes.UgovorOKoncesiji
                            ).MaxBy(p => p.SysCreatedDate)
                    })
                    .Where(result => result.FilteredLeaseData != null && result.FilteredLeaseData.PropertyStatus.PropertyStatusID != (byte)GlobalEnum.PropertyStatuses.Slobodan)
                    .Select(result => result.Property)
            .ToList();

            var mapper = new PropertyReportMapper();
            var propertyReportList = properties.Select(r => mapper.MapOfficeBuildingReport(r, _configuration)).ToList();

            var lgu = GetLGUInfo(municipalityId, userId, total);

            return (propertyReportList, lgu);
        }

        public (List<ResidentialBuildingLandLeaseReportDTO>, LGUReportDTO) GenerateRBALeaseReport(int municipalityId, Guid userId)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.StambeneZgrade, municipalityId);
            var total = properties.Count;
            properties = properties
                .Where(r => !r.PropertyLeaseData.IsNullOrEmpty())
                .Select(r => new
                {
                    Property = r,
                    FilteredLeaseData = r.PropertyLeaseData
                        .Where(p =>
                            p.ContractTypeID is (byte)GlobalEnum.ContractTypes.UgovorONajmuZakupuPodzakupu or (byte)GlobalEnum.ContractTypes.UgovorOKoncesiji
                        ).MaxBy(p => p.SysCreatedDate)
                })
                .Where(result => result.FilteredLeaseData != null && result.FilteredLeaseData.PropertyStatus.PropertyStatusID != (byte)GlobalEnum.PropertyStatuses.Slobodan)
                .Select(result => result.Property)
                .ToList();

            var mapper = new PropertyReportMapper();
            var propertyReportList = properties.Select(r => mapper.MapResidentialBuildingReport(r, _configuration)).ToList();

            var lgu = GetLGUInfo(municipalityId, userId, total);

            return (propertyReportList, lgu);
        }

        public (List<BuildingLandTradeReportDTO>, LGUReportDTO) GenerateBLTreadeReport(int municipalityId, Guid userId, DateTime from, DateTime to)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.GradjevinskoZemljiste, municipalityId);
            var total = properties.Count;
            var leaseData = properties
                .SelectMany(r => r.PropertyLeaseData.Where(p => p is { ContractConclusionDate: not null, ContractTypeID: (byte)GlobalEnum.ContractTypes.UgovorOProdaji } && p.ContractConclusionDate.Value >= from && p.ContractConclusionDate.Value <= to)).ToList();

            var mapper = new PropertyReportMapper();
            var propertyReportList = leaseData.Select(r => mapper.MapBuildingTradeReport(r, _configuration)).ToList();

            var lgu = GetLGUInfo(municipalityId, userId, total);

            return (propertyReportList, lgu);
        }


        private LGUReportDTO GetLGUInfo(int municipalityId, Guid userId, int total)
        {
            var municipality = _municipalityRepository.GetMunicipalityById(municipalityId);
            var user = _userRepository.GetUserById(userId);
            return new LGUReportDTO()
            {
                EntityName = municipality.Entity.EntityName,
                LGUType = municipality.LocalGovernmentUnit.LocalGovernmentUnitName == "Općina" && municipality.Entity.EntityID == (byte)GlobalEnum.Entity.RS ? "Opština" : municipality.LocalGovernmentUnit.LocalGovernmentUnitName,
                MunicipalityName = municipality.MunicipalityName,
                UserNameAndSurname = SEDManager.Unprotect(user.FirstNameEnc, _configuration) + " " + SEDManager.Unprotect(user.LastNameEnc, _configuration),
                ReportDate = DateTime.Now.ToShortDateString(),
                Total = total
            };
        }

        public (List<OfficeBuildingTradeReportDTO>, LGUReportDTO) GenerateOBSTreadeReport(int municipalityId, Guid userId, DateTime? from, DateTime? to)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.PoslovneZgrade, municipalityId);
            var total = properties.Count;
            var leaseData = properties
                .SelectMany(r => r.PropertyLeaseData.Where(p => p is { ContractConclusionDate: not null, ContractTypeID: (byte)GlobalEnum.ContractTypes.UgovorOProdaji } && p.ContractConclusionDate.Value >= from && p.ContractConclusionDate.Value <= to)).ToList();


            var mapper = new PropertyReportMapper();
            var propertyReportList = leaseData.Select(r => mapper.MapOfficeBuildingTradeReport(r, _configuration)).ToList();

            var municipality = _municipalityRepository.GetMunicipalityById(municipalityId);
            var user = _userRepository.GetUserById(userId);
            var lgu = new LGUReportDTO()
            {
                EntityName = municipality.Entity.EntityName,
                LGUType = municipality.LocalGovernmentUnit.LocalGovernmentUnitName == "Općina" && municipality.Entity.EntityID == (byte)GlobalEnum.Entity.RS ? "Opština" : municipality.LocalGovernmentUnit.LocalGovernmentUnitName,
                MunicipalityName = municipality.MunicipalityName,
                UserNameAndSurname = SEDManager.Unprotect(user.FirstNameEnc, _configuration) + " " + SEDManager.Unprotect(user.LastNameEnc, _configuration),
                ReportDate = DateTime.Now.ToShortDateString(),
                Total = total
            };

            return (propertyReportList, lgu);
        }

        public (List<ResidentialBuildingTradeReportDTO>, LGUReportDTO) GenerateRBATradeReport(int municipalityId, Guid userId, DateTime? from, DateTime? to)
        {
            var properties = _propertyRepository.GetPropertiesByType(GlobalEnum.PropertyCategories.StambeneZgrade, municipalityId);
            var total = properties.Count;
            var leaseData = properties
                .SelectMany(r => r.PropertyLeaseData.Where(p => p is { ContractConclusionDate: not null, ContractTypeID: (byte)GlobalEnum.ContractTypes.UgovorOProdaji } && p.ContractConclusionDate.Value >= from && p.ContractConclusionDate.Value <= to)).ToList();


            var mapper = new PropertyReportMapper();
            var propertyReportList = leaseData.Select(r => mapper.MapResidentialBuildingTradeReport(r, _configuration)).ToList();

            var municipality = _municipalityRepository.GetMunicipalityById(municipalityId);
            var user = _userRepository.GetUserById(userId);
            var lgu = new LGUReportDTO()
            {
                EntityName = municipality.Entity.EntityName,
                LGUType = municipality.LocalGovernmentUnit.LocalGovernmentUnitName == "Općina" && municipality.Entity.EntityID == (byte)GlobalEnum.Entity.RS ? "Opština" : municipality.LocalGovernmentUnit.LocalGovernmentUnitName,
                MunicipalityName = municipality.MunicipalityName,
                UserNameAndSurname = SEDManager.Unprotect(user.FirstNameEnc, _configuration) + " " + SEDManager.Unprotect(user.LastNameEnc, _configuration),
                ReportDate = DateTime.Now.ToShortDateString(),
                Total = total
            };

            return (propertyReportList, lgu);
        }

        public (List<ExpropriatedRealEstateTradeReportDTO>, LGUReportDTO) GenerateERETradeReport(int municipalityId, Guid userId)
        {
            var properties = _propertyRepository.GetAllProperties(municipalityId);
            var total = properties.Count;
            var leaseData = properties
                .SelectMany(r => r.PropertyLeaseData.Where(p => p is { Property.OwnershipRightsAcquisitionLegalBasisID: (byte)GlobalEnum.OwnershipRightsTypes.Eksproprijacija })).ToList();


            var mapper = new PropertyReportMapper();
            var propertyReportList = leaseData.Select(r => mapper.MapExpropriatedRealEstateTradeReport(r, _configuration)).ToList();

            var municipality = _municipalityRepository.GetMunicipalityById(municipalityId);
            var user = _userRepository.GetUserById(userId);
            var lgu = new LGUReportDTO()
            {
                EntityName = municipality.Entity.EntityName,
                LGUType = municipality.LocalGovernmentUnit.LocalGovernmentUnitName == "Općina" && municipality.Entity.EntityID == (byte)GlobalEnum.Entity.RS ? "Opština" : municipality.LocalGovernmentUnit.LocalGovernmentUnitName,
                MunicipalityName = municipality.MunicipalityName,
                UserNameAndSurname = SEDManager.Unprotect(user.FirstNameEnc, _configuration) + " " + SEDManager.Unprotect(user.LastNameEnc, _configuration),
                ReportDate = DateTime.Now.ToShortDateString(),
                Total = total
            };

            return (propertyReportList, lgu);
        }

        public (List<DisputedPropertyTradeReportDTO>, LGUReportDTO) GenerateDPTradeReport(int municipalityId, Guid userId)
        {
            var properties = _propertyRepository.GetAllProperties(municipalityId);
            var total = properties.Count;
            var leaseData = properties
                .SelectMany(r => r.PropertyLeaseData.Where(p => p is { Property.IsDispute: true })).ToList();


            var mapper = new PropertyReportMapper();
            var propertyReportList = leaseData.Select(r => mapper.MapDisputedPropertyTradeReport(r, _configuration)).ToList();

            var municipality = _municipalityRepository.GetMunicipalityById(municipalityId);
            var user = _userRepository.GetUserById(userId);
            var lgu = new LGUReportDTO()
            {
                EntityName = municipality.Entity.EntityName,
                LGUType = municipality.LocalGovernmentUnit.LocalGovernmentUnitName == "Općina" && municipality.Entity.EntityID == (byte)GlobalEnum.Entity.RS ? "Opština" : municipality.LocalGovernmentUnit.LocalGovernmentUnitName,
                MunicipalityName = municipality.MunicipalityName,
                UserNameAndSurname = SEDManager.Unprotect(user.FirstNameEnc, _configuration) + " " + SEDManager.Unprotect(user.LastNameEnc, _configuration),
                ReportDate = DateTime.Now.ToShortDateString(),
                Total = total
            };

            return (propertyReportList, lgu);
        }
        #endregion
    }
}
