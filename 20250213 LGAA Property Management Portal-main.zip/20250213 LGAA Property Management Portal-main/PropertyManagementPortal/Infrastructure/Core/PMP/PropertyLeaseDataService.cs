﻿using Infrastructure.Helpers;
using Infrastructure.Mappings.Utils;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.DTO.PropertyValue;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings;
using PropertyManagementPortal.Infrastructure.Mappings.PMP;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyLeaseDataService
    {

        private readonly IPropertyLeaseDataRepository _repository;
        private readonly PropertyService _propertyService;
        private readonly AttachmentService _attachmentService;
        private readonly IConfiguration _configuration;

        public PropertyLeaseDataService(IPropertyLeaseDataRepository repository, IConfiguration configuration, AttachmentService attService, PropertyService propertyService)
        {
            _repository = repository;
            _configuration = configuration;
            _attachmentService = attService;
            _propertyService = propertyService;
        }

        public List<PropertyLeaseDataDTO> GetAllPropertyLeaseData()
        {
            var map = new PropertyLeaseDataMapper();
            var entity = _repository.GetAllPropertyLeaseData();

            var ret = entity.Select(c => map.Map(c)).ToList();

            return ret;
        }

        public PropertyLeaseDataDTO GetPropertyLeaseDataById(Guid id)
        {
            var map = new PropertyLeaseDataMapper();
            var entity = _repository.GetPropertyLeaseDataById(id);

            var ret = map.Map(entity);
            ret.PropertyAddress = _propertyService.GetPropertyAddress(id);

            return ret;
        }
        public GridDTO<PropertyLeaseDataGridDTO, SearchPropertyLeaseDataDTO> GetPropertyLeaseDataGrid(SearchPropertyLeaseDataDTO args, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<PropertyLeaseDataDTO, SearchPropertyLeaseDataDTO>();
            (var retVal, var totalNumberOfRows) = _repository.GetPropertyLeaseDataGrid(args, numberOfObjectsPerPage);

            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new PropertyLeaseDataMapper();
            var grid = retVal.Select(c => map.MapGrid(c)).ToList();

            args.PropertyAddress = _propertyService.GetPropertyAddress(args.PropertyID);

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public RetValue Save(PropertyLeaseDataDTO model, Guid loggedUserId)
        {
            var map = new PropertyLeaseDataMapper();
            var operation = model.PropertyLeaseDataID == Guid.Empty ? GlobalEnum.CrudOperation.Add : GlobalEnum.CrudOperation.Edit;
            var entity = map.Map(model, operation, loggedUserId);

            _attachmentService.DeleteFiles(model.DeleteAttachmentIDs);

            var status = _repository.Save(entity, operation);

            if (status.IsError || model.Attachments == null || !model.Attachments.Any())
            {
                return status;
            }

            var saveInfo = new AttachmentSaveDTO()
            {
                ContentID = status.Guid,
                LoggedUserId = loggedUserId,
                AttachmentType = (short)GlobalEnum.AttachmentTypes.PropertyLeaseData,
            };

            var documents = _attachmentService.SaveFiles(model.Attachments, saveInfo);
            if (documents.IsError)
            {
                Delete(status.Guid, loggedUserId);
                return documents;
            }

            return status;
        }

        public RetValue Delete(Guid id, Guid loggedUserId)
        {
            return _repository.Delete(id, loggedUserId);
        }
    }
}
