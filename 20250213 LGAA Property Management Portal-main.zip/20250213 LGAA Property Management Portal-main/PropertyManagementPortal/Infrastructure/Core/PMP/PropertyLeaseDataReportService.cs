﻿using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Mappings.PMP;
using PropertyManagementPortal.Infrastructure.Resources;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyLeaseDataReportService
    {
        private readonly IConfiguration _configuration;
        private readonly IPropertyRepository _propertyRepository;
        private readonly IPropertyLeaseDataRepository _repository;
        public PropertyLeaseDataReportService(IConfiguration configuration, IPropertyLeaseDataRepository repository, IPropertyRepository propertyRepository)
        {
            _configuration = configuration;
            _repository = repository;
            _propertyRepository = propertyRepository;
        }
        public List<ReportLeaseDataDTO> GetLeaseDataForExport(Guid propertyGuid)
        {
            var map = new PropertyLeaseDataMapper();
            var property = _propertyRepository.GetPropertyForStatusReport(propertyGuid);
            if (property == null || !property.PropertyLeaseData.Any())
            {
                return new List<ReportLeaseDataDTO>();
            }
            return property.PropertyLeaseData.Select(r => map.MapReport(r)).ToList();
        }

        public List<string> GetIgnoredFieldsForLeaseData(Guid propertyGuid)
        {
            return new();
        }

        public string GetReportName(Guid propertyGuid)
        {
            var property = _propertyRepository.GetPropertyById(propertyGuid);
            if (property == null)
            {
                return PropertyLeaseDataReportRes.ReportName + propertyGuid;
            }

            return $"{PropertyLeaseDataReportRes.ReportName}-{SEDManager.Unprotect(property.LocationAddress,_configuration)}-{property.KO}-{property.KP}".Slugify();
        }
    }
}
