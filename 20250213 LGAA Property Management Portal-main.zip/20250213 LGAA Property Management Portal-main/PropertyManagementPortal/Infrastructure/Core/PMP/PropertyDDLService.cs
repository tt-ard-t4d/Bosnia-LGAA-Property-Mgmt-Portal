﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Contracts.PMP;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Utility;

namespace PropertyManagementPortal.Infrastructure.Core.PMP
{
    public class PropertyDDLService
    {
        private readonly IPropertyDDLRepository _repository;
        private readonly IConfiguration _config;
        public PropertyDDLService(IPropertyDDLRepository repository, IConfiguration config)
        {
            _repository = repository;
            _config = config;
        }

        public List<ItemDDL> GetAL_CreditRatingCategories()
        {
            return _repository.GetAL_CreditRatingCategories().Select(r => new ItemDDL() { Id = r.AL_CreditRatingCategoryID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetDisputeTypes()
        {
            return _repository.GetDisputeTypes().Select(r => new ItemDDL() { Id = r.DisputeTypeID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetPropertyStatuses(byte? propertyCategoryId)
        {
            var res = _repository.GetPropertyStatuses();

            if (propertyCategoryId == null)
            {
                return res.Select(r => new ItemDDL() { Id = r.PropertyStatusID, Value = r.Value }).ToList();
            }

            return new List<ItemDDL>();
        }
        public List<ItemDDL> GetOBS_RBA_SPF_PropertyTypes(byte propertyCategoryId)
        {
            if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste || propertyCategoryId == (byte)GlobalEnum.PropertyCategories.GradjevinskoZemljiste)
                return new();

            var res = _repository.GetOBS_RBA_SPF_PropertyTypes();
            //ENUM
            if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.PoslovneZgrade)
            {
                res = res.Where(r =>
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Zgrada ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.PoslovniProstor
                );
            }
            else if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.StambeneZgrade)
            {
                res = res.Where(r =>
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Zgrada ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Stan
                );
            }
            else if (propertyCategoryId == (byte)GlobalEnum.PropertyCategories.OstaliObjekti)
            {
                res = res.Where(r =>
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Garaza ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.JavnaZgradaObdaniste ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Pozoriste ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Biblioteka ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.DomKulture ||
                      r.OBS_RBA_SPF_PropertyTypeID == (byte)GlobalEnum.OBS_RBA_SPF_PropertyTypes.Drugo
                );
            }

            return res.Select(r => new ItemDDL() { Id = r.OBS_RBA_SPF_PropertyTypeID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetSPF_PropertyTypes()
        {
            return _repository.GetSPF_PropertyTypes().Select(r => new ItemDDL() { Id = r.Id, Value = r.Title }).ToList();
        }

        public List<ItemDDL> GetOBS_RBA_SPF_EnergyClasses()
        {
            return _repository.GetOBS_RBA_SPF_EnergyClasses().Select(r => new ItemDDL() { Id = r.OBS_RBA_SPF_EnergyClassID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetOwnershipRightsAcquisitionLegalBases()
        {
            return _repository.GetOwnershipRightsAcquisitionLegalBases().Select(r => new ItemDDL() { Id = r.OwnershipRightsAcquisitionLegalBasisID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetOwnershipTypes()
        {
            return _repository.GetOwnershipTypes().Select(r => new ItemDDL() { Id = r.OwnershipTypeID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetPossessionBases()
        {
            return _repository.GetPossessionBases().Select(r => new ItemDDL() { Id = r.PossessionBasisID, Value = r.Value }).OrderBy(r => r.Id).ToList();
        }

        public List<ItemDDL> GetPropertyCategories()
        {
            return _repository.GetPropertyCategories().Select(r => new ItemDDL() { Id = r.PropertyCategoryID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetOBS_RBA_SPF_Conditions()
        {
            return _repository.GetOBS_RBA_SPF_Conditions().Select(r => new ItemDDL() { Id = r.OBS_RBA_SPF_ConditionID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetRestrictedRealRightInformation()
        {
            return _repository.GetRestrictedRealRightInformation().Select(r => new ItemDDL() { Id = r.RestrictedRealRightInformationID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetLandTypes()
        {
            return _repository.GetLandTypes().Select(r => new ItemDDL() { Id = r.AL_LandTypeID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> Get_BLConstructionRightsBases()
        {
            return _repository.GetBLConstructionRightsBases().Select(r => new ItemDDL() { Id = r.BL_ConstructionRightsBasisID, Value = r.Value }).ToList();
        }

        public List<ItemDDL> GetBoolDDL()
        {
            return new List<ItemDDL>
            {
                new ItemDDL
                {
                    Id = 1,
                    Value = "Da"
                },
                new ItemDDL
                {
                    Id = 0,
                    Value = "Ne"
                }
            };
        }

        public List<ItemDDL> GetMunicipalitiesForUser(Guid userId)
        {
            return _repository.GetMunicipalitiesForUser(userId).Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName }).ToList();
        }

        public List<ItemDDL> GetInstalledInfrastructure(byte? propertyCategoryID)
        {
            var res = _repository.GetInstalledInfrastructures();

            if (propertyCategoryID == (byte)GlobalEnum.PropertyCategories.PoljoprivrednoZemljiste)
            {
                res = res.Where(r =>
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.PristupniPut ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Vodovod ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.ElektroMreza ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.SistemNavodnjavanja ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.SistemZasjenjivanja ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.ProtugradneMreze ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Kanalizacija ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.SistemZastiteOdMraza ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Toplovod ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Drugo
                );
            }
            else if (propertyCategoryID == (byte)GlobalEnum.PropertyCategories.GradjevinskoZemljiste || propertyCategoryID == (byte)GlobalEnum.PropertyCategories.OstaliObjekti)
            {
                res = res.Where(r =>
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.PristupniPut ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Vodovod ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.ElektroPrikljucak ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Kanalizacija ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Toplovod ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Drugo
                );
            }
            else if (propertyCategoryID == (byte)GlobalEnum.PropertyCategories.StambeneZgrade || propertyCategoryID == (byte)GlobalEnum.PropertyCategories.PoslovneZgrade)
            {
                res = res.Where(r =>
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.PristupniPut ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.ElektroPrikljucak ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Vodovod ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.CentralnoGrijanje ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Kanalizacija ||
                      r.InstalledInfrastructureID == (byte)GlobalEnum.InstalledInfrastructures.Drugo
                );
            }

            return res.Select(r => new ItemDDL() { Id = r.InstalledInfrastructureID, Value = r.Value }).OrderBy(r => r.Id).ToList();
        }

        public List<ItemDDL> GetZones()
        {
            return _repository.GetZones().Select(r => new ItemDDL() { Id = r.Id, Value = r.Name }).ToList();
        }

        public List<ItemDDL> GetMunicipalityUsers(int argsMunicipalityID)
        {
            var userList = argsMunicipalityID == 0
                ? _repository.GetAllUsers()
                : _repository.GetMunicipalityUsers(argsMunicipalityID);

            return userList.Select(r => new ItemDDL() { Guid = r.UserID, Value = SEDManager.Unprotect(r.FirstNameEnc, _config) + " " + SEDManager.Unprotect(r.LastNameEnc, _config) }).ToList();
        }
    }
}
