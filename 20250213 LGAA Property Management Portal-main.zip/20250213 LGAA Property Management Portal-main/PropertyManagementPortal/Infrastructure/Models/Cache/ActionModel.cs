﻿namespace PropertyManagementPortal.Infrastructure.Models.Cache
{
    public class ActionModel
    {
        public int UserID { get; set; }
        public int ActionID { get; set; }
    }
}
