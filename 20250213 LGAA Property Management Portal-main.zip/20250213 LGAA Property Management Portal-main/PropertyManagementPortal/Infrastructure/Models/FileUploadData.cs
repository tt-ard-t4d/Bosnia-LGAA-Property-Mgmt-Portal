﻿namespace PropertyManagementPortal.Infrastructure.Models
{
    public class FileUploadData
    {
        public int Id { get; set; }
        public short TypeId { get; set; }
    }
}
