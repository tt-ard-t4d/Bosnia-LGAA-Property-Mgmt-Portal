﻿using PropertyManagementPortal.Infrastructure.Models;

namespace Infrastructure.Models
{
    public class UserData
    {
        public Guid UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public bool AllowLock { get; set; }
        public int DefaultLanguageID { get; set; }
        public bool Retired { get; set; }
        public bool Confirmed { get; set; }
        public bool? IsPowerAdmin { get; set; }
        public List<UserDataGroup> UserGroups { get; set; }
        public List<UserDataAction> UserActions { get; set; }
    }
}