﻿namespace Infrastructure.Models.Utils.Email
{
    public class EmailData
    {
        public Dictionary<string, string> ItemData = new Dictionary<string, string>();
        public List<String> To { get; set; }
        public List<String> Cc { get; set; } = new List<String>();
        public List<String> Bcc { get; set; } = new List<string>();
    }
}
