﻿namespace PropertyManagementPortal.Infrastructure.Models
{
    public class RetValue
    {
        public RetValue()
        {
            IsError = false;
            ErrorMessage = string.Empty;
        }

        public int Id { get; set; }
        public Guid Guid { get; set; }
        public long IdLong { get; set; }
        public string ErrorMessage { get; set; }
        public string Message { get; set; }
        public bool IsError { get; set; }
        public Exception Exception { get; set; }
        public string ReturnUrl { get; set; }
    }
}
