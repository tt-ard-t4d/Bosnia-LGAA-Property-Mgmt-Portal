﻿namespace PropertyManagementPortal.Infrastructure.Models
{
    public class CustomClaimTypes
    {
        public const string UserId = "UserId";
        public const string UserGroupId = "UserGroupId";
        public const string UserGroup = "UserGroup";
        public const string ActionId = "ActionId";
        public const string Action = "Action";
        public const string PartyId = "PartyId";
        public const string PartyName = "PartyName";
        public const string LanguageId = "LanguageId";
        public const string Email = "Email";
        public const string PowerAdmin = "PowerAdmin";
        public const string CurrentImpersonatedUserId = "CurrentImpersonatedUserId";
        public const string CurrentImpersonatedUserEmail = "CurrentImpersonatedUserEmail";
        public const string IsDirectoryUserLogedIn = "IsDirectoryUserLogedIn";
    }
}
