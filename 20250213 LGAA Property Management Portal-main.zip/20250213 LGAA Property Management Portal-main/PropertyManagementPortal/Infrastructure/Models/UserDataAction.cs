﻿namespace PropertyManagementPortal.Infrastructure.Models
{
    public class UserDataAction
    {
        public int ActionID { get; set; }
        public string ActionEnumerationName { get; set; }
    }
}
