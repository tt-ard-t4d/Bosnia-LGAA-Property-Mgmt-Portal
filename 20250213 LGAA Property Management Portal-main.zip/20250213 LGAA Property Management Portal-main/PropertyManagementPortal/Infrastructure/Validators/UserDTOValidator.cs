﻿using FluentValidation;
using PropertyManagementPortal.DTO.Admin;

namespace PropertyManagementPortal.Infrastructure.Validators
{
    public class UserDTOValidator : AbstractValidator<UserDTO>
    {
        public UserDTOValidator() 
        {
            RuleFor(r => r.FirstName).NotEmpty();
            RuleFor(r => r.LastName).NotEmpty();
            RuleFor(r => r.Email).EmailAddress();
            RuleFor(r => r.UserName).NotEmpty();
        }
    }
}
