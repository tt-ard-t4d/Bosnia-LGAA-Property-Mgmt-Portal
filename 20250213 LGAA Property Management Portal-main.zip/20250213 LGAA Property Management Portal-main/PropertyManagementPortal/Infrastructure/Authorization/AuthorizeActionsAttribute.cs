﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;

namespace PropertyManagementPortal.Infrastructure.Authorization
{
    public class AuthorizeActionsAttribute : Attribute, IAuthorizationFilter
    {
        private ActionManagementEnum.ActionEnumeration[] _allowedActions;

        public AuthorizeActionsAttribute(params ActionManagementEnum.ActionEnumeration[] allowedActions)
        {
            _allowedActions = allowedActions;
        }

        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            if (!filterContext.HttpContext.User.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            if(filterContext.HttpContext.Session.CheckIsInAction(_allowedActions)) return;

            HandleUnauthorizedRequest(filterContext);
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.SignOutAsync();
            filterContext.HttpContext.Session.Clear();
            filterContext.Result = new RedirectResult("/");
        }
    }
}
