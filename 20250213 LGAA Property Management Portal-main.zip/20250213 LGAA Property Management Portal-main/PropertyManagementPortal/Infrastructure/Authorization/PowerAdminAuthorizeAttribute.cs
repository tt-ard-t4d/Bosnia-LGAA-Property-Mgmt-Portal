﻿
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PropertyManagementPortal.Infrastructure.Extensions;

namespace Authorization
{
    public class PowerAdminAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        
        {
            if (!filterContext.HttpContext.User.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            if (!filterContext.HttpContext.User.IsPowerAdmin())
            {
                HandleUnauthorizedRequest(filterContext);
            }
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.SignOutAsync();
            filterContext.HttpContext.Session.Clear();
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "Login" }, { "controller", "Login" } });
        }
    }
}