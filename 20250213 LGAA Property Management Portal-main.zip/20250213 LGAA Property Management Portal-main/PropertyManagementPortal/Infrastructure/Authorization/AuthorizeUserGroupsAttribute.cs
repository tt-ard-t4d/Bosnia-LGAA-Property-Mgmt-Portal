﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;

namespace Authorization
{
    // this attribute can be use in class and in methods
    // [AuthorizeRoles(GlobalEnum.UserTypes.Admin, GlobalEnum.UserTypes.Korisnici)]
    public class AuthorizeUserGroupsAttribute : Attribute, IAuthorizationFilter
    {
        private ActionManagementEnum.UserGroups[] _allowedUserGroups;
   
        public AuthorizeUserGroupsAttribute(params ActionManagementEnum.UserGroups[] allowedUserGroups)
        {
            _allowedUserGroups = allowedUserGroups;
        }

        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            if (!filterContext.HttpContext.User.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            if (filterContext.HttpContext.Session.CheckIsInUserGroup(_allowedUserGroups)) return;
            
            HandleUnauthorizedRequest(filterContext);            
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.Result = new RedirectResult("/Home/NotAuthorized");
        }
    }
}