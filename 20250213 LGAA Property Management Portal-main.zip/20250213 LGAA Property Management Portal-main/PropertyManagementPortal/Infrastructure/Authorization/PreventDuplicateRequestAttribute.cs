﻿

using Infrastructure.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

//Treba napraviti novu verziju sa claimsovima (cookie)

namespace UNDPGES.Web.Infrastructure.Authorization
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class PreventDuplicateRequestAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (AppSettingsHelper.GetContxtHeader("__RequestVerificationToken") == null)
                return;

            var currentToken = AppSettingsHelper.GetContxtHeader("__RequestVerificationToken");
            var currentDate = DateTime.Now;

            var data = new List<UserInfo>
            {  
                new UserInfo(){
                Id = currentToken,
                date = currentDate
                }
            };

            if (AppSettingsHelper.GetContxt<List<UserInfo>>("LastProcessed") == null)
                AppSettingsHelper.SetContxt<List<UserInfo>>("LastProcessed", data);
           
            lock (AppSettingsHelper.GetContxt<List<UserInfo>>("LastProcessed"))
            {
                var proccesedList = AppSettingsHelper.GetContxt<List<UserInfo>>("LastProcessed");
               
                var proccesedTokenCount = proccesedList.Where(u => u.Id == currentToken).Count();
                var proccesed = proccesedList.Where(u => u.Id == currentToken)?.First();
                var preccesedToken = proccesed.Id ?? "";

                if (preccesedToken == currentToken && proccesedTokenCount > 2)
                {
                    if ((currentDate - proccesed.date).TotalSeconds < 60)
                    {
                        Controller controller = filterContext.Controller as Controller;
                        controller.TempData["ModelStateError"] = "Izgleda da slučajno pokušavate poslati zahtjev više puta.";
                        return;
                    }
                    else
                    {
                        proccesedList.Remove(proccesed);
                    }
                }

                proccesedList.Add(data.First());

                AppSettingsHelper.SetContxt<List<UserInfo>>("LastProcessed", proccesedList);
            }
        }

        public class UserInfo
        {
            public string Id { get; set; }
            public DateTime date { get; set; }
        }
    }
}