﻿using PropertyManagementPortal.Infrastructure.Models;
using System.Security.Claims;
using System.Security.Principal;

namespace PropertyManagementPortal.Infrastructure.Extensions
{
    public static class IdentityExtension
    {
        public static Guid GetLoggedUserId(this IIdentity? identity)
        {
            if (identity is not ClaimsIdentity claimsIdentity || identity == null) { return Guid.Empty; }

            Claim? claim = claimsIdentity?.FindFirst(CustomClaimTypes.UserId);

            if (claim == null)
            {
                return Guid.Empty;
            }

            return new Guid(claim.Value);
        }

        public static string GetUserName(this IIdentity identity)
        {
            if (identity is not ClaimsIdentity claimsIdentity) { return string.Empty; }

            Claim? claim = claimsIdentity?.FindFirst(ClaimTypes.Name);

            return claim?.Value ?? string.Empty;
        }

        public static string GetImpersonatedUserEmail(this IIdentity? identity)
        {
            if (identity is not ClaimsIdentity claimsIdentity) { return string.Empty; }

            Claim? claim = claimsIdentity?.FindFirst(CustomClaimTypes.CurrentImpersonatedUserEmail);

            return claim?.Value ?? string.Empty;
        }

        public static string GetUserEmail(this IIdentity identity)
        {
            if (identity is not ClaimsIdentity claimsIdentity) { return string.Empty; }

            Claim? claim = claimsIdentity?.FindFirst(CustomClaimTypes.Email);

            return claim?.Value ?? string.Empty;
        }

        public static bool GetUserIsDirectoryUser(this IIdentity identity)
        {
            if (identity is not ClaimsIdentity claimsIdentity || identity == null) { return false; }

            Claim? claim = claimsIdentity?.FindFirst(CustomClaimTypes.IsDirectoryUserLogedIn);

            if (claim == null)
            {
                return false;
            }

            return bool.Parse(claim.Value);
        }
    }
}
