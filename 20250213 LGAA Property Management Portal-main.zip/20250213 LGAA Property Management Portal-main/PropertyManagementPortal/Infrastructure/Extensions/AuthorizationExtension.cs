﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using System;
using System.Security.Claims;

namespace PropertyManagementPortal.Infrastructure.Extensions
{
    public static class AuthorizationExtension
    {
        public static bool IsLoggedIn(this ClaimsPrincipal user)
        {
            if (user.Identity == null) return false;

            return user.Identity.IsAuthenticated;
        }

        public static Guid GetImpersonatedUserId(this ClaimsPrincipal user)
        {
            var id = user.FindFirst(CustomClaimTypes.CurrentImpersonatedUserId);

            return id != null ? new Guid(id.Value) : Guid.Empty; 
        }

        public static Guid GetLoggedUserId(this ClaimsPrincipal user)
        {
            var id = user.FindFirst(CustomClaimTypes.UserId);

            return id != null ? new Guid(id.Value) : Guid.Empty;
        }

        public static bool IsPowerAdmin(this ClaimsPrincipal principal)
        {
            var id = GetImpersonatedUserId(principal);
            var powerAdmins = ConfigurationHelper.GetConfig("AppIdentitySettings:Utils");
            string[] parts = powerAdmins.Split(';');

            return parts.Any(s => new Guid(s).Equals(id));
        }


        public static bool IsPowerAdminControl(this ClaimsPrincipal principal)
        {
            var id = GetLoggedUserId(principal);
            var powerAdmins = ConfigurationHelper.GetConfig("AppIdentitySettings:Utils");
            string[] parts = powerAdmins.Split(';');

            return parts.Any(s => new Guid(s).Equals(id));
        }

        public static bool LoggedAsImpersonatedUser(this ClaimsPrincipal principal)
        {
            var impersonatedUserId = principal.GetImpersonatedUserId();
            var userId = principal.GetLoggedUserId();

            return (!userId.Equals(Guid.Empty) && impersonatedUserId == userId);
        }
    }
}
