﻿using System.Linq.Expressions;
using System.Reflection;

namespace PropertyManagementPortal.Infrastructure.Extensions
{
    public static class DynamicOrderByExtension
    {
        public static IQueryable<T> OrderByField<T>(this IQueryable<T> query, string sortField, bool ascending)
        {
            var type = typeof(T);
            var property = GetProperty(type, sortField);

            if (property == null) throw new ArgumentException($"Property '{sortField}' not found on type {type}");

            var parameter = Expression.Parameter(type, "p");

            // Check if the property is from a related entity (e.g., category name)
            var memberExpression = property.DeclaringType != type
                ? Expression.Property(Expression.Property(parameter, property.DeclaringType.Name), property.Name)
                : Expression.Property(parameter, property);

            var orderByExpression = Expression.Lambda(memberExpression, parameter);

            var orderByMethod = ascending ? "OrderBy" : "OrderByDescending";

            var resultExpression = Expression.Call(
                typeof(Queryable),
                orderByMethod,
                new Type[] { type, property.PropertyType },
                query.Expression,
                Expression.Quote(orderByExpression)
            );

            return query.Provider.CreateQuery<T>(resultExpression);
        }

        private static PropertyInfo GetProperty(Type type, string propertyName)
        {
            var property = type.GetProperty(propertyName,
                BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

            if (property == null && type.BaseType != null)
                return GetProperty(type.BaseType, propertyName);

            return property;
        }
    }
}
