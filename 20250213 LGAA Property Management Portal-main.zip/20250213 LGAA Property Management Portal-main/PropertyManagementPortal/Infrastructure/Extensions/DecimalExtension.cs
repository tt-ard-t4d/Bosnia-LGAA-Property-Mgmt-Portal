﻿using Infrastructure.Helpers;

namespace PropertyManagementPortal.Infrastructure.Extensions
{
    public static class DecimalExtension
    {
        public static string FormatNumberToString(this decimal source, int format = 2)
        {
            var selectedFormat = (GlobalEnum.FormatNumber)format;
            return source.ToString(selectedFormat.GetDescriptionExt());
        }

        public static string FormatNumberToString(this decimal? source, int format = 2)
        {
            var selectedFormat = (GlobalEnum.FormatNumber)format;
            return source.HasValue ? source.Value.ToString(selectedFormat.GetDescriptionExt()) : string.Empty;
        }

        public static string FormatDecimalToString(this decimal source)
        {
            return source.ToString("N2");
        }
    }
}
