﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using PropertyManagementPortal.Infrastructure.Helpers;
using System.Linq;

namespace PropertyManagementPortal.Infrastructure.Extensions
{
    public static class QueryableExtension
    {
        public static IQueryable<T> SortRows<T>(this IQueryable<T> source, string? propertyName, string? direction)
        {
            bool? isDescending = IsDescending(direction);

            if (!source.Any() || string.IsNullOrEmpty(propertyName) || isDescending == null)
            {
                return source;
            }

            try
            {
                return source.OrderBy(propertyName, isDescending: isDescending.Value);
            }
            catch 
            {
                return source;
            }
        }

        private static bool? IsDescending(string? direction)
        {
            if (string.IsNullOrEmpty(direction)) return null;

            if (direction.Equals(Constants.Descending, StringComparison.OrdinalIgnoreCase)) return true;
            if (direction.Equals(Constants.Ascending, StringComparison.OrdinalIgnoreCase)) return false;

            return null;
        }
    }
}
