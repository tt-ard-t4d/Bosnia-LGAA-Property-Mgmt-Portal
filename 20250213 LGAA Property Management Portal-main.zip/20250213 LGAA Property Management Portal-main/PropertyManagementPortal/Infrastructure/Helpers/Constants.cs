﻿namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public class Constants
    {
        public const int NumberOfObjectsPerPage = 20;
        public const int DefaultPageNumber = 1;

        public static readonly string Ascending = "asc";
        public static readonly string Descending = "desc";

        public static readonly string Error = "error";
        public static readonly string Success = "success";
        public static readonly string Warning = "warning";
    }
}
