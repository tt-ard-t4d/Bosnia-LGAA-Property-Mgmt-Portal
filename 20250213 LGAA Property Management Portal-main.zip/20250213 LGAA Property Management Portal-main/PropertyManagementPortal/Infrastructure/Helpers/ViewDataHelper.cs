﻿using Azure.Storage.Blobs.Models;
using Infrastructure.Helpers;

namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public static class ViewDataHelper
    {
        public static string GetStatusColor(int? statusId)
        {
            var colors = new List<string>()
            {
                "red",
                "blue",
                "green",
                "yellow",
                "orange",
                "teal",
                "violet",
                "fuchsia"
            };
            if (statusId == null || statusId > colors.Count - 1 || statusId < 0)
            {
                return "red";
            }
            return colors[statusId.Value];
        }

        public static bool IsBuilding(byte propertyCategoryID)
        {
            byte[] data = new byte[3]
            {
                (byte)GlobalEnum.PropertyCategories.PoslovneZgrade,
                (byte)GlobalEnum.PropertyCategories.StambeneZgrade,
                (byte)GlobalEnum.PropertyCategories.OstaliObjekti,
            };
            return data.Contains(propertyCategoryID);
        }
        public static bool IsBusinessOrResidentialBuilding(byte propertyCategoryID)
        {
            byte[] data = new byte[2]
            {
                (byte)GlobalEnum.PropertyCategories.PoslovneZgrade,
                (byte)GlobalEnum.PropertyCategories.StambeneZgrade,
            };
            return data.Contains(propertyCategoryID);
        }
    }
}
