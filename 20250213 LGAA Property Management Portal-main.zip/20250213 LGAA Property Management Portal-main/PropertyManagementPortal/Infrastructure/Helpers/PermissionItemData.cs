﻿using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using Infrastructure.Models;
using Infrastructure.Helpers;
using Microsoft.AspNetCore.Http;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;

namespace Infrastructure.Helpers
{
    public class PermissionItemData
    {
        public static bool IsItemAccessible(string controle, int item)
        {
            var itemCollection = new List<int>() { 1 };


            switch (controle)
            {
                case "controle1":
                    if (LoginDataHelper.HasAdminRole && itemCollection.Contains(item))
                        return true;
                    else
                        return false;
                default:
                    return false;
            }


        }
    }
}