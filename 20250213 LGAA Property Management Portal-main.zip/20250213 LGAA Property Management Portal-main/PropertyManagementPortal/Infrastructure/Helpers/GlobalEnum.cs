﻿

using PropertyManagementPortal.Domain.Entities.App;
using System.ComponentModel;

namespace Infrastructure.Helpers
{
    /// <summary>
    /// All this must be in synch with database
    /// </summary>
    public class GlobalEnum
    {
        public enum CrudOperation
        {
            Add = 1,
            Edit = 2,
            Delete = 3
        }

        public enum Language
        {
            [Description("bs-Latn-BA")]
            ba = 1,
            [Description("en-US")]
            en = 2
        }

        public enum FormatNumber : short
        {
            [Description("N0")]
            Decimal0 = 1,
            [Description("N2")]
            Decimal2 = 2,
            [Description("N4")]
            Decimal4 = 3
        }

        public enum Email : short
        {
            EmailPasswordSetup = 1,
            EmailPasswordReset = 2,
            EmailContractDedline = 3
        }

        public enum EmailStatus : short
        {
            Developer = 1,
            Actual = 2
        }

        public enum Entity : byte
        {
            Federacija = 1,
            RS = 2,
        }

        public enum PropertyCategories : byte
        {
            PoljoprivrednoZemljiste = 1,
            GradjevinskoZemljiste = 2,
            PoslovneZgrade = 3,
            StambeneZgrade = 4,
            OstaliObjekti = 5,
        }

        public enum OBS_RBA_SPF_PropertyTypes : byte
        {
            Zgrada = 1,
            PoslovniProstor = 2,
            Stan = 3,
            Garaza = 4,
            JavnaZgradaObdaniste = 5,
            Pozoriste = 6,
            Biblioteka = 7,
            DomKulture = 8,
            Drugo = 9,
        }

        public enum PropertyStatuses : byte
        {
            UUpotrebi = 1,
            Slobodan = 2,
            SlobodanFunkcionalan = 3,
            SlobodanOstecen = 4,
            Ruiniran = 5,
            Drugo = 6,
        }

        public enum InstalledInfrastructures : byte
        {
            PristupniPut = 1,
            ElektroMreza = 2,
            SistemNavodnjavanja = 3,
            SistemZasjenjivanja = 4,
            ProtugradneMreze = 5,
            SistemZastiteOdMraza = 6,
            PristupPutnaKomunikacija = 7,
            ElektroPrikljucak = 8,
            Vodovod = 9,
            Kanalizacija = 10,
            CentralnoGrijanje = 11,
            Toplovod = 12,
            Drugo = 13
        }

        public enum ReportTypes : byte
        {
            IzvjestajOZakupuPoljoprivrednogZemljista = 1,
            IzvjestajOZakupuGradjevinskogZemljista = 2,
            IzvjestajOZakupuPoslovnihProstora = 3,
            IzvjestajOZakupuStanova = 4,
            IzvjestajOPrometuGradjevniskogZemljista = 5,
            IzvjestajOPrometuStambenihLokacija = 6,
            IzvjestajOPrometuPoslovnihObjekata = 7,
            IzvjestajOEksproprisanimNekretninama = 8,
            IzvjestajOSpornojImovini = 9
        }

        public enum ContractTypes : byte
        {
            UgovorOProdaji = 1,
            UgovorONajmuZakupuPodzakupu = 2,
            UgovorOKoncesiji = 3,
            Drugo = 4,
        }

        public enum PropertyUseBasis : byte
        {
            Zakup = 1,
            Podzakup = 2,
            Koncesija = 3,
            Prodaja = 4,
            Drugo = 5
        }

        public enum AttachmentTypes : short
        {
            Property = 1,
            PropertyLeaseData = 2,
        }

        public enum OwnershipRightsTypes : short
        {
            UgovorOZamjeni = 1,
            KupoprodajniUgovor = 2,
            Nasljeđivanje = 3,
            Eksproprijacija = 4,
            Drugo = 5
        }
    }
}