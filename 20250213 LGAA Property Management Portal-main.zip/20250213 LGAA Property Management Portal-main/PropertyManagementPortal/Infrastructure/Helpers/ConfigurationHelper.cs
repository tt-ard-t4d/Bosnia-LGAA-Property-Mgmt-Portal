﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text.Json;

namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public static class ConfigurationHelper
    {
        private static IConfiguration _config;

        public static void Initialize(IConfiguration config)
        {
            _config = config;
        }

        public static string GetConfig(string key)
        {
            return _config.GetSection(key).Value;
        }
    }
}
