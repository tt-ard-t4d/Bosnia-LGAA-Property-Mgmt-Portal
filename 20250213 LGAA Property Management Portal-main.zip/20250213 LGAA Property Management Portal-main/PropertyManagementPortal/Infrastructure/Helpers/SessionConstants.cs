﻿namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public class SessionConstants
    {
        public static readonly string UserGroups = "userGroups";
        public static readonly string Actions = "actions";
    }
}
