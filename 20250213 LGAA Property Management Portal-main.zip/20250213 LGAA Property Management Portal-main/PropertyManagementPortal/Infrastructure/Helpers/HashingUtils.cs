﻿using AngleSharp.Css.Values;
using DocumentFormat.OpenXml.InkML;
using System;
using System.Drawing.Text;
using System.Security.Cryptography;
using System.Text;

namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public static class HashingUtils
    {
        private const int keySize = 64;
        private const int iterations = 350000;
        private static readonly HashAlgorithmName hashAlgorithm = HashAlgorithmName.SHA512;
        private const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        public static string HashPassword(string password, out string salt)
        {
            var saltGen = RandomNumberGenerator.GetBytes(keySize);

            var hash = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                saltGen, 
                iterations, 
                hashAlgorithm: HashAlgorithmName.SHA512, keySize);

            salt = Convert.ToBase64String(saltGen);

            return Convert.ToHexString(hash);
        }

        public static bool VerifyPassword(string password, string hash, string salt)
        {
            var saltArray = Convert.FromBase64String(salt);
            var hashToCompare = Rfc2898DeriveBytes.Pbkdf2(password, saltArray, iterations, hashAlgorithm, keySize);

            return hashToCompare.SequenceEqual(Convert.FromHexString(hash));
        }

        public static string GenerateRandomString(int length = 15)
        {
            Random random = new Random();

            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
