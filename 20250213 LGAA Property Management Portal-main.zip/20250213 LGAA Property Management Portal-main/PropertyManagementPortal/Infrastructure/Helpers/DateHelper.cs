﻿using System.Globalization;

namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public class DateHelper
    {
        public static string GetDateFormat()
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
        }
    }
}
