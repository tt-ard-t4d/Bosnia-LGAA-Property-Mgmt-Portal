﻿using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using Infrastructure.Models;
using Infrastructure.Helpers;
using Microsoft.AspNetCore.Http;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;

namespace Infrastructure.Helpers
{
    /// <summary>
    /// OBRISATI CITAVU KLASU
    /// </summary>
    public class LoginDataHelper
    {

        #region <!--- USER --->
        public static UserData LoggedUser
        {
            get { return GetLoggedUserData(); }
            set { SetLoggedUserData(value); }
        }

        private static UserData GetLoggedUserData()
        {
            return AppSettingsHelper.GetContxt<UserData>("CurrentUser");
        }

        private static void SetLoggedUserData(UserData user)
        {
            AppSettingsHelper.SetContxt<UserData>("CurrentUser", user);
        }

        public static Guid LoggedUserId
        {
            get { return GetLoggedUserData() != null ? GetLoggedUserData().UserID : Guid.Empty; }
        }

        public static bool IsLogged
        {
            get
            {
                return LoggedUser != null ? true : false;
            }
        }

        public static void ClearLoggedUser()
        {
            LoggedUser = null;
        }

        public static int CurrentImpersonatedUserID
        {
            get { return GetLoggedUserIDImpersonatedData(); }
            set { SetLoggedUserIDImpersonatedData(value); }
        }

        private static int GetLoggedUserIDImpersonatedData()
        {
            return AppSettingsHelper.GetContxt<int>("CurrentImpersonatedUserID") != null ? AppSettingsHelper.GetContxt<int>("CurrentImpersonatedUserID") : 0;
        }

        private static void SetLoggedUserIDImpersonatedData(int id)
        {
            AppSettingsHelper.SetContxt<int>("CurrentImpersonatedUserID", id);
        }

        public static string CurrentImpersonatedUserEmail
        {
            get { return GetLoggedUserEmailImpersonatedData(); }
            set { SetLoggedUserEmailImpersonatedData(value); }
        }

        private static string GetLoggedUserEmailImpersonatedData()
        {
            return AppSettingsHelper.GetContxt<string>("CurrentImpersonatedUserEmail");
        }

        private static void SetLoggedUserEmailImpersonatedData(string email)
        {
            AppSettingsHelper.SetContxt<string>("CurrentImpersonatedUserEmail", email);
        }

        public static bool IsPowerAdmin()
        {

            var powerAdmins = AppSettingsHelper.GetConfig("AppIdentitySettings:HashingUtils");
            var id = LoginDataHelper.CurrentImpersonatedUserID;
            string[] parts = powerAdmins.Split(';');

            return parts.Any(s => int.Parse(s) == id);
        }

        public static bool IsPowerAdminControl()
        {

            var powerAdmins = AppSettingsHelper.GetConfig("AppIdentitySettings:HashingUtils");
            var id = LoginDataHelper.LoggedUserId;
            string[] parts = powerAdmins.Split(';');

            return parts.Any(s => new Guid(s).Equals(id));
        }

        #endregion

        #region <!--- ROLE --->

        private static List<UserDataGroup> GetRoles()
        {
            return LoggedUser.UserGroups;
        }

        public static List<UserDataGroup> SelectedRoles
        {
            get { return GetRoles(); }
        }

        public static List<int> SelectedRoleIds
        {
            get { return GetRoles().Select(r => r.UserGroupID).ToList(); }
        }

        public static bool HasMultipleRoles
        {
            get
            {
                if (IsLogged)
                {
                    return LoggedUser.UserGroups.Count > 1 ? true : false;
                }
                else
                    return false;
            }
        }

        public static bool HasOneRoles
        {
            get
            {
                if (IsLogged)
                {
                    return LoggedUser.UserGroups.Count == 1 ? true : false;
                }
                else
                    return false;
            }
        }

        public static bool HasAdminRole
        {
            get
            {
                return LoggedUser?.UserGroups.Where(r => r.UserGroupID == (int)ActionManagementEnum.UserGroups.Administrator).Count() > 0 ? true : false;
            }
        }

        public static bool HasOtherUserRoles(int userRoleId)
        {
            return LoggedUser?.UserGroups.Where(r => r.UserGroupID != userRoleId).Count() > 0 ? true : false;
        }

        private static UserDataGroup GetRole()
        {
            return AppSettingsHelper.GetContxt<UserDataGroup>("CurrentUserRole");
        }

        private static void SetRole(UserDataGroup role)
        {
            AppSettingsHelper.SetContxt<UserDataGroup>("CurrentUserRole", role);
        }

        public static UserDataGroup SelectedRole
        {
            get { return GetRole(); }
            set { SetRole(value); }
        }


        #endregion

        #region <--- HIDE CONTROL --->

        public static bool IsControlVisibleHide(string controle)
        {
            switch (controle)
            {
                case "controle1":
                    if (LoginDataHelper.IsPowerAdminControl())
                        return true;
                    else
                        return false;
                case "controle2":
                    return false;
                default:
                    return true;
            }


        }
        public static bool IsControlEditable(string controle, int? status)
        {
            switch (controle)
            {
                case "controle1":
                    if (status == 1 || status == 3 || LoginDataHelper.IsPowerAdminControl())
                        return true;
                    else
                        return false;
                case "controle2":
                    if (status == 1 || status == null || status == 3 || LoginDataHelper.IsPowerAdminControl())
                        return true;
                    else
                        return false;
                default:
                    return false;
            }


        }


        #endregion

        #region <--- LoggedUserDeviceInfo --->



        public static List<LoggedUserDevice> LoggedUserDeviceInfo
        {
            get { return GetLoggedUserDevice(); }
            set { SetLoggedUserDevice(value.First()); }

        }

        public static List<LoggedUserDevice> LoggedUserDeviceList = new List<LoggedUserDevice>();

        public class LoggedUserDevice
        {
            public string Email { get; set; }
            public string Device { get; set; }

            public string SesssionID { get; set; }
        }

        private static List<LoggedUserDevice> GetLoggedUserDevice()
        {
            return LoggedUserDeviceList.ToList();
        }

        private static void SetLoggedUserDevice(LoggedUserDevice userDevice)
        {
            LoggedUserDeviceList.Add(userDevice);
        }

        public static void RemoveLoggedUserDevice(string sessionID)
        {
            LoggedUserDeviceList.RemoveAll(u => u.SesssionID == sessionID);
        }


        #endregion

    }
}