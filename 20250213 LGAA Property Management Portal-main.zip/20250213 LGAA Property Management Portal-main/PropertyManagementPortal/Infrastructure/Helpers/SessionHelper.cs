﻿using Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Extensions;

namespace PropertyManagementPortal.Infrastructure.Helpers
{
    public static class SessionHelper
    {
        public static void SetUserData(this ISession session, UserData user)
        {
            session.SetValue(SessionConstants.Actions, user.UserActions);
            session.SetValue(SessionConstants.UserGroups, user.UserGroups);
        }
    }
}
