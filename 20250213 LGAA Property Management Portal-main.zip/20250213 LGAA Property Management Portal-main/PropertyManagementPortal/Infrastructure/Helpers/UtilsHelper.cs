﻿using Ganss.Xss;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Infrastructure.Helpers
{
    /// <summary>
    /// Dodati implementacije, provjeriti prvo
    /// </summary>
    public static class UtilsHelper
    {
        public static string GetSafeInput(string input)
        {
            if (!String.IsNullOrEmpty(input))
            {
                var safeInput = input;

                safeInput = Regex.Replace(safeInput, @"\=.*?cmd\b", "", RegexOptions.IgnoreCase);

                var sanitizer = new HtmlSanitizer();
                safeInput = sanitizer.Sanitize(safeInput);

                return safeInput;
            }

            return string.Empty;
        }

        public static (string? columnName, string? direction) GetSortOrder(string sort)
        {
            if (String.IsNullOrEmpty(sort)) return (null, null);
            var str = sort.Split("_");
            return ((str.Length > 0) ? str[0] : "", (str.Length > 1) ? str[1] : "");
        }

        public static string Slugify(this string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }

            // Convert to lowercase
            input = input.ToLowerInvariant();

            // Remove all accents and diacritical marks
            input = RemoveDiacritics(input);

            // Replace all non-alphanumeric characters with hyphens
            input = Regex.Replace(input, @"[^a-z0-9]+", "-");

            // Trim hyphens from the start and end of the string
            input = input.Trim('-');

            return input;
        }

        private static string RemoveDiacritics(string input)
        {
            var normalizedString = input.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }

        public static string Label(this string? input)
        {
            return !string.IsNullOrEmpty(input) ? input : LabelsRes.NoData;
        }
    }
}
