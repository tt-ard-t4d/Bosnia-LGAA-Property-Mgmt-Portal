﻿using Authorization;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Core.Admin;
using PropertyManagementPortal.Infrastructure.Core.PMP;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;
using System.Linq;

namespace PropertyManagementPortal.Controllers.Admin
{

    [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator)]
    public class UserController : Controller
    {
        private readonly UserService _userService;
        private readonly MunicipalityService _municipalityService;
        private readonly ReportingService _reportingService;
        private readonly DropDownService _ddl;
        private readonly PMPDropDownService _pmpDdl;
        private readonly SessionService _sessionService;
        private readonly IValidator<UserDTO> _validator;

        public UserController(UserService userService, DropDownService ddl, PMPDropDownService pmpDDL, ReportingService reportingService, SessionService sessionService, IValidator<UserDTO> validator, MunicipalityService municipalityService)
        {
            _userService = userService;
            _municipalityService = municipalityService;
            _ddl = ddl;
            _pmpDdl = pmpDDL;
            _reportingService = reportingService;
            _sessionService = sessionService;
            _validator = validator;
        }

        #region <!-- User -->

        public IActionResult Index(SearchUserDTO args)
        {
            CreateFilterDDL(ref args);
            if (SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator))
            {
                return View(_userService.GetAllUsersGrid(args));
            }
            var userId = User.GetLoggedUserId();
            return View(_userService.GetMunicipalityUsersGrid(args, userId));

        }

        public IActionResult Create()
        {
            var model = new UserDTO();
            CreateAddEditDDL(ref model);

            return View("Edit", model);
        }

        public IActionResult SaveFailed(UserDTO model)
        {
            CreateAddEditDDL(ref model);
            return View("Edit", model);
        }

        public IActionResult Edit(Guid userId)
        {
            var user = _userService.GetUser(userId);

            if (user.UserID != Guid.Empty)
            {
                CreateAddEditDDL(ref user);
                return View("Edit", user);
            }

            return View("Error");
        }

        [HttpPost]
        public IActionResult Save(UserDTO model)
        {
            if (!SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator))
            {
                if (model.UserGroupIDs.Contains((int)ActionManagementEnum.UserGroups.Administrator))
                    model.UserGroupIDs.Remove((int)ActionManagementEnum.UserGroups.Administrator);
                var userMunicipalities = _userService.GetUserMunicipalities(User.GetLoggedUserId()) ?? new List<int>();
                model.MunicipalityIDs.RemoveAll(id => !userMunicipalities.Contains(id));
            }
            var validate = _validator.Validate(model);

            if (!validate.IsValid)
            {
                validate.AddToModelState(this.ModelState);

                if (model.UserID != Guid.Empty)
                {
                    return RedirectToAction("Edit", "User", new { userId = model.UserID });
                }

                return RedirectToAction("Create", "User");
            }

            if (ModelState.IsValid)
            {
                var ddlCheck = model.UserGroupIDs.IsValidList(_ddl.GetUserGroups(SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator)));

                if (!ddlCheck)
                {
                    CreateAddEditDDL(ref model);
                    return View("Edit", model);
                }

                var save = _userService.Save(model, User.Identity.GetLoggedUserId());

                if (!save.IsError)
                {
                    _sessionService.SessionUpdateOnUserUpdate(HttpContext, save.Guid);
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("Index", "User");
                }

                TempData["error-message"] = save.ErrorMessage;
                CreateAddEditDDL(ref model);
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            CreateAddEditDDL(ref model);
            return View("Edit", model);
        }

        [HttpPost]
        public IActionResult Delete(Guid id)
        {
            Guid loggedUserId = User.GetLoggedUserId();
            var res = _userService.Delete(id, loggedUserId);

            if (!res.IsError)
                TempData["success-message"] = MessageRes.Success;
            else
                TempData["error-message"] = MessageRes.Error;

            RetValue retValue = new()
            {
                ReturnUrl = Url.Action("Index", "User"),
            };

            return Json(retValue);
        }

        #endregion

        #region <!-- DDL -->

        private void CreateFilterDDL(ref SearchUserDTO args)
        {
            args.UserGroups = _ddl.GetUserGroups(SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator));
            args.Municipalities = _ddl.GetMunicipalities();
        }

        private void CreateAddEditDDL(ref UserDTO args)
        {
            args.UserActions = _ddl.GetActions();
            args.UserGroups = _ddl.GetUserGroups(SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator));
            if (SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator))
                args.Municipalities = _pmpDdl.GetAllMunicipalities();
            else
                args.Municipalities = _pmpDdl.GetMunicipalitiesForUser(User.GetLoggedUserId());
        }

        #endregion

        #region <!-- Reporting -->

        [HttpGet]
        public ActionResult RenderReport(SearchUserDTO args)
        {
            var data = _userService.GetAllUsersGrid(args).Data.ToList();
            Tuple<MemoryStream, string> _excel = _reportingService.CreateDefaultReport(data, "report1");
            return File(_excel.Item1.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _excel.Item2);
        }

        #endregion

    }
}
