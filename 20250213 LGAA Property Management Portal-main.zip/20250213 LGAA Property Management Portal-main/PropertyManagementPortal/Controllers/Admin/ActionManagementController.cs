﻿using Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Core.Admin;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Controllers.Admin
{
    [PowerAdminAuthorize]
    public class ActionManagementController : Controller
    {
        private readonly ActionManagementService _actionManagementService;
        private readonly ReportingService _reportingService;
        private readonly DropDownService _ddl;
        private readonly SessionService _sessionService;

        public ActionManagementController(ActionManagementService actionManagementService, DropDownService ddl, ReportingService reportingService, SessionService sessionService)
        {
            _actionManagementService = actionManagementService;
            _ddl = ddl;
            _reportingService = reportingService;
            _sessionService = sessionService;
        }

        #region <!-- Action -->

        public IActionResult IndexAction(SearchActionDTO args)
        {
            CreateFilterDDL(ref args);

            return View(_actionManagementService.GetActionGrid(args));
        }

        public IActionResult IndexActionTemporal(SearchActionDTO args)
        {
            //CreateFilterDDL(ref args);

            return View("IndexActionTemporal", _actionManagementService.GetActionTemporalGrid(args));
        }

        public IActionResult CreateAction()
        {
            var model = new ActionDTO();
            CreateAddEditDDL(ref model);

            return View("EditAction", model);
        }

        public IActionResult EditAction(int actionId)
        {
            var action = _actionManagementService.GetAction(actionId);

            if (action.ActionID > 0)
            {
                return View("EditAction", action);
            }

            return View("EditAction");
        }

        [HttpPost]
        public IActionResult SaveAction(ActionDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _actionManagementService.SaveAction(model, User.Identity.GetLoggedUserId());

                if (!save.IsError)
                {
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("IndexAction", "ActionManagement");
                }

                TempData["error-message"] = MessageRes.SaveError;
                CreateAddEditDDL(ref model);
                return View("EditAction", model);
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            CreateAddEditDDL(ref model);
            return View("EditAction", model);
        }

        #endregion

        #region <!-- User Group -->

        public IActionResult IndexUserGroup(SearchUserGroupDTO args)
        {
            return View(_actionManagementService.GetUserGroupGrid(args));
        }

        public IActionResult CreateUserGroup()
        {
            var model = new UserGroupDTO();

            return View("EditUserGroup", model);
        }

        public IActionResult EditUserGroup(int userGroupId)
        {
            var userGroup = _actionManagementService.GetUserGroup(userGroupId);

            if (userGroup.UserGroupID > 0)
            {
                return View("EditUserGroup", userGroup);
            }

            return View("EditUserGroup");
        }

        [HttpPost]
        public IActionResult SaveUserGroup(UserGroupDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _actionManagementService.SaveUserGroup(model, User.Identity.GetLoggedUserId());

                if (!save.IsError)
                {
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("IndexUserGroup", "ActionManagement");
                }

                TempData["error-message"] = MessageRes.SaveError;
                return View("EditUserGroup", model);
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return View("EditUserGroup", model);
        }

        #endregion

        #region <!-- Action assignment -->
        public IActionResult IndexActionAssignment()
        {
            return View();
        }

        public IActionResult ActionAssignment(ActionAssignmentDTO model)
        {
            CreateAssignmentDDL(ref model);
            return View("ActionAssignment", model);
        }


        [HttpPost]
        public IActionResult SaveActionsForUserGroup(ActionAssignmentDTO model)
        {
            if (ModelState.IsValid)
            {
                var validate = ValidateAssingmentSave(ref model);

                if (!validate)
                {
                    TempData["error-message"] = MessageRes.SaveError;
                    return RedirectToAction("ActionAssignment", "ActionManagement");
                }

                var save = _actionManagementService.SaveActionsForUserGroup(model);

                if (!save.IsError)
                {
                    _sessionService.SessionUpdateOnGroupActionUpdate(HttpContext, model);
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("ActionAssignment", "ActionManagement");
                }

                TempData["error-message"] = MessageRes.SaveError;
                return RedirectToAction("ActionAssignment", "ActionManagement");
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("ActionAssignment", "ActionManagement");
        }

        [HttpPost]
        public IActionResult SaveActionsForUser(ActionAssignmentDTO model)
        {
            if (ModelState.IsValid)
            {
                var validate = ValidateAssingmentSave(ref model);

                if (!validate)
                {
                    TempData["error-message"] = MessageRes.SaveError;
                    return RedirectToAction("ActionAssignment", "ActionManagement");
                }

                var save = _actionManagementService.SaveActionsForUser(model);

                if (!save.IsError)
                {
                    _sessionService.SessionUpdateOnUserActionUpdate(HttpContext, model);
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("ActionAssignment", "ActionManagement");
                }

                TempData["error-message"] = MessageRes.SaveError;
                return RedirectToAction("ActionAssignment", "ActionManagement");
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("ActionAssignment", "ActionManagement");
        }

        #endregion

        #region <!-- DDL -->

        private bool ValidateAssingmentSave(ref ActionAssignmentDTO model)
        {
            List<bool> validation = new List<bool>()
            {
                model.GroupActionIDs.IsValidList(_ddl.GetActions()),
                model.UserActionIDs.IsValidList(_ddl.GetActions())
            };

            return validation.TrueForAll(r => r == true);
        }

        private void CreateAssignmentDDL(ref ActionAssignmentDTO args)
        {
            args.Actions = _ddl.GetActions();
            args.UserGroups = _ddl.GetUserGroups(SessionExtension.CheckIsInUserGroup(HttpContext.Session, ActionManagementEnum.UserGroups.Administrator));
            args.Users = _ddl.GetUsers();
        }

        [HttpPost]
        public IActionResult UserGroupChanged(int parentId)
        {
            return Json(_actionManagementService.GetActionsForUserGroup(parentId));
        }

        [HttpPost]
        public IActionResult UserChanged(Guid parentId)
        {
            return Json(_actionManagementService.GetActionsForUser(parentId));
        }

        private void CreateFilterDDL(ref SearchActionDTO args)
        {

        }

        private void CreateAddEditDDL(ref ActionDTO args)
        {

        }

        #endregion

        #region <!-- Reporting -->

        [HttpGet]
        public ActionResult RenderReport(SearchActionDTO args)
        {
            var data = _actionManagementService.GetActionGrid(args).Data.ToList();

            Tuple<MemoryStream, string> _excel = _reportingService.CreateDefaultReport(data, "property-report");
            return File(_excel.Item1.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _excel.Item2);
        }

        #endregion

    }
}
