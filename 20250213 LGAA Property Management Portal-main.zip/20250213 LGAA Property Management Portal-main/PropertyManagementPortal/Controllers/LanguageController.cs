﻿using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;

namespace PropertyManagementPortal.Controllers
{
    public class LanguageController : Controller
    {
        [HttpPost]
        public IActionResult SetLanguage(string culture, string returnUrl)
        {
            Response.Cookies.Append(
                CookieRequestCultureProvider.DefaultCookieName,
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions 
                { 
                    Expires = DateTimeOffset.UtcNow.AddMonths(1),
                    HttpOnly = true,
                    SameSite = SameSiteMode.Strict
                }
            );

            return LocalRedirect(returnUrl);
        }

        public IActionResult Index()
        {
            return View("Language");
        }
    }
}
