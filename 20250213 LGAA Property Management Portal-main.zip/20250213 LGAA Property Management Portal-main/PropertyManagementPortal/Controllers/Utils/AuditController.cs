﻿using Authorization;
using Infrastructure.Core;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Core.Utils;

namespace PropertyManagementPortal.Controllers.Utils
{
    public class AuditController : Controller
    {
        private readonly DropDownService _ddl;
        private readonly AuditLogService _auditLogService;

        public AuditController(DropDownService ddl, AuditLogService auditLogService)
        {
            _ddl = ddl;
            _auditLogService = auditLogService;
        }


        // GET: Audit
        [PowerAdminAuthorize]
        public ActionResult Index(SearchAuditLogDTO args)
        {

            CreateFilterDDL(ref args);

            var audits = _auditLogService.GetAuditLogGrid(args);

            foreach (var item in audits.Data)
            {
                item.AuditLogEnumerationName = args.AuditLogEnumerations.Where(e => e.Id == item.AuditLogEnumerationID).FirstOrDefault()?.Value;
            }

            return View(audits);
        }

        #region <!-- DDL -->

        private void CreateFilterDDL(ref SearchAuditLogDTO args)
        {
            args.AuditLogEnumerations = _ddl.GetAuditType();
        }


        #endregion
    }
}
