﻿using Domain.Entities.Utils;
using Infrastructure.Core;
using Infrastructure.Helpers;
using Infrastructure.Models.Utils.Email;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.Infrastructure.Core.Admin;
using PropertyManagementPortal.Infrastructure.Core.PMP;
using PropertyManagementPortal.Infrastructure.Resources;
using static Infrastructure.Helpers.GlobalEnum;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PropertyManagementPortal.Controllers.Utils
{
    public class EmailNotifyController : Controller
    {
        private readonly PropertyLeaseDataService _propertyDataService;
        private readonly UserService _userService;
        private readonly EmailService _emailService;

        public EmailNotifyController(PropertyLeaseDataService propertyDataService, UserService userService, EmailService emailService)
        {
            _propertyDataService = propertyDataService;
            _userService = userService;
            _emailService = emailService;   
        }


        public void SendEmailContractDeadline()
        {
            var getPropertyData = _propertyDataService.GetAllPropertyLeaseData();

            foreach (var item in getPropertyData)
            {
                if (item.ContractConclusionDate != null && item.ContractDurationInMonths != null) {
                   
                    DateTime startDate = DateTime.Parse(item.ContractConclusionDate.ToString());
                    DateTime endDate = startDate.AddMonths((int)item.ContractDurationInMonths);
                    var dt = (int)(endDate - DateTime.Now).TotalDays;

                    var user = _userService.GetUser(item.SysCreatedByUserID);

                    switch (dt)
                    {
                        case 45:
                            _emailService.SendEmailContractDedline(item, user);
                            break;
                        default:
                            break;
                    }
                }
            }

        }

    }
}
