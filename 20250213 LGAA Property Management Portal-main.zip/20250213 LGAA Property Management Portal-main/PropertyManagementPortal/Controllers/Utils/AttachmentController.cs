﻿using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.Infrastructure.Core.Utils;

namespace PropertyManagementPortal.Controllers.Utils
{
    public class AttachmentController : Controller
    {
        private readonly AttachmentService _attachmentService;
        private readonly IHttpClientFactory _httpClientFactory;

        public AttachmentController(AttachmentService attachmentService, IHttpClientFactory httpClientFactory)
        {
            _attachmentService = attachmentService;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> DownloadFile(string s)
        {
            var file = _attachmentService.GetFileById(new Guid(s));

            var fileUrl = file.Link;
            var httpClient = _httpClientFactory.CreateClient();
            var fileStream = await httpClient.GetStreamAsync(fileUrl);
            var contentType = file.MimeType;
            var fileName = file.Name;
            return File(fileStream, contentType ?? "application/octet-stream", fileName);
        }
    }
}
