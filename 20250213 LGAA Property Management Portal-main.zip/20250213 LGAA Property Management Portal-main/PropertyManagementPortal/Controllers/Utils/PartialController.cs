﻿using Microsoft.AspNetCore.Mvc;

namespace PropertyManagementPortal.Controllers.Utils
{
    public class PartialController : Controller
    {
        public PartialViewResult ConfirmationModal()
        {
            return PartialView("~/Views/Utils/Partial/_ConfirmationModal.cshtml");
        }
    }
}
