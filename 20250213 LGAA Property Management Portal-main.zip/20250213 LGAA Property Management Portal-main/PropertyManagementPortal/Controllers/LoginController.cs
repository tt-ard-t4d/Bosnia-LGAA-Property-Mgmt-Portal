﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.Infrastructure.Core;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Helpers;
using Microsoft.AspNetCore.Identity;
using PropertyManagementPortal.Infrastructure.Core.Admin;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Resources;
using PropertyManagementPortal.Infrastructure.Utility;
using Infrastructure.Core;

namespace PropertyManagementPortal.Controllers
{
    public class LoginController : Controller
    {
        private readonly LoginService _loginService;
        private readonly UserService _userService;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly IConfiguration _configuration;
        private readonly EmailService _emailService;

        public LoginController(LoginService loginService, SignInManager<IdentityUser> signInManager, UserService userService, IConfiguration configuration, EmailService emailService)
        {
            _loginService = loginService;
            _signInManager = signInManager;
            _userService = userService;
            _configuration = configuration;
            _emailService = emailService;
        }

        #region <!-- Login -->

        public IActionResult Login(string returnUrl = "")
        {
            var model = new LoginDTO() { ReturnUrl = returnUrl };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginDTO model, string returnUrl = "")
        {
            if (ModelState.IsValid)
            {
                var user = _loginService.ValidateUser(model.UserName, model.Password);

                if (user.UserID != Guid.Empty)
                {
                    var userPrincipal = _loginService.AddClaims(model, user);

                    HttpContext.Session.SetUserData(user);
                    await HttpContext.SignInAsync(userPrincipal);

                    if (!String.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }

                    return RedirectToAction("Index", "Home");
                }

                TempData["error-message"] = MessageRes.LoginError;
                return RedirectToAction("Login", "Login", new { ReturnUrl = returnUrl }); ;
            }

            TempData["error-message"] = MessageRes.Error;
            return RedirectToAction("Login", "Login", new { ReturnUrl = returnUrl });
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            HttpContext.Session.Clear();
            await _signInManager.SignOutAsync();

            return RedirectToAction("Index", "Home");
        }

        #endregion

        #region <!-- Password Reset -->

        public IActionResult PasswordReset(string verificationCode)
        {
            if (!string.IsNullOrEmpty(verificationCode))
            {
                var user = _userService.GetUserByEmailCode(verificationCode);

                if (user.UserID != Guid.Empty)
                {
                    var model = new ResetPasswordDTO();
                    model.VerificationCode = verificationCode;

                    return View("PasswordReset", model);
                }
            }

            return RedirectToAction("Index", "Home");
        }

        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ForgotPassword(string email)
        {
            if (!string.IsNullOrEmpty(email))
            {
                var emailEnc = SEDManager.Protect(email, _configuration);
                var user = _userService.GetUserByEmailEnc(emailEnc);

                if (user.UserID != Guid.Empty)
                {
                    _emailService.SendEmailPasswordReset02(user);
                }
            }

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public IActionResult SavePassword(ResetPasswordDTO resetPassword)
        {
            if (ModelState.IsValid)
            {
                var ret = _userService.ResetPassword(resetPassword);

                if (!ret.IsError)
                {
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("Index", "Home");
                }

                TempData["error-message"] = MessageRes.Error;
                return RedirectToAction("Index", "Home");
            }

            TempData["success-message"] = MessageRes.InvalidModel;
            return RedirectToAction("Index", "Home");
        }

        #endregion

        #region RegionExternalLoginLogout

        //public async Task<IActionResult> GetExternalLogin([FromRoute] string scheme, string returnUrl)
        //{
        //    await HttpContext.SignOutAsync(IdentityConstants.ExternalScheme);

        //    scheme = scheme ?? AzureADDefaults.AuthenticationScheme;
        //    var redirectUrl = Url.Action("ExternalLoginCallback", "Login", new { returnUrl });
        //    var properties = _signInManager.ConfigureExternalAuthenticationProperties(scheme, redirectUrl);
            
        //    return new ChallengeResult(scheme, properties);

        //}

        //public async Task<IActionResult> ExternalLoginCallback(string returnUrl = null, string remoteError = null)
        //{
        //    var info = await _signInManager.GetExternalLoginInfoAsync();

        //    if (info == null)
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }

        //    var preferredUsername = info.Principal.FindFirstValue("preferred_username");

        //    if (!string.IsNullOrEmpty(preferredUsername))
        //    {
        //        var user = _loginService.ValidateDirectoryUserEmail(preferredUsername);

        //        if (user.UserID != Guid.Empty)
        //        {
        //            var model = new LoginDTO()
        //            {
        //                UserName = user.UserName,
        //                IsDirectoryUserLogedIn = true
        //            };

        //            var userPrincipal = _loginService.AddClaims(model, user);

        //            HttpContext.Session.SetUserData(user);
        //            await HttpContext.SignInAsync(userPrincipal);

        //            if (!String.IsNullOrEmpty(returnUrl))
        //            {
        //                return Redirect(returnUrl);
        //            }

        //            return RedirectToAction("Index", "Home");
        //        }
        //    }

        //    return RedirectToAction("Index", "Home");

        //}

        //public async Task<IActionResult> ExternalLogout([FromRoute] string scheme, string returnUrl = null)
        //{
          
        //    await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        //    HttpContext.Session.Clear();
        //    await _signInManager.SignOutAsync();
        //    return LocalRedirect("/");


        //}



        #endregion
    }
}
