﻿using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.Infrastructure.Extensions;

namespace PropertyManagementPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
   
        public IActionResult Index()
        {
            if(User.IsLoggedIn())
            {
                return RedirectToAction("Index", "Property");
            }
            return RedirectToAction("Login", "Login");
        }

        public string Culture()
        {
            return Thread.CurrentThread.CurrentCulture.Name;
        }

        public IActionResult Info()
        {
            return View();
        }

        public IActionResult Help()
        {
            return View();
        }

        public IActionResult NotAuthorized()
        {
            return View();
        }
    }
}