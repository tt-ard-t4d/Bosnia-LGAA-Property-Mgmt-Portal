﻿using Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.PropertyValue;
using PropertyManagementPortal.Infrastructure.Core.PMP;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Controllers.PMP
{
    public class PropertyValueController : Controller
    {
        private readonly PropertyValueService _service;

        public PropertyValueController(PropertyValueService service)
        {
            _service = service;
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult Index(SearchPropertyValueDTO args)
        {
            return View(_service.GetPropertyValuesGrid(args));
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Create(Guid propertyID)
        {
            var model = new PropertyValueDTO
            {
                PropertyID = propertyID
            };
            return View("Edit", model);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Edit(Guid propertyValueID)
        {
            var model = _service.GetPropertyValueById(propertyValueID);

            if (model.PropertyID != Guid.Empty)
            {
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.MissingItem;
            return RedirectToAction("Index", "Property");
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Save(PropertyValueDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _service.Save(model, User.Identity.GetLoggedUserId());

                if (save.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return RedirectToAction("Edit", "PropertyValue", new { propertyValueID = save.Guid });
                }

                TempData["success-message"] = MessageRes.Success;
                return RedirectToAction("Edit", "PropertyValue", new { propertyValueID = save.Guid });
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("Edit", "PropertyValue", new { propertyValueID = model.PropertyValueID });
        }

        public IActionResult SaveAndRedirect(PropertyValueDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _service.Save(model, User.Identity.GetLoggedUserId());

                if (save.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return RedirectToAction("Index", "PropertyValue", new { PropertyId = model.PropertyID });
                }

                TempData["success-message"] = MessageRes.Success;
                return RedirectToAction("Index", "PropertyValue", new { PropertyId = model.PropertyID });
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("Index", "PropertyValue", new { PropertyId = model.PropertyID });
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Delete(Guid id)
        {
            Guid loggedUserId = User.GetLoggedUserId();
            var res = _service.Delete(id, loggedUserId);

            if (!res.IsError)
                TempData["success-message"] = MessageRes.Success;
            else
                TempData["error-message"] = MessageRes.Error;

            RetValue retValue = new()
            {
                ReturnUrl = Url.Action("Index", "PropertyValue", new { PropertyId = res.Guid }) ?? "/",
                Guid = res.Guid,
            };

            return Json(retValue);
        }
    }
}
