﻿using Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.Municipality;
using PropertyManagementPortal.Infrastructure.Core.PMP;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Controllers.PMP
{
    [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator)]
    public class MunicipalityController : Controller
    {
        private readonly MunicipalityService _service;
        private readonly PMPDropDownService _dropdownService;

        public MunicipalityController(MunicipalityService service, PMPDropDownService dropdownService)
        {
            _service = service;
            _dropdownService = dropdownService;
        }

        public IActionResult Index(SearchMunicipalityDTO args)
        {
            CreateFilterDDL(ref args);
            return View(_service.GetMunicipalityGrid(args));
        }

        public IActionResult Create()
        {
            var model = new MunicipalityEditDTO();
            CreateAddEditDDL(ref model);

            return View("Edit", model);
        }

        [HttpPost]
        public IActionResult Save(MunicipalityEditDTO model)
        {
            if (ModelState.IsValid)
            {
                var res = _service.Save(model, User.Identity.GetLoggedUserId());

                if (!res.IsError)
                {
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("Index", "Municipality");
                }

                TempData["error-message"] = res.ErrorMessage;
                CreateAddEditDDL(ref model);
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            CreateAddEditDDL(ref model);
            return View("Edit", model);
        }

        [HttpPost]
        public JsonResult Delete(int id)
        {
            if (id > 0)
            {
                var res = _service.DeleteMunicipality(id);

                if (res.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return new JsonResult(new RetValue() { IsError = true, ReturnUrl = Url.Action("Index", "Municipality") });
                }

                TempData["success-message"] = MessageRes.Success;
                return new JsonResult(new RetValue() { IsError = true, ReturnUrl = Url.Action("Index", "Municipality") });
            }

            TempData["error-message"] = MessageRes.Error;
            return new JsonResult(new RetValue() { IsError = true, ReturnUrl = Url.Action("Index", "Municipality") });
        }


        [HttpGet]
        public JsonResult GetRetiredMunicipality(int id)
        {
            return Json(_service.GetRetiredMunicipality(id));
        }

        private void CreateAddEditDDL(ref MunicipalityEditDTO args)
        {
            args.Municipalities = _dropdownService.GetRetiredMunicipalities();
        }

        private void CreateFilterDDL(ref SearchMunicipalityDTO args)
        {
            args.Entities = _dropdownService.GetEntities();
        }
    }
}
