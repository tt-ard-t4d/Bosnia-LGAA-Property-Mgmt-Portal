﻿using Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.Infrastructure.Core.PMP;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Controllers.PMP
{
    public class PropertyLeaseDataController : Controller
    {
        private readonly PropertyLeaseDataService _service;
        private readonly PropertyLeaseDataDDLService _ddlService;
        private readonly PropertyService _propertyService;
        private readonly ReportingService _reportService;
        private readonly PropertyLeaseDataReportService _lddReportService;

        public PropertyLeaseDataController(PropertyLeaseDataService service, PropertyLeaseDataDDLService ddlService, PropertyService propertyService, ReportingService reportService, PropertyLeaseDataReportService lddReportService)
        {
            _service = service;
            _propertyService = propertyService;
            _ddlService = ddlService;
            _reportService = reportService;
            _lddReportService = lddReportService;
        }
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult Index(SearchPropertyLeaseDataDTO args)
        {
            return View(_service.GetPropertyLeaseDataGrid(args));
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Create(Guid PropertyID)
        {
            var model = new PropertyLeaseDataDTO();
            CreateAddEditDDL(ref model, PropertyID);
            return View("Edit", model);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Edit(Guid propertyLeaseDataID)
        {
            var model = _service.GetPropertyLeaseDataById(propertyLeaseDataID);

            if (model.PropertyID != Guid.Empty)
            {
                CreateAddEditDDL(ref model, model.PropertyID);
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.MissingItem;
            return RedirectToAction("Index", "Property");
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Save(PropertyLeaseDataDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _service.Save(model, User.Identity.GetLoggedUserId());

                if (save.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return RedirectToAction("Edit", "PropertyLeaseData", new { propertyLeaseDataID = save.Guid });
                }

                TempData["success-message"] = MessageRes.Success;
                return RedirectToAction("Edit", "PropertyLeaseData", new { propertyLeaseDataID = save.Guid });
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("Edit", "PropertyLeaseData", new { propertyLeaseDataID = model.PropertyLeaseDataID });
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult SaveAndRedirect(PropertyLeaseDataDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _service.Save(model, User.Identity.GetLoggedUserId());

                if (save.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return RedirectToAction("Index", "PropertyLeaseData", new { PropertyID = model.PropertyID });
                }

                TempData["success-message"] = MessageRes.Success;
                return RedirectToAction("Index", "PropertyLeaseData", new { PropertyID = model.PropertyID });
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("Index", "PropertyLeaseData", new { PropertyID = model.PropertyID });
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Delete(Guid id)
        {
            Guid loggedUserId = User.GetLoggedUserId();
            var res = _service.Delete(id, loggedUserId);

            if (!res.IsError)
                TempData["success-message"] = MessageRes.Success;
            else
                TempData["error-message"] = MessageRes.Error;

            RetValue retValue = new()
            {
                ReturnUrl = Url.Action("Index", "PropertyLeaseData", new { PropertyID = res.Guid }) ?? "/",
                Guid = res.Guid,
            };

            return Json(retValue);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult ExportToExcel(Guid propertyGuid)
        {
            var data = _lddReportService.GetLeaseDataForExport(propertyGuid);
            var ignoredFields = _lddReportService.GetIgnoredFieldsForLeaseData(propertyGuid);
            var reportName = _lddReportService.GetReportName(propertyGuid);
            var export = _reportService.CreateDefaultReport(data, reportName, ignoredFields);
            return File(export.Item1.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", export.Item2);
        }

        private void CreateAddEditDDL(ref PropertyLeaseDataDTO args, Guid propertyID)
        {
            byte propertyCategoryID = _propertyService.GetCategory(propertyID) ?? 0;
            args.PropertyAddress = _propertyService.GetPropertyAddress(propertyID);
            args.PropertyCategoryID = propertyCategoryID;
            args.PropertyID = propertyID;
            args.ContractTypes = _ddlService.GetContractTypes(propertyCategoryID);
            args.PropertyStatuses = _ddlService.GetPropertyStatuses(propertyCategoryID);
            args.PropertyUseBasisDocuments = _ddlService.GetPropertyUseBasisDocuments();
            args.PropertyUseBases = _ddlService.GetPropertyUseBases(propertyCategoryID);
            args.PropertyUserGenders = _ddlService.GetPropertyUserGenders();
            args.PropertyUserTypes = _ddlService.GetPropertyUserTypes();
            args.ContractTypesBasedOnUserStatus = _ddlService.GetContractTypesBasedOnUserStatus();
            args.PaymentFrequencies = _ddlService.GetPaymentFrequencies();
        }

    }
}
