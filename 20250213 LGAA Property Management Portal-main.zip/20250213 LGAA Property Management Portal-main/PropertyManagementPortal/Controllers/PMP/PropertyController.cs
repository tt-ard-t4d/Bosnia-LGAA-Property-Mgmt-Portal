﻿using Authorization;
using Infrastructure.Helpers;
using Microsoft.AspNetCore.Mvc;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.Infrastructure.Core.PMP;
using PropertyManagementPortal.Infrastructure.Core.Utils;
using PropertyManagementPortal.Infrastructure.Extensions;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.Controllers.PMP
{
    public class PropertyController : Controller
    {
        private readonly PropertyService _propertyService;
        private readonly PropertyDDLService _ddlService;
        private readonly ReportingService _reportService;
        private readonly PropertyReportService _propertyReportService;
        public PropertyController(PropertyService propertyService, PropertyDDLService ddlService, ReportingService reportService, PropertyReportService propertyReportService)
        {
            _propertyService = propertyService;
            _ddlService = ddlService;
            _reportService = reportService;
            _propertyReportService = propertyReportService;
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult Index(SearchPropertyDTO args)
        {
            HandleMunicipalityPermissions(ref args);
            if (!args.HasPermission) return View("NotAuthorized");

            CreateFilterDDL(ref args);
            var properties = _propertyService.GetPropertyGrid(args, User.GetLoggedUserId());

            return View(properties);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult Show(Guid id)
        {
            var property = _propertyService.GetPropertyDetails(id);
            if (property == null)
            {
                TempData["error-message"] = MessageRes.MissingItem;
                return RedirectToAction("Index", "Property");
            }

            return View(property);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Create(byte? propertyCategoryID)
        {
            var model = new PropertyDTO();
            if (propertyCategoryID == null)
            {
                model.PropertyCategories = _ddlService.GetPropertyCategories();
                return View("Create", model);
            }

            CreateAddEditDDL(ref model, propertyCategoryID);
            return View("Edit", model);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Edit(Guid id)
        {
            var model = _propertyService.GetPropertyById(id);

            if (model.PropertyID != Guid.Empty)
            {
                CreateAddEditDDL(ref model, model.PropertyCategoryID);
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.MissingItem;
            return RedirectToAction("Index", "Property");
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Save(PropertyDTO model)
        {
            if (!ModelState.IsValid) return RedirectToAction("Edit", "Property", new { id = model.PropertyID });

            var save = _propertyService.Save(model, User.Identity.GetLoggedUserId());

            if (save.IsError)
            {
                TempData["error-message"] = MessageRes.Error;
                return RedirectToAction("Edit", "Property", new { id = save.Guid });
            }

            TempData["success-message"] = MessageRes.Success;
            return RedirectToAction("Edit", "Property", new { id = save.Guid });

        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult SaveAndRedirect(PropertyDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _propertyService.Save(model, User.Identity.GetLoggedUserId());

                if (save.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return RedirectToAction("Index", "Property");
                }

                TempData["success-message"] = MessageRes.Success;
                return RedirectToAction("Index", "Property");
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            return RedirectToAction("Index", "Property");
        }

        [HttpPost]
        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser)]
        public IActionResult Delete(Guid id)
        {
            Guid loggedUserId = User.GetLoggedUserId();
            var res = _propertyService.Delete(id, loggedUserId);

            if (!res.IsError)
                TempData["success-message"] = MessageRes.Success;
            else
                TempData["error-message"] = MessageRes.Error;

            RetValue retValue = new()
            {
                ReturnUrl = Url.Action("Index", "Property") ?? "/",
                Guid = res.Guid,
            };

            return Json(retValue);
        }

        #region <!-- Reporting -->

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult ExportToExcel(SearchPropertyDTO args)
        {
            args.StartDate = DateTime.Parse(args.StartDateString);
            args.EndDate = DateTime.Parse(args.EndDateString);

            var data = _propertyReportService.GetPropertyForExport(args);
            var ignoredFields = _propertyReportService.GetIgnoredFieldsForProperty(args);
            Tuple<MemoryStream, string> export = _reportService.CreateDefaultReport(data, PropertyReportRes.PropertiesExport, ignoredFields);
            return File(export.Item1.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", export.Item2);
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult Report(SearchPropertyDTO args, GlobalEnum.ReportTypes reportType, int municipalityId = 0)
        {
            var userID = User.Identity.GetLoggedUserId();

            if (municipalityId != 0)
            {
                args.MunicipalityID = municipalityId;
            }

            HandleMunicipalityPermissions(ref args);
            if (!args.HasPermission) return View("NotAuthorized");

            switch (reportType)
            {
                case GlobalEnum.ReportTypes.IzvjestajOZakupuPoljoprivrednogZemljista:
                    return View("Reports/AgriculturalReport", _propertyReportService.GenerateALLeaseReport(args.MunicipalityID, userID));
                case GlobalEnum.ReportTypes.IzvjestajOZakupuGradjevinskogZemljista:
                    return View("Reports/BuildingReport", _propertyReportService.GenerateBLLeaseReport(args.MunicipalityID, userID));
                case GlobalEnum.ReportTypes.IzvjestajOZakupuPoslovnihProstora:
                    return View("Reports/OfficeBuildingReport", _propertyReportService.GenerateOBSLeaseReport(args.MunicipalityID, userID));
                case GlobalEnum.ReportTypes.IzvjestajOZakupuStanova:
                    return View("Reports/ResidentialBuildingReport", _propertyReportService.GenerateRBALeaseReport(args.MunicipalityID, userID));
                case GlobalEnum.ReportTypes.IzvjestajOPrometuGradjevniskogZemljista:
                    return View("Reports/BuildingLandTradeReport", _propertyReportService.GenerateBLTreadeReport(args.MunicipalityID, userID, args.StartDate, args.EndDate));
                case GlobalEnum.ReportTypes.IzvjestajOPrometuPoslovnihObjekata:
                    return View("Reports/OfficeBuildingTradeReport", _propertyReportService.GenerateOBSTreadeReport(args.MunicipalityID, userID, args.StartDate, args.EndDate));
                case GlobalEnum.ReportTypes.IzvjestajOPrometuStambenihLokacija:
                    return View("Reports/ResidentialBuildingTradeReport", _propertyReportService.GenerateRBATradeReport(args.MunicipalityID, userID, args.StartDate, args.EndDate));
                case GlobalEnum.ReportTypes.IzvjestajOEksproprisanimNekretninama:
                    return View("Reports/ExpropriatedRealEstateTradeReport", _propertyReportService.GenerateERETradeReport(args.MunicipalityID, userID));
                case GlobalEnum.ReportTypes.IzvjestajOSpornojImovini:
                    return View("Reports/DisputedPropertyTradeReport", _propertyReportService.GenerateDPTradeReport(args.MunicipalityID, userID));
                default:
                    return View("NotAuthorized");
            }
        }

        [AuthorizeUserGroups(ActionManagementEnum.UserGroups.Administrator, ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.LGUUser, ActionManagementEnum.UserGroups.LGAAConsultant)]
        public IActionResult ReportRange(SearchPropertyDTO args, GlobalEnum.ReportTypes reportType, int municipalityId = 0)
        {
            if (municipalityId != 0)
            {
                args.MunicipalityID = municipalityId;
            }
            return View("Reports/_ReportRange", (args, reportType));
        }

        #endregion

        #region <!-- DDL -->
        private void HandleMunicipalityPermissions(ref SearchPropertyDTO args)
        {
            var userID = User.Identity.GetLoggedUserId();
            var userMunicipalities = _ddlService.GetMunicipalitiesForUser(userID);

            if (userMunicipalities.Count == 0)
            {
                args.MunicipalityID = 0;
                args.HasPermission = false;
            }

            if (userMunicipalities.Count == 1)
            {
                args.MunicipalityID = userMunicipalities.First().Id;
                args.HasPermission = true;
            }
            else if (!userMunicipalities.Select(r => r.Id).Contains(args.MunicipalityID))
            {
                args.MunicipalityID = 0;
                args.HasPermission = false;
            }

            args.HasPermission = true;
        }
        private void CreateFilterDDL(ref SearchPropertyDTO args)
        {
            var userID = User.Identity.GetLoggedUserId();
            args.Municipalities = _ddlService.GetMunicipalitiesForUser(userID);
            args.Users = _ddlService.GetMunicipalityUsers(args.MunicipalityID);
            args.PropertyCategories = _ddlService.GetPropertyCategories();
            args.Statuses = _ddlService.GetPropertyStatuses(null);
        }

        private void CreateAddEditDDL(ref PropertyDTO args, byte? propertyCategoryId)
        {
            var userId = User.Identity.GetLoggedUserId();
            if (propertyCategoryId != null)
            {
                args.PropertyCategoryID = (byte)propertyCategoryId;
            }
            args.UserMunicipalities = _ddlService.GetMunicipalitiesForUser(userId);
            args.BooleanDDL = _ddlService.GetBoolDDL();
            args.PropertyCategories = _ddlService.GetPropertyCategories();
            args.PossessionBases = _ddlService.GetPossessionBases();
            args.OwnershipTypes = _ddlService.GetOwnershipTypes();
            args.DisputeTypes = _ddlService.GetDisputeTypes();
            args.OwnershipRightsAcquisitionLegalBases = _ddlService.GetOwnershipRightsAcquisitionLegalBases();
            args.RestrictedRealRightInformation = _ddlService.GetRestrictedRealRightInformation();
            args.AL_CreditRatingCategories = _ddlService.GetAL_CreditRatingCategories();
            args.BL_ConstructionRightsBases = _ddlService.Get_BLConstructionRightsBases();
            args.OBS_RBA_SPF_PropertyTypes = _ddlService.GetOBS_RBA_SPF_PropertyTypes(args.PropertyCategoryID);
            args.SPF_PropertyTypes = _ddlService.GetSPF_PropertyTypes();
            args.OBS_RBA_SPF_EnergyClasses = _ddlService.GetOBS_RBA_SPF_EnergyClasses();
            args.OBS_RBA_SPF_Conditions = _ddlService.GetOBS_RBA_SPF_Conditions();
            args.AL_LandTypes = _ddlService.GetLandTypes();
            args.InstalledInfrastructure = _ddlService.GetInstalledInfrastructure(propertyCategoryId);
            args.Zones = _ddlService.GetZones();
        }

        #endregion

    }
}
