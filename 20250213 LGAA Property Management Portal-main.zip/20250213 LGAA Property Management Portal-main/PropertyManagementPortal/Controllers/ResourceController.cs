﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Globalization;
using System.Text;
using System.Xml.Linq;

namespace PropertyManagementPortal.Controllers
{
    public class ResourceController : Controller
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        public ResourceController(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            // TODO: Add manually resources
            // Check names
            Dictionary<string, string> resources = new Dictionary<string, string>
            {
                { "ButtonRes", ConvertResourceToJson("ButtonRes.resx") },
                { "LabelRes", ConvertResourceToJson("LabelRes.resx") },
                { "MessageRes", ConvertResourceToJson("MessageRes.resx") },
                { "ValidationRes", ConvertResourceToJson("ValidationRes.resx") }
            };
            return Json(resources);
        }

        public IActionResult GetSpecific(string name)
        {
            var cultureName = Thread.CurrentThread.CurrentUICulture.Name;

            StringBuilder resourceName = new StringBuilder();
            resourceName.Append(name);

            //if (!string.IsNullOrEmpty(cultureName))
            //{
            //    resourceName.Append($".{cultureName}");
            //}

            resourceName.Append(".resx");

            if (!String.IsNullOrEmpty(name))
            {
                Dictionary<string, string> resources = new Dictionary<string, string>
                {
                    { "name", ConvertResourceToJson(resourceName.ToString()) }
                };
                return Json(resources);
            }

            return Json(new { });
        }

        public IActionResult GetDateFormat()
        {
            var format = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            return Json(new { dateFormat = format });
        }

        private string ConvertResourceToJson(string resourcePath)
        {
            string webRootPath = _webHostEnvironment.WebRootPath;
            string contentPath = _webHostEnvironment.ContentRootPath + "/Infrastructure/Resources";

            var resFile = Path.Combine(contentPath, resourcePath);
            var xml = System.IO.File.ReadAllText(resFile);
            var obj = new
            {
                Texts = XElement.Parse(xml)
                .Elements("data")
                .Select(el => new
                {
                    id = el.Attribute("name")?.Value,
                    text = el.Element("value")?.Value.Trim()
                }).ToList()
            };
            return JsonConvert.SerializeObject(obj, Formatting.Indented);
        }
    }
}
