﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Property
{
    public class PropertyDTO
    {
        public Guid PropertyID { get; set; }
        public int PropertyDisplayID { get; set; }
        public List<ItemDDL> UserMunicipalities { get; set; } = new();
        public int MunicipalityID { get; set; }
        public List<ItemDDL> PropertyCategories { get; set; } = new();
        public byte PropertyCategoryID { get; set; }
        public string LocationAddress { get; set; } = string.Empty;
        public string? KO { get; set; } = string.Empty;
        public string? KP { get; set; } = string.Empty;

        public List<ItemDDL> BooleanDDL = new();

        #region Documents
        public IFormFileCollection? Attachments { get; set; }
        public List<string>? OldAttachments { get; set; }
        public List<string>? DeleteAttachmentIDs { get; set; }
        #endregion

        //List nepokretnosti
        public string? PropertyRegister { get; set; } = string.Empty;
        public List<ItemDDL> Zones { get; set; } = new();
        public byte? ZoneId { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public decimal? PropertyArea { get; set; }
        public int? OBS_RBA_SPF_UnitNumber { get; set; }
        public decimal? OBS_RBA_SPF_GardenArea { get; set; }
        public string PropertyOwner { get; set; } = string.Empty;

        //Osnova posjedovanja/raspolaganja/korištenja
        //drop down menue(svojina, pravo korištenja, drugo)
        public List<ItemDDL> PossessionBases { get; set; } = new();
        public byte? PossessionBasisID { get; set; }

        //drop down menue (isključivo vlasništvo, suvlasništvo, zajedničko, izvanknjižno)
        public List<ItemDDL> OwnershipTypes { get; set; } = new();
        public byte? OwnershipTypeID { get; set; }

        //postojanje spora
        public bool? IsDispute { get; set; } = false;

        public List<ItemDDL> DisputeTypes { get; set; } = new();
        public byte? DisputeTypeID { get; set; }
        public bool? UsurpationExists { get; set; } = false;

        //Godina sticanja prava vlasništva
        public int? OwnershipRightsAcquisitionYear { get; set; }

        //Pravni osnov sticanja prava vlasništva
        //drop down menue(ugovor o zamjeni, kupoprodajni ugovor, nasljeđivanje, eksproprijacija, drugo)
        public List<ItemDDL> OwnershipRightsAcquisitionLegalBases { get; set; } = new();
        public byte? OwnershipRightsAcquisitionLegalBasisID { get; set; }

        //Podaci o ispravi o sticanju prava vlasništva
        public string? OwnershipRightsAcquisitionLegitimationInformation { get; set; } = string.Empty;
        public bool? IsNationalizedProperty { get; set; } = false;

        //Zabrana raspolaganja
        public bool? IsRestrictedDisposition { get; set; } = false;

        //drop down menue (zalog , služnost, drugo)
        public List<ItemDDL> RestrictedRealRightInformation { get; set; } = new();
        public byte? RestrictedRealRightInformationID { get; set; }

        //Bonitetna kategorija
        public List<ItemDDL> AL_CreditRatingCategories { get; set; } = new();
        public byte? AL_CreditRatingCategoryID { get; set; }
        public List<ItemDDL> AL_LandTypes { get; set; } = new();
        public byte? AL_LandTypeID { get; set; }

        public List<ItemDDL> BL_ConstructionRightsBases { get; set; } = new();
        public bool? BL_HasConstructionRights { get; set; } = false;
        public byte? BL_ConstructionRightsBasisID { get; set; }
        public string? BL_ConstructionRightsHolder { get; set; }
        public List<ItemDDL> OBS_RBA_SPF_PropertyTypes { get; set; } = new();
        public byte? OBS_RBA_SPF_PropertyTypeID { get; set; }
        public decimal? OBS_RBA_SPF_NumberOfFloors { get; set; }
        public List<ItemDDL> SPF_PropertyTypes { get; set; } = new();
        public byte? SPF_PropertyTypeID { get; set; }
        //Etažirano
        public bool? OBS_RBA_IsSharedObject { get; set; } = false;
        public List<ItemDDL> OBS_RBA_SPF_EnergyClasses { get; set; } = new();
        public byte? OBS_RBA_SPF_EnergyClassID { get; set; }
        public int? OBS_RBA_SPF_BuildYear { get; set; }
        public List<ItemDDL> OBS_RBA_SPF_Conditions { get; set; } = new();
        public byte? OBS_RBA_SPF_ConditionID { get; set; }
        public bool? SPF_IsLegallyConstructed { get; set; } = false;
        public List<ItemDDL> InstalledInfrastructure { get; set; } = new();
        public List<byte> InstalledInfrastructureIDs { get; set; } = new();
        public string? Comment { get; set; } = string.Empty;
        public string? PropertyInstalledInfrastructuresOther { get; set; } = string.Empty;
        public string? RestrictedRealRightInformationOther { get; set; } = string.Empty;
        public string? AL_BL_LandUseAccordingRegulatoryPlan { get; set; } = string.Empty;

        
    }
}
