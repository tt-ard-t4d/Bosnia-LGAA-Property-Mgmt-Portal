﻿using PropertyManagementPortal.Infrastructure.Attributes;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.DTO.Property
{
    public class ReportPropertyDTO
    {
        //Title and system
        [LocalizableDisplayName(typeof(PropertyReportRes), "PropertyDisplayID")]
        public int PropertyDisplayID { get; set; }
        [LocalizableDisplayName(typeof(PropertyReportRes), "PropertyCategoryID")]
        public string PropertyCategory { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "PropertyLatestStatusID")]
        public string PropertyLatestStatus { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "LocationAddress")]
        public string LocationAddress { get; set; } = LabelsRes.NoData;

        [LocalizableDisplayName(typeof(PropertyReportRes), "KO")]
        public string KO { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "KP")]
        public string KP { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "PropertyRegister")]
        public string PropertyRegister { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "Zone")]
        public string Zone { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_UnitNumber")]
        public string OBS_RBA_SPF_UnitNumber { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_GardenArea")]
        public string OBS_RBA_SPF_GardenArea { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "Latitude")]
        public string Latitude { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "Longitude")]
        public string Longitude { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "PropertyArea")]
        public string PropertyArea { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "LandUseAccordingRegulatoryPlan")]
        public string AL_BL_LandUseAccordingRegulatoryPlan { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_NumberOfFloors")]
        public string OBS_RBA_SPF_NumberOfFloors { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_PropertyTypeID")]
        public string OBS_RBA_SPF_PropertyType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "SPF_PropertyTypeID")]
        public string SPF_PropertyType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_IsSharedObject")]
        public string OBS_RBA_IsSharedObject { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "SPF_IsLegallyConstructed")]
        public string SPF_IsLegallyConstructed { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_BuildYear")]
        public string OBS_RBA_SPF_BuildYear { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_ConditionID")]
        public string OBS_RBA_SPF_Condition { get; set; } = LabelsRes.NoData;

        [LocalizableDisplayName(typeof(PropertyReportRes), "PropertyOwner")]
        public string PropertyOwner { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "PossessionBasisID")]
        public string PossessionBasis { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OwnershipTypeID")]
        public string OwnershipType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "IsDispute")]
        public string IsDispute { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "DisputeTypeID")]
        public string DisputeType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "UsurpationExists")]
        public string UsurpationExists { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OwnershipRightsAcquisitionYear")]
        public string OwnershipRightsAcquisitionYear { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OwnershipRightsAcquisitionLegalBasisID")]
        public string OwnershipRightsAcquisitionLegalBasis { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OwnershipRightsAcquisitionLegitimationInformation")]
        public string OwnershipRightsAcquisitionLegitimationInformation { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "IsNationalizedProperty")]
        public string IsNationalizedProperty { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "IsRestrictedDisposition")]
        public string IsRestrictedDisposition { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "RestrictedRealRightInformationID")]
        public string RestrictedRealRightInformation { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "Explanation")]
        public string RestrictedRealRightInformationOther { get; set; } = LabelsRes.NoData;


        //Third data set
        [LocalizableDisplayName(typeof(PropertyReportRes), "BookepingValue")]
        public string BookepingValue { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "MarketValue")]
        public string MarketValue { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "MaintainanceCostEstimate")]
        public string MaintainanceCostEstimate { get; set; } = LabelsRes.NoData;

        //Forth data set
        [LocalizableDisplayName(typeof(PropertyReportRes), "AL_CreditRatingCategoryID")]
        public string AL_CreditRatingCategory { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "AL_LandTypeID")]
        public string AL_LandType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "BL_HasConstructionRights")]
        public string BL_HasConstructionRights { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "BL_ConstructionRightsBasisID")]
        public string BL_ConstructionRightsBasis { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "BL_ConstructionRightsHolder")]
        public string BL_ConstructionRightsHolder { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "OBS_RBA_SPF_EnergyClassID")]
        public string OBS_RBA_SPF_EnergyClass { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "InstalledInfrastructureIDs")]
        public string InstalledInfrastructure { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyReportRes), "Explanation")]
        public string PropertyInstalledInfrastructuresOther { get; set; }

        //Current status
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyStatus")]
        public string PropertyStatus { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserName")]
        public string PropertyUserName { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractNumber")]
        public string ContractNumber { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractConclusionDate")]
        public string ContractConclusionDate { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractDurationInMonths")]
        public string ContractDurationInMonths { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "OtherContractualObligations")]
        public string OtherContractualObligations { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUseBasisDocument")]
        public string PropertyUseBasisDocument { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUseBasis")]
        public string PropertyUseBasis { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserGender")]
        public string PropertyUserGender { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserType")]
        public string PropertyUserType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractedValue")]
        public string ContractedValue { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractTypeBasedOnUserStatus")]
        public string ContractTypeBasedOnUserStatus { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractType")]
        public string ContractType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PaymentFrequency")]
        public string PaymentFrequency { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserTypeOther")]
        public string? PropertyUserTypeOther { get; set; } = LabelsRes.NoData;
    }
}
