﻿using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.DTO.Property
{
    public class ShowPropertyDTO
    {
        //Title and system
        public Guid? PropertyID { get; set; }
        public int PropertyDisplayID { get; set; }
        public int PropertyCategoryID { get; set; }
        public string PropertyCategory { get; set; }
        public string PropertyLatestStatus { get; set; }
        public int PropertyLatestStatusID { get; set; }
        public string LocationAddress { get; set; }

        //First data set
        public string KO { get; set; }
        public string KP { get; set; }
        public string PropertyRegister { get; set; }
        public string Zone { get; set; }
        //Vidjeti za ispis ove lokacije
        public bool ShowGPS { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string PropertyArea { get; set; }
        public string OBS_RBA_SPF_NumberOfFloors { get; set; }
        public string OBS_RBA_SPF_PropertyType { get; set; }
        public string SPF_PropertyType { get; set; }
        public string OBS_RBA_IsSharedObject { get; set; }
        public string? SPF_IsLegallyConstructed { get; set; }
        public string OBS_RBA_SPF_BuildYear { get; set; }
        public string OBS_RBA_SPF_Condition { get; set; }
        public string OBS_RBA_SPF_UnitNumber { get; set; }
        public string OBS_RBA_SPF_GardenArea { get; set; }

        //Second data set
        public string PropertyOwner { get; set; }
        public string PossessionBasis { get; set; }
        public string OwnershipType { get; set; }
        public string IsDispute { get; set; }
        public string DisputeType { get; set; }
        public string UsurpationExists { get; set; }
        public string OwnershipRightsAcquisitionYear { get; set; }
        public string OwnershipRightsAcquisitionLegalBasis { get; set; }
        public string OwnershipRightsAcquisitionLegitimationInformation { get; set; }
        public string IsNationalizedProperty { get; set; }
        public string IsRestrictedDisposition { get; set; }
        public string RestrictedRealRightInformation { get; set; }

        //Third data set
        public string BookepingValue { get; set; }
        public string MarketValue { get; set; }
        public string MaintainanceCostEstimate { get; set; }
        public string AdditionalInformation { get; set; }

        //Forth data set
        public string AL_CreditRatingCategory { get; set; }
        public string AL_LandType { get; set; }
        public string BL_HasConstructionRights { get; set; }
        public string BL_ConstructionRightsBasis { get; set; }
        public string BL_ConstructionRightsHolder { get; set; }
        public string OBS_RBA_SPF_EnergyClass { get; set; }
        public List<string> InstalledInfrastructure { get; set; } = new();
        public string Comment { get; set; }

        public string PropertyInstalledInfrastructuresOther { get; set; } 
        public string RestrictedRealRightInformationOther { get; set; }
        public string AL_BL_LandUseAccordingRegulatoryPlan { get; set; }
        public List<AttachmentShowDTO> Files { get; set; } = new();
    }
}
