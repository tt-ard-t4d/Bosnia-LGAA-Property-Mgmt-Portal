﻿using PropertyManagementPortal.DTO.Utils;
using System.ComponentModel.DataAnnotations;

namespace PropertyManagementPortal.DTO.Property
{
    public class SearchPropertyDTO : GridArgsDTO
    {
        public List<ItemDDL> Municipalities { get; set; } = new();
        public List<ItemDDL> PropertyCategories { get; set; } = new();
        public List<ItemDDL> Statuses { get; set; } = new();
        public List<ItemDDL> Users { get; set; } = new();
        public int MunicipalityID { get; set; }
        public bool HasPermission { get; set; }
        public Guid UserGuid { get; set; }
        public string LocationAddress { get; set; } = string.Empty;
        public int StatusID { get; set; }
        public int PropertyCategoryID { get; set; }
        public string? SearchTerm { get; set; }
        public DateTime StartDate { get; set; } = new(2024, 1, 1);
        public DateTime EndDate { get; set; } = DateTime.Now;

        //Made sepearateley for reporting, since URL is not correctly encoded
        public string? StartDateString { get; set; }
        public string? EndDateString { get; set; }
    }
}
