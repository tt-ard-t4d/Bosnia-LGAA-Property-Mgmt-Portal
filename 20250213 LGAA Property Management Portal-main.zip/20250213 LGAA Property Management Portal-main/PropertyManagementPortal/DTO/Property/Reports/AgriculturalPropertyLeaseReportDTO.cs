﻿using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.DTO.Municipality;

namespace PropertyManagementPortal.DTO.Property.Reports
{
    public class AgriculturalPropertyLeaseReportDTO
    {
        public string Address { get; set; } = string.Empty;
        public string KO { get; set; } = string.Empty;
        public string KP { get; set; } = string.Empty;
        public string ZK { get; set; } = string.Empty;
        public string Zone { get; set; } = string.Empty;
        public string PropertyPurposeType { get; set; } = string.Empty;
        public string LandUseAccordingRegulatoryPlan { get; set; } = string.Empty;
        public string CreditRatingCategory { get; set; } = string.Empty;
        public string PropertyUser { get; set; } = string.Empty;
        public string PropertyUserGender { get; set; } = string.Empty;
        public string ContractDuration { get; set; } = string.Empty;
        public string ContractType { get; set; } = string.Empty;
        public string ContractPayment { get; set; } = string.Empty;
        public string PaymentFrequency { get; set; } = string.Empty;
        public string Comment { get; set; } = string.Empty;
    }
}
