﻿namespace PropertyManagementPortal.DTO.Property.Reports
{
    public class ExpropriatedRealEstateTradeReportDTO
    {
        public string Address { get; set; } = string.Empty;
        public string KO { get; set; } = string.Empty;
        public string Zone { get; set; } = string.Empty;
        public string ZK { get; set; } = string.Empty;
        public string Comment { get; set; } = string.Empty;

    }
}
