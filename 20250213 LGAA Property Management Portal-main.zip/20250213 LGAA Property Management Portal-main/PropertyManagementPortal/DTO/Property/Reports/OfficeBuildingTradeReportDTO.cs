﻿namespace PropertyManagementPortal.DTO.Property.Reports
{
    public class OfficeBuildingTradeReportDTO
    {
        public string Address { get; set; } = string.Empty;
        public string KO { get; set; } = string.Empty;
        public string KP { get; set; } = string.Empty;
        public string Zone { get; set; } = string.Empty;
        public string OBS_RBA_SPF_PropertyTypeID { get; set; } = string.Empty;
        public string OBS_RBA_SPF_UnitNumber { get; set; } = string.Empty;
        public string ZK { get; set; } = string.Empty;
        public string ContractNumber { get; set; } = string.Empty;
        public string PropertyUser { get; set; } = string.Empty;
        public string ContractedValue { get; set; } = string.Empty;
        public string Comment { get; set; } = string.Empty;

    }
}
