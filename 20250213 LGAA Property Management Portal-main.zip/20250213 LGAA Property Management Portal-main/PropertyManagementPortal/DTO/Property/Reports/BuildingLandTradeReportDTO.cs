﻿namespace PropertyManagementPortal.DTO.Property.Reports
{
    public class BuildingLandTradeReportDTO
    {
        public string Address { get; set; } = string.Empty;
        public string KO { get; set; } = string.Empty;
        public string KP { get; set; } = string.Empty;
        public string ZK { get; set; } = string.Empty;
        public string Zone { get; set; } = string.Empty;
        public string ContractNumber { get; set; } = string.Empty;
        public string ContractValue { get; set; } = string.Empty;
        public string Comment { get; set; } = string.Empty;
    }
}
