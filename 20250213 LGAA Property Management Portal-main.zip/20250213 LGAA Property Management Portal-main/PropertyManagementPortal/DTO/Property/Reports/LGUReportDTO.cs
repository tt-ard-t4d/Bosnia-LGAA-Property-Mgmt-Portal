﻿namespace PropertyManagementPortal.DTO.Property.Reports
{
    public class LGUReportDTO
    {
        public string EntityName { get; set; } = string.Empty;
        public string LGUType { get; set; } = string.Empty;
        public string MunicipalityName { get; set; } = string.Empty;
        public string UserNameAndSurname { get; set; } = string.Empty;
        public string ReportDate { get; set; } = string.Empty;
        public int Total {  get; set; }
    }
}
