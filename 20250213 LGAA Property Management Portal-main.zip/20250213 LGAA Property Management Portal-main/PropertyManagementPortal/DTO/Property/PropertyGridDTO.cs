﻿using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Property
{
    public class PropertyGridDTO
    {
        public Guid PropertyID { get; set; }
        public int PropertyDisplayID { get; set; }
        public int PropertyCategoryID { get; set; }
        public string PropertyCategory { get; set; } = string.Empty;
        public string LocationAddress { get; set; } = string.Empty;
        public string PropertyOwner { get; set; } = "-";
        public string KO { get; set; } = string.Empty;
        public string KP { get; set; } = string.Empty;
        public byte? StatusID { get; set; }
        public string Status { get; set; } = string.Empty;
        public string CreatedDate { get; set; } = string.Empty;
        public int Total { get; set; }
    }
}
