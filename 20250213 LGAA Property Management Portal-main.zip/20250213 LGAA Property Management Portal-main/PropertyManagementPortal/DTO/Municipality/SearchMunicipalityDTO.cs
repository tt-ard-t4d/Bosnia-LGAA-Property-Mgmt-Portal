﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Municipality
{
    public class SearchMunicipalityDTO : GridArgsDTO
    {
        public string MunicipalityName { get; set; } = string.Empty;
        public List<ItemDDL> Entities { get; set; } = new List<ItemDDL>();
        public int EntityID { get; set; }
    }
}
