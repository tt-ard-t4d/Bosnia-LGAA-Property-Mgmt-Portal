﻿namespace PropertyManagementPortal.DTO.Municipality
{
    public class MunicipalitySlugDTO
    {
        public List<string>? Slugs { get; set; }
    }
}
