﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Municipality
{
    public class MunicipalityDTO
    {
        public int MunicipalityID { get; set; }
        public List<ItemDDL> Slugs { get; set; } = new List<ItemDDL>();
        public string Slug { get; set; } = string.Empty;
        public List<ItemDDL> Entities { get; set; } = new List<ItemDDL>();
        public string EntityName { get; set; } = string.Empty;
        public byte EntityID { get; set; }
        public string MunicipalityName { get; set; } = string.Empty;
        public string LocalGovernmentUnitName { get; set; } = string.Empty;
        public byte LocalGovernmentUnitID { get; set; }
    }
}
