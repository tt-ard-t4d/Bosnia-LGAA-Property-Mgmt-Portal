﻿namespace PropertyManagementPortal.DTO.Municipality
{
    public class MunicipalityGridDTO
    {
        public int MunicipalityID { get; set; }
        public string EntityName { get; set; } = string.Empty;
        public string MunicipalityName { get; set; } = string.Empty;
        public string LocalGovernmentUnitName { get; set; } = string.Empty;
        public int Total { get; set; }
        public string Slug { get; set; } = string.Empty;
    }
}
