﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.PropertyLeaseData
{
    public class SearchPropertyLeaseDataDTO : GridArgsDTO
    {
        public Guid PropertyID { get; set; }
        public string PropertyAddress { get; set; } = string.Empty;
    }
}
