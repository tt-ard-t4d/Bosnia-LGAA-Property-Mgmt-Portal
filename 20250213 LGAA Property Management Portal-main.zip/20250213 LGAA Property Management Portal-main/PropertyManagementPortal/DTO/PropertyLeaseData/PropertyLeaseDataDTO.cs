﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.PropertyLeaseData
{
    public class PropertyLeaseDataDTO
    {
        public string? PropertyAddress { get; set; }
        public Guid PropertyLeaseDataID { get; set; }
        public Guid PropertyID { get; set; }
        public byte PropertyCategoryID { get; set; }

        #region documents
        public IFormFileCollection? Attachments { get; set; }
        public List<string>? OldAttachments { get; set; }
        public List<string>? DeleteAttachmentIDs { get; set; }
        #endregion

        public List<ItemDDL> PropertyStatuses { get; set; } = new();
        public byte PropertyStatusID { get; set; }
        public string? PropertyUserName { get; set; } = string.Empty;
        public string? ContractNumber { get; set; } = string.Empty;
        public DateTime? ContractConclusionDate { get; set; }
        public int? ContractDurationInMonths { get; set; }
        public string? OtherContractualObligations { get; set; } = string.Empty;

        //Dokument na osnovu kog je zemljište dato na korištenje/osnov korištenja
        public List<ItemDDL> PropertyUseBasisDocuments { get; set; } = new();
        public byte? PropertyUseBasisDocumentID { get; set; }

        //Osnov korištenja zemljišta
        public List<ItemDDL> PropertyUseBases { get; set; } = new();
        public byte? PropertyUseBasisID { get; set; }

        //Spol korisnika/većinski vlasnik korisnika
        public List<ItemDDL> PropertyUserGenders { get; set; } = new();
        public byte? PropertyUserGenderID { get; set; }
        public List<ItemDDL> PropertyUserTypes { get; set; } = new();
        public byte? PropertyUserTypeID { get; set; }
        public decimal? ContractedValue { get; set; }

        //Vrsta ugovora po osnovu statusa korisnika
        public List<ItemDDL> ContractTypesBasedOnUserStatus { get; set; } = new();
        public byte? ContractTypeBasedOnUserStatusID { get; set; }

        //Vrsta ugovora
        public List<ItemDDL> ContractTypes { get; set; } = new();
        public byte? ContractTypeID { get; set; }

        public List<ItemDDL> PaymentFrequencies { get; set; } = new();
        public byte? PaymentFrequencyID { get; set; }

        public string? PropertyUserTypeOther { get; set; }

        public Guid SysCreatedByUserID { get; set; }

    }
}
