﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.PropertyLeaseData
{
    public class PropertyLeaseDataGridDTO
    {
        //System
        public Guid PropertyLeaseDataID { get; set; }
        public byte PropertyStatusID { get; set; }
        public string DateCreated { get; set; }

        //Details
        public string PropertyStatus { get; set; } = string.Empty;
        public string? PropertyUseBasisDocument { get; set; }
        public string? PropertyUseBasis { get; set; }
        public string? PropertyUserName { get; set; }
        public string? PropertyUserGender { get; set; }
        public string? PropertyUserType { get; set; }

        //Contract
        public string? ContractNumber { get; set; }
        public string? ContractConclusionDate { get; set; }
        public string? ContractType { get; set; }
        public int? ContractDurationInMonths { get; set; }
        public decimal? ContractedValue { get; set; }
        public string? PaymentFrequency { get; set; }
        public string? ContractTypeBasedOnUserStatus { get; set; }
        public string? OtherContractualObligations { get; set; }
        public string? PropertyUserTypeOther { get; set; }

        public List<AttachmentShowDTO> Attachments { get; set; } = new();

    }
}
