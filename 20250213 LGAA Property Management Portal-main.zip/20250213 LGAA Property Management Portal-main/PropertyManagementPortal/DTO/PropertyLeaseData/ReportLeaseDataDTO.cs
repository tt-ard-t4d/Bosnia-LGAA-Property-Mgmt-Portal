﻿using PropertyManagementPortal.Infrastructure.Attributes;
using PropertyManagementPortal.Infrastructure.Resources;

namespace PropertyManagementPortal.DTO.PropertyLeaseData
{
    public class ReportLeaseDataDTO
    {
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyLeaseDataId")]
        public string PropertyLeaseDataId { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyStatus")]
        public string PropertyStatus { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserName")]
        public string PropertyUserName { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractNumber")]
        public string ContractNumber { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractConclusionDate")]
        public string ContractConclusionDate { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractDurationInMonths")]
        public string ContractDurationInMonths { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "OtherContractualObligations")]
        public string OtherContractualObligations { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUseBasisDocument")]
        public string PropertyUseBasisDocument { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUseBasis")]
        public string PropertyUseBasis { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserGender")]
        public string PropertyUserGender { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserType")]
        public string PropertyUserType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractedValue")]
        public string ContractedValue { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractTypeBasedOnUserStatus")]
        public string ContractTypeBasedOnUserStatus { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "ContractType")]
        public string ContractType { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PaymentFrequency")]
        public string PaymentFrequency { get; set; } = LabelsRes.NoData;
        [LocalizableDisplayName(typeof(PropertyLeaseDataReportRes), "PropertyUserTypeOther")]
        public string PropertyUserTypeOther { get; set; } = LabelsRes.NoData;
    }
}
