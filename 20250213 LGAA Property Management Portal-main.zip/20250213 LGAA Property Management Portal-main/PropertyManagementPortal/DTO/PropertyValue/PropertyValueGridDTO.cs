﻿namespace PropertyManagementPortal.DTO.PropertyValue
{
    public class PropertyValueGridDTO
    {
        public Guid PropertyValueID { get; set; }
        public Guid PropertyID { get; set; }
        public decimal CurrentYearBookkeepingValue { get; set; }
        public decimal CurrentYearEstimatedMarketValue { get; set; }
        public decimal EstimatedMaintenanceCost { get; set; }
        public string? CurrentYearBookkeepingValueComment { get; set; } = string.Empty;
        public string? CurrentYearEstimatedMarketValueComment { get; set; } = string.Empty;
        public string? EstimatedMaintenanceCostComment { get; set; } = string.Empty;
        public string? AdditionalInformation { get; set; }
        public DateTime SysCreatedDate { get; set; }
    }
}
