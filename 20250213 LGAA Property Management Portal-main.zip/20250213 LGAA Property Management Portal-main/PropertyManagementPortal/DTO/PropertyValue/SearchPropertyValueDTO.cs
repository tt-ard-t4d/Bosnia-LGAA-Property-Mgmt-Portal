﻿using PropertyManagementPortal.DTO.Utils;
using System.ComponentModel.DataAnnotations;

namespace PropertyManagementPortal.DTO.PropertyValue
{
    public class SearchPropertyValueDTO : GridArgsDTO
    {
        public Guid PropertyID { get; set; } = Guid.Empty;
        public string? Address { get; set; } = string.Empty;
    }
}
