﻿namespace PropertyManagementPortal.DTO.PropertyValue
{
    public class PropertyValueDTO
    {
        public Guid PropertyValueID { get; set; }
        public Guid PropertyID { get; set; }
        public decimal CurrentYearBookkeepingValue { get; set; }
        public string? CurrentYearBookkeepingValueComment { get; set; }
        public decimal CurrentYearEstimatedMarketValue { get; set; }
        public string? CurrentYearEstimatedMarketValueComment { get; set; }
        public decimal EstimatedMaintenanceCost { get; set; }
        public string? EstimatedMaintenanceCostComment { get; set; }
    }
}
