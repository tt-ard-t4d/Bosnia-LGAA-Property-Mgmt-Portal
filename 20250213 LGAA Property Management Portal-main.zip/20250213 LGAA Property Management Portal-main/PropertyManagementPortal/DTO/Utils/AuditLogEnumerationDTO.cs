﻿namespace DTO.Utils
{
    public class AuditLogEnumerationDTO
    {
        public int AuditLogEnumerationID { get; set; }
        public string AuditLogEnumerationDescription { get; set; }
        public string AuditLogEnumerationText { get; set; }
        public Guid SysCreatedByUserID { get; set; }
        public DateTime SysCreatedDate { get; set; }
        public Guid? SysLastModifiedByUserID { get; set; }
        public Nullable<DateTime> SysLastModifiedDate { get; set; }
    }
}
