﻿namespace PropertyManagementPortal.DTO.Utils
{
    public class FileUploadDTO
    {
        public List<FormFileDTO> FormFiles { get; set; } = new List<FormFileDTO>();
        public string SelectedFormFileID { get; set; }
    }
}
