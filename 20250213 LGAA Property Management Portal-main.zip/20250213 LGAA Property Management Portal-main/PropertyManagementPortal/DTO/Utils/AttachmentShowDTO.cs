﻿namespace PropertyManagementPortal.DTO.Utils
{
    public class AttachmentShowDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Link { get; set; }
        public string? MimeType { get; set; }
    }
}
