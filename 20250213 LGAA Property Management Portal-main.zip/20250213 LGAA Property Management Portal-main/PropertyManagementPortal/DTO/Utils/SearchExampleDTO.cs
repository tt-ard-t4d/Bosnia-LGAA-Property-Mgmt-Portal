﻿namespace PropertyManagementPortal.DTO.Utils
{
    public class SearchExampleDTO : GridArgsDTO
    {
        public string? ExampleSortField { get; set; }
        public string? ExampleEnumerationName { get; set; }
        public string? SearchTerm { get; set; }
    }
}
