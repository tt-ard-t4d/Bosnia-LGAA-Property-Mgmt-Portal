﻿namespace PropertyManagementPortal.DTO.Utils
{
    public class SearchFileDTO
    {
        public string SearchTerm { get; set; }
        public int FileTypeID { get; set; }
    }
}
