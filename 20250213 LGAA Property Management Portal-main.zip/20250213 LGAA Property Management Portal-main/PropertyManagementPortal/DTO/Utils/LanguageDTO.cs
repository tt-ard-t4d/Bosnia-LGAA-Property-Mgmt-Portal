﻿namespace DTO.Utils
{
    public class LanguageDTO
    {
        public int LanguageID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int LCID { get; set; }
        public bool Retired { get; set; }
    }
}