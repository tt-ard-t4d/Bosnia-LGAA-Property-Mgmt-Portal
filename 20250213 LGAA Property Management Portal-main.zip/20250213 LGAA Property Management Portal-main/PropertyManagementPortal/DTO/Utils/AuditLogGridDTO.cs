﻿namespace PropertyManagementPortal.DTO.Utils
{
    public class AuditLogGridDTO
    {
        public int AuditLogID { get; set; }
        public string AuditLogText { get; set; }
        public string AuditLogEnumerationName { get; set; }
        public int? AuditLogEnumerationID { get; set; }
        public DateTime SysDateCreated { get; set; }
        public int Total { get; set; }
    }
}
