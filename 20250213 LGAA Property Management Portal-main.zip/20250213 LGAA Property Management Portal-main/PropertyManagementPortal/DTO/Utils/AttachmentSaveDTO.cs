﻿namespace PropertyManagementPortal.DTO.Utils
{
    public class AttachmentSaveDTO
    {
        public Guid ContentID { get; set; }
        public Guid LoggedUserId { get; set; }
        public short AttachmentType { get; set; }
    }
}
