﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Admin
{
    public class SearchUserDTO : GridArgsDTO
    {
        public List<ItemDDL> UserGroups { get; set; } = new();
        public int UserGroupID { get; set; }
        public List<ItemDDL> Municipalities { get; set; } = new();
        public int MunicipalityID { get; set; }
    }
}
