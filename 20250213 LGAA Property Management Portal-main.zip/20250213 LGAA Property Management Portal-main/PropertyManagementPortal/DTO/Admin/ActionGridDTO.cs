﻿namespace PropertyManagementPortal.DTO.Admin
{
    public class ActionGridDTO
    {
        public int ActionID { get; set; }
        public string ActionName { get; set; } = string.Empty;
        public string ActionEnumerationName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? StatusName { get; set; }
        public int Total { get; set; }
        public DateTime? SysLastModifiedDate { get; set; }
        public DateTime SysEntryTime { get; set; }
        public Guid? SysLastModifiedByUserID { get; set; }
    }
}
