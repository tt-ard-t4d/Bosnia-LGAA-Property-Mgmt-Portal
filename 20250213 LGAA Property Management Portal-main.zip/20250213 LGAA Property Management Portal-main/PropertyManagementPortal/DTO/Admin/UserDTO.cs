﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Admin
{
    public class UserDTO
    {
        public Guid UserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public Guid EmailCode { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public string? Password { get; set; }
        public string? RepeatPassword { get; set; }
        public bool ResetPassword { get; set; }
        public List<ItemDDL> UserGroups { get; set; } = new List<ItemDDL>();
        public List<int> UserGroupIDs { get; set; } = new List<int>();
        public List<ItemDDL> UserActions { get; set; } = new List<ItemDDL>();
        public List<int> UserActionIDs { get; set; } = new List<int>();
        public List<ItemDDL> Municipalities { get; set; } = new List<ItemDDL>();
        public List<int> MunicipalityIDs { get; set; } = new List<int>();
        public bool UserChoicePassword { get; set; }
        public bool IsDirectoryUser { get; set; }
    }
}
