﻿namespace PropertyManagementPortal.DTO.Admin
{
    public class UserGroupDTO
    {
        public short UserGroupID { get; set; }
        public string Name { get; set; } 
    }
}
