﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Admin
{
    public class ActionAssignmentDTO
    {
        public List<ItemDDL> UserGroups { get; set; } = new List<ItemDDL>();
        public int UserGroupID { get; set; }
        public List<ItemDDL> Users { get; set; } = new List<ItemDDL>();
        public Guid UserID { get; set; }
        public List<ItemDDL> Actions { get; set; } = new List<ItemDDL>();
        public List<int> GroupActionIDs { get; set; } = new List<int>();
        public List<ItemDDL> UserActions { get; set; } = new List<ItemDDL>();
        public List<int> UserActionIDs { get; set; } = new List<int>();
    
    }
}
