﻿using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.DTO.Admin
{
    public class SearchUserGroupDTO : GridArgsDTO
    {
        public string? SearchTerm { get; set; }
    }
}
