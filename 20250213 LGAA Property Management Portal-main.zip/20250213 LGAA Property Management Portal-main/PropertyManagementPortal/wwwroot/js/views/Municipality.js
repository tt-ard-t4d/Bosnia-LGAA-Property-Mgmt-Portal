﻿var app = app || {};

app.municipality = function () {

    var initForm = function () {
        $(function () {
            app.common.addSinglePicker('#MunicipalityID');
            app.municipality.onMunicipalityChange();
        });
    }

    var onMunicipalityChange = function () {
        $('#MunicipalityID').on('change', function () {
            $.ajax({
                method: 'GET',
                url: '/Municipality/GetRetiredMunicipality',
                data: {
                    id: $(this).val()
                },
                dataType: "json",
                success: function (data) {
                    $('#Slug').val(data.slug);
                    $('#Entity').val(data.entityName);
                    $('#LocalGovernmentUnit').val(data.localGovernmentUnitName);
                },
                error: function () {

                }
            });
        });
    }


    var deleteMunicipality = function (id) {
        var endpointRoute = '/Municipality/Delete';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteMunicipalityMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Yes'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { sendDeleteRequest(endpointRoute, id); });
        });
    };

    var sendDeleteRequest = function (endpointRoute, data) {
        app.utility.showLoader('body');
        $.ajax({
            method: "POST",
            url: endpointRoute,
            data: {
                id: data
            },
            dataType: "json"
        }).done(function (result) {
            app.utility.hideLoader('body');
            window.location.href = result.returnUrl;
        });
    };

    return {
        initForm: initForm,
        onMunicipalityChange: onMunicipalityChange,
        deleteMunicipality: deleteMunicipality,
    }
}();