﻿var app = app || {};

app.property = function () {

    function isMobileDevice() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    function getLocation() {

        if ("geolocation" in navigator) {
            var options = {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            };

            navigator.geolocation.getCurrentPosition(function (position) {
                var latitude = position.coords.latitude;
                var longitude = position.coords.longitude;
                $("#Latitude").val(latitude.toString().replace(/\./g, ','));
                $("#Longitude").val(longitude.toString().replace(/\./g, ','));
            }, function (error) {
                console.log("Error: " + error.message);
            }, options);
        }
    }

    var initForm = function () {
        $(function () {
            app.utility.showLoader();
            app.common.addSinglePicker('#InstalledInfrastructureIDs');
            app.common.addAllBasicSelects();
            app.common.autoExpandTextarea('Comment');
            app.common.preventFormSubmissionOnEnter('EditPropertyForm');
            app.property.addFormValidation();
            app.property.manageRequiredFields();
            $('#getGPSCoordinates').click(function () {
                if (isMobileDevice()) getLocation();
                else alert('Ne koristite mobilni uređaj!');
            })
            AutoNumeric.multiple('.decimal-value-2', {
                caretPositionOnFocus: "end",
                decimalCharacter: ",",
                decimalCharacterAlternative: ",",
                decimalPlaces: 2,
                digitGroupSeparator: ".",
                emptyInputBehavior: "null",
                minimumValue: "0",
                outputFormat: "string"
            });
            app.utility.hideLoader();
        });

        $('#OBS_RBA_SPF_PropertyTypeID').change(setDDLOtherOptionsSPF);
        $('#SPF_PropertyTypeID').change(setDDLOtherOptionsSPF);
        setDDLOtherOptionsII();
        setDDLOtherOptionsRRRI();

    }

    var addFormValidation = function () {
        app.resource.initSpecificResource('Validations', function () {
            $('form[id="EditPropertyForm"]').validate({
                ignore: ":hidden:not(#DisputeTypeID)",
                validClass: 'bg-green-50 border border-green-500 text-green-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5',
                errorClass: 'mt-2 text-sm text-red-600',
                highlight: function (element, errorClass) {
                    $(element).addClass("bg-red-50 border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500 validation-error");
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass("bg-red-50 border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500 validation-error").addClass(validClass);
                    $(element.form).find("label[for=" + element.id + "]")
                        .removeClass(errorClass);
                },
                errorPlacement: function (error, element) {
                    element.parent().append(error);
                },
                messages: {
                    'LocationAddress':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'KO':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'KP':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'DisputeTypeID':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                }
            });
        });
    };

    var manageRequiredFields = function () {
        function updateDisputeTypeIDVisibilityAndRequired() {
            var isDisputeValue = $("#IsDispute").val();
            var disputeTypeDiv = $("#DisputeTypeID").closest("div");

            if (isDisputeValue === "False") {
                disputeTypeDiv.hide();
                $("#DisputeTypeID").prop("required", false);
                $("#DisputeTypeID").val(null);
            } else {
                disputeTypeDiv.show();
                $("#DisputeTypeID").prop("required", true);
            }
            console.log($("#DisputeTypeID").val())
        }

        // Initial setup
        updateDisputeTypeIDVisibilityAndRequired();

        // Event listeners
        $("#IsDispute").on("change", function () {
            updateDisputeTypeIDVisibilityAndRequired();
        });
    }
    var deleteProperty = function (id) {
        var data = id;
        var deleteUrl = '/Property/Delete';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeletePropertyMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Delete'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { deletePropertyItem(deleteUrl, data); });
        });
    };



    var deletePropertyItem = function (deleteUrl, id) {
        app.utility.showLoader('body');
        $.ajax({
            method: "POST",
            url: deleteUrl + '?id=' + id,
            dataType: "json"
        }).done(function (result) {
            app.utility.hideLoader('body');
            window.location.href = result.returnUrl;
        });
    };

    var setDDLOtherOptionsII = function () {

        var selectedValues = $("#InstalledInfrastructureIDs").val();

        if (selectedValues && selectedValues.indexOf("12") !== -1) {
            $("#PropertyInstalledInfrastructuresOtherDiv").removeClass('hidden');
        } else {
            $("#PropertyInstalledInfrastructuresOtherDiv").addClass('hidden');

        }

    };

    var setDDLOtherOptionsRRRI = function () {

        var selectedValue = $("#RestrictedRealRightInformationID").val();

        if (selectedValue === "3") {
            $("#RestrictedRealRightInformationOtherDiv").removeClass('hidden');
        } else {
            $("#RestrictedRealRightInformationOtherDiv").addClass('hidden');

        }

    };

    var setDDLOtherOptionsSPF = function () {
        var selectedValueSPF = $("#SPF_PropertyTypeID").val();
        var selectedValueOBS_RBA = $("#OBS_RBA_SPF_PropertyTypeID").val();
        var show = selectedValueSPF === "2" || selectedValueOBS_RBA === "2" || selectedValueOBS_RBA === "3";

        if (show) {
            $("#OBS_RBA_SPF_UnitNumberDiv").removeClass('hidden');
        } else {
            $("#OBS_RBA_SPF_UnitNumberDiv").addClass('hidden');

        }

    };

    return {
        initForm: initForm,
        deleteProperty: deleteProperty,
        addFormValidation: addFormValidation,
        manageRequiredFields: manageRequiredFields,
        setDDLOtherOptionsII: setDDLOtherOptionsII,
        setDDLOtherOptionsRRRI: setDDLOtherOptionsRRRI,
        setDDLOtherOptionsSPF: setDDLOtherOptionsSPF
    }
}();