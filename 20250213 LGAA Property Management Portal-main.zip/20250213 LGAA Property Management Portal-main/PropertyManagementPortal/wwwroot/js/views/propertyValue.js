﻿var app = app || {};

app.propertyValue = function () {
    let initForm = function () {
        AutoNumeric.multiple('.decimal-value-2', {
            caretPositionOnFocus: "end",
            decimalCharacter: ",",
            decimalCharacterAlternative: ",",
            decimalPlaces: 2,
            digitGroupSeparator: ".",
            emptyInputBehavior: "null",
            minimumValue: "0",
            outputFormat: "string"
        });
        app.common.preventFormSubmissionOnEnter("PropertyValueEdit");
    }

    var deletePropertyValue = function (id) {
        var data = id;
        var deleteUrl = '/PropertyValue/Delete';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeletePropertyValueMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Delete'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { deletePropertyItem(deleteUrl, data); });
        });
    };

    return {
        initForm: initForm,
        deletePropertyValue: deletePropertyValue,
    }
}();