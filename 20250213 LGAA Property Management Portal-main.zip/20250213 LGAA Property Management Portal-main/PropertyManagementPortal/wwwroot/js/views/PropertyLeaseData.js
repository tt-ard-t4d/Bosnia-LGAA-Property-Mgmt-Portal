﻿var app = app || {};

app.propertyLeaseData = function () {

    var initForm = function () {

        app.common.addAllBasicSelects();
        app.propertyLeaseData.handleChangeStatus();
        setDDLOtherOptionsPUT();
        $(() => {
            AutoNumeric.multiple('.decimal-value-2', {
                caretPositionOnFocus: "end",
                decimalCharacter: ",",
                decimalCharacterAlternative: ",",
                decimalPlaces: 2,
                digitGroupSeparator: ".",
                emptyInputBehavior: "null",
                minimumValue: "0",
                outputFormat: "string"
            });
        });
        app.common.preventFormSubmissionOnEnter("property-lease-data-form");
    }


    var deletePropertyLeaseData = function (id) {
        var data = id;
        var deleteUrl = '/PropertyLeaseData/Delete';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeletePropertyLeaseDataMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Delete'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { deletePropertyLeaseDataItem(deleteUrl, data); });
        });
    };

    var deletePropertyLeaseDataItem = function (deleteUrl, id) {
        app.utility.showLoader('body');
        $.ajax({
            method: "POST",
            url: deleteUrl + '?id=' + id,
            dataType: "json"
        }).done(function (result) {
            app.utility.hideLoader('body');
            window.location.href = result.returnUrl;
        });
    };

    var handleChangeStatus = function () {
        $(document).ready(function () {
            $('#PropertyStatusID').on('change', function () {
                var selectedValue = $(this).val();
                var form = $('#property-lease-data-form');
                var sections = form.find('section');

                sections.hide();

                if (selectedValue === '1') {
                    sections.show();
                }
            });

            $('#property-lease-data-form').on('submit', function () {
                if ($('#PropertyStatusID').val() !== '1') {
                    $(this).find('select').not('#PropertyStatusID').each(function () {
                        $(this).val('0');
                    })
                    $('#basic-info').find('input, textarea').not('#PropertyStatusID, #PropertyID, #PropertyLeaseDataID').val('');
                    $('#contract-info').find('input, textarea').not('#PropertyStatusID, #PropertyID, #PropertyLeaseDataID').val('');
                }
            });

            $('#PropertyStatusID').trigger('change');
        });
    }

    var setDDLOtherOptionsPUT = function () {

        var selectedValues = $("#PropertyUserTypeID").val();

        if (selectedValues && selectedValues.indexOf("6") !== -1) {
            $("#PropertyUserTypeOtherDiv").removeClass('hidden');
        } else {
            $("#PropertyUserTypeOtherDiv").addClass('hidden');

        }

    };

    return {
        initForm: initForm,
        deletePropertyLeaseData: deletePropertyLeaseData,
        handleChangeStatus: handleChangeStatus,
        setDDLOtherOptionsPUT: setDDLOtherOptionsPUT
    }
}();