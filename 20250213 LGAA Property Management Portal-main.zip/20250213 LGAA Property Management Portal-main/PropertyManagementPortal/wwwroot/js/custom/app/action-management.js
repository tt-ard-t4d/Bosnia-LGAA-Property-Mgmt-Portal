﻿var app = app || {};

app.actionManagement = function () {

    var initActionForm = function () {
        app.resource.initSpecificResource('Validations', function () {
            $('form[id="EditActionForm"]').validate({
                ignore: ":not(:visible)",
                validClass: 'bg-green-50 border border-green-500 text-green-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5',
                errorClass: 'mt-2 text-sm text-red-600',
                highlight: function (element, errorClass) {
                    $(element).addClass("bg-red-50 border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500");

                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass(errorClass).addClass(validClass);
                    $(element.form).find("label[for=" + element.id + "]")
                        .removeClass(errorClass);
                },
                rules: {
                    'ActionName':
                    {
                        required: true
                    },
                    'ActionEnumerationName':
                    {
                        required: true
                    },
                    'Description':
                    {
                        required: true
                    }
                },
                messages: {
                    'ActionName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'ActionEnumerationName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'Description':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    }
                }
            });
        });
    }

    return {
        initActionForm: initActionForm
    }
}();