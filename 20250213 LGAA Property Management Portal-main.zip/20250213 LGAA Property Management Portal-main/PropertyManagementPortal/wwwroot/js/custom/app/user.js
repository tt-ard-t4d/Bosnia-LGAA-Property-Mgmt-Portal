﻿var app = app || {};

app.user = function () {

    var initGrid = function () {
        app.common.addPickers();
        initMunicipalityFilterSearch();
    };

    var initMunicipalityFilterSearch = function () {
        document.getElementById('municipality-search').addEventListener('input', function (e) {
            const searchValue = e.target.value.toLowerCase();
            const municipalities = document.querySelectorAll('#municipality-list li');

            municipalities.forEach(municipality => {
                const label = municipality.querySelector('label');
                if (label.textContent.toLowerCase().includes(searchValue)) {
                    municipality.style.display = 'flex';
                } else {
                    municipality.style.display = 'none';
                }
            });
        });
    }

    var initForm = function () {
        app.utility.showLoader();
        app.common.addPickers('#UserGroupIDs');
        app.common.addPickers('#MunicipalityIDs');
        addValidation();
        initPasswordCheckbox();
        app.utility.hideLoader();
    };

    var initPasswordCheckbox = function () {
        $('input[type=radio][name=UserChoicePassword]').change(
            function () {
                if (this.value == false || this.value == "false") {
                    $('#password-mannagement').show(300);
                }
                else {
                    $('#password-mannagement').hide(300);
                }
            }
        );
    };

    var addValidation = function () {
        app.resource.initSpecificResource('Validations', function () {
            $('form[id="EditUserForm"]').validate({
                ignore: ":not(:visible)",
                validClass: 'bg-green-50 border border-green-500 text-green-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5',
                errorClass: 'mt-2 text-sm text-red-600',
                highlight: function (element, errorClass) {
                    $(element).addClass("bg-red-50 border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500");

                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass(errorClass).addClass(validClass);
                    $(element.form).find("label[for=" + element.id + "]")
                        .removeClass(errorClass);
                },
                rules: {
                    'FirstName':
                    {
                        required: true,
                    },
                    'LastName':
                    {
                        required: true,
                    },
                    'UserName':
                    {
                        required: true,
                    },
                    'Email':
                    {
                        required: true,
                    },
                    'Password':
                    {
                        required: true,
                    },
                    'RepeatPassword':
                    {
                        required: true,
                    }
                },
                messages: {

                    'FirstName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'LastName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'UserName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'Email':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'Password':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'RepeatPassword':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    }
                }
            });
        });
    };

    var deleteUser = function (id) {
        var data = id;
        var deleteUrl = '/User/Delete';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteUserMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Delete'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { deleteUserItem(deleteUrl, data); });
        });
    };

    var deleteUserItem = function (deleteUrl, id) {
        app.utility.showLoader('body');
        $.ajax({
            method: "POST",
            url: deleteUrl + '?id=' + id,
            dataType: "json"
        }).done(function (result) {
            app.utility.hideLoader('body');
            window.location.href = result.returnUrl;
        });
    };

    return {
        initGrid: initGrid,
        initForm: initForm,
        deleteUser: deleteUser
    };
}();