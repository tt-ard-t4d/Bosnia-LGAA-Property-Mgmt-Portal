﻿var app = app || {};

app.layout = function () {

    var showMessageForType = function (type, msg) {
        switch (type) {
            case "success":
                showSuccessMessage(msg);
                break;
            case "error":
                showErrorMessage(msg);
                break;
            case "warning":
                showWarningMessage(msg);
                break;
            default:
                showSuccessMessage(msg);
        }
    };

    var showSuccessMessage = function (message) {
        toastr.options = {
            hideDuration: 500,
            timeOut: 2000,
            tapToDismiss: false,
            extendedTimeOut: 0,
            positionClass: 'toast-top-center'
        };

        if (message)
            toastr.success(message);
    };

    var showErrorMessage = function (message) {
        toastr.options = {
            timeOut: 0,
            extendedTimeOut: 0,
            tapToDismiss: true,
            positionClass: 'toast-top-center'
        };

        if (message)
            toastr.error(message);
    };

    var showWarningMessage = function (message) {
        toastr.options = {
            timeOut: 0,
            extendedTimeOut: 0,
            tapToDismiss: true,
            positionClass: 'toast-top-center'
        };

        if (message)
            toastr.warning(message);
    };

    var showInfoMessage = function (message) {
        toastr.options = {
            timeOut: 0,
            extendedTimeOut: 0,
            tapToDismiss: true,
            positionClass: 'toast-top-center'
        };

        if (message)
            toastr.info(message);
    };

    return {
        showSuccessMessage: showSuccessMessage,
        showErrorMessage: showErrorMessage,
        showWarningMessage: showWarningMessage,
        showInfoMessage: showInfoMessage,
        showMessageForType: showMessageForType
    };
}();