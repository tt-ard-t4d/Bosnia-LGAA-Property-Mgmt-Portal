﻿var app = app || {};

app.fileUpload = function () {
    var initFilePond = function (fileInputSelector, files) {
        FilePond.registerPlugin(FilePondPluginGetFile);
        const inputElement = document.querySelector(fileInputSelector);
        const pond = FilePond.create(inputElement, {
            credits: false,
            server: {
                load: '/Attachment/DownloadFile?s=',
            },
            files: files,
            instantUpload: false,
            allowMultiple: true,
            allowReorder: true,
            storeAsFile: true,
            labelIdle: 'Prevucite dokumente ovdje ili <span class="filepond--label-action">pretražite vaš uređaj</span>.',
            labelButtonDownloadItem: 'Preuzmi dokument',
            allowDownloadByUrl: false,
            beforeRemoveFile: (item) => {
                if (item.serverId != null && item.filenameWithoutExtension != null && item.filenameWithoutExtension.trim() !== "") {
                    let fileGuid = item.serverId.split('/').pop().split('.')[0];
                    var option = $("<option>").attr("value", fileGuid).text(fileGuid).prop("selected", true);
                    $("#DeleteAttachmentIDs").append(option);
                }
            }
        });
        return pond;
    }

    var loadExistingFiles = function (files) {
        if (files == null)
            return [];
        if (!Array.isArray(files)) {
            files = [files];
        }
        const pondFiles = files.map(filePath => ({
            source: filePath,
            options: {
                type: 'local',
            },

        }));

        return pondFiles;
    }

    return {
        initFilePond: initFilePond,
        loadExistingFiles: loadExistingFiles,
    }
}();