﻿var app = app || {};

app.common = function () {
    var addPickers = function (selector) {
        var picker = tail.select(selector, {
            locale: "bs",
            multiSelectAll: true,
            search: true,
            width: "100%",
        });
        return picker;
    };

    var addSinglePicker = function (selector) {
        var picker = tail.select(selector, {
            locale: "bs",
            search: true,
            width: "100%",
        });
        return picker;
    }

    var addAllBasicSelects = function () {
        var picker = tail.select("select:not([multiple])", {
            locale: "bs",
            search: true,
            width: "100%",
        });
        return picker;
    }

    var expandTextarea = function (textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = (textarea.scrollHeight) + 'px';
    }
    var autoExpandTextarea = function (id) {
        $(document).ready(function () {
            $(`#${id}`).on('input', function () {
                expandTextarea(this);
            });

            expandTextarea($(`#${id}`)[0]);
        });
    }

    var exportPdf = function (buttonId, exportId, documentName) {
        var savePdf = function () {
            var element = document.getElementById(exportId);
            var opt = {
                margin: [0.5, 0.2, 0.3, 0.2],
                pagebreak: { avoid: '.row' },
                filename: `${documentName}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            var worker = html2pdf().set(opt).from(element).save();
        }
        $(function () {
            document.getElementById(buttonId).addEventListener("click", savePdf);
        });
    }

    function preventFormSubmissionOnEnter(formId) {
        document.addEventListener('DOMContentLoaded', function () {
            var form = document.getElementById(formId);

            if (form) {
                form.addEventListener('keypress', function (event) {
                    if (event.keyCode === 13 || event.key === 'Enter') {
                        event.preventDefault();
                        return false;
                    }
                });
            } else {
                console.error('Form not found with ID:', formId);
            }
        });
    }

    return {
        addPickers: addPickers,
        addSinglePicker: addSinglePicker,
        addAllBasicSelects: addAllBasicSelects,
        autoExpandTextarea: autoExpandTextarea,
        exportPdf: exportPdf,
        preventFormSubmissionOnEnter: preventFormSubmissionOnEnter,
    }
}();