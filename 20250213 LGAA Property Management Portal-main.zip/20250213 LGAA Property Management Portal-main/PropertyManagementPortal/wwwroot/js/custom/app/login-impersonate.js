﻿var app = app || {};

app.loginImpersonate = function () {

    var resetLoginImpersonate = function () {
        window.location = "/LoginImpersonate/ResetLogin";
    }

    var openLoginImpersonate = function () {

        if ($("#ddLoginImpersonate").hasClass("show")) {

            $('select[name=Email] option[value=null]').prop('selected', true);
            $('select[name=Email]').selectpicker('render');
            $("#ddLoginImpersonate").removeClass("show");
        }
        else {
            $("#ddLoginImpersonate").addClass("show");
            var ddl = $('select[name=Email]');
            createDDL('/LoginImpersonate/GetUsers', ddl);
        }
    }

    var createDDL = function (url, ddl) {
        app.resource.initSpecificResource('Messages', function () {
            $.ajax({
                url: url,
                success: function (data) {

                    var html = `<option value="">${app.resource.getByResourceGroupAndKey('Messages', 'SelectUser')}</option>`;

                    $.each(data, (v) => {
                        html += `<option value="${data[v].value}">${data[v].value}</option>`;
                    });

                    ddl.empty();
                    ddl.append(html);
                    ddl.selectpicker('refresh');
                },
                error: function (xhr, status, error) {
                    toastr.error(app.resource.getByResourceGroupAndKey('Messages', 'Error'));
                }
            });
        });
    }

    return {
        openLoginImpersonate: openLoginImpersonate,
        resetLoginImpersonate: resetLoginImpersonate,
    }
}();