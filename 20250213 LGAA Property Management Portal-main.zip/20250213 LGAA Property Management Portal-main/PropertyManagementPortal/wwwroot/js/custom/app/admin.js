﻿var app = app || {};

app.admin = function () {

    var initSearch = function () {
        $(document).ready(function () {
            $('#action-search').on('keyup', function () {
                filterItems($(this).val().toLowerCase());
            });

            function filterItems(query) {
                $('ul#actions li').each(function () {
                    var itemValue = $(this).find('label span.text-lg').text().toLowerCase();
                    if (itemValue.includes(query)) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            }
        });
    }





    //OVO ISPOD SVE TREBA POBRISATI


    onChangeDDL = function (url, parentName, childName, lstForRemove, childPicker, parentPicker) {
        app.utility.showLoader('body');

        var parentDDL = $(`#${parentName}`);
        var childDDL = $(`#${childName}`);
        let emptyText = $(`#${childName} option:first-child`).text();

        const parentId = parentDDL.val();
        const data = {
            parentId: parentId
        }

        $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            data: data,
            success: function (data) {
                createDDL(childDDL, data, emptyText);
                clearDDL(lstForRemove);
                childPicker.reload();
                app.utility.hideLoader('body');
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status === 404) {
                    app.utility.hideLoader('body');
                    alert(thrownError);
                }
            }
        });
    };

    var createDDL = function (ddl, data, emptyText, id = "0") {
        if (data) {
            ddl.find('option:selected').prop('selected', false);
            for (var i = 0; i < data.length; i++) {
                ddl.find(`option[value=${data[i].id}]`).prop('selected', true);
            };
            return;
        }
    };

    var clearDDL = function (ddls) {
        if (ddls) {
            for (var i = 0; i < ddls.length; i++) {
                let ddl = $(`#${ddls[i]}`);
                let emptyText = $(`#${ddls[i]} option:first-child`).text();
                ddl.empty();
                ddl.append(`<option value="">${emptyText}</option>`);
            }
        }
    };

    return {
        onChangeDDL: onChangeDDL,
        initSearch: initSearch
    };
}();

