var app = app || {};

app.modal = function () {
    let counter = 0;
    let createConfirmationModal = function (title, actionName, cancelName, callback) {
        $.ajax({
            url: '/Partial/ConfirmationModal',
            type: 'GET',
            title: title,
            actionName: actionName,
            cancelName: cancelName,
            callback: callback,
            success: function (data) {

                $('#modal').html(data);
                const $targetEl = document.getElementById('popup-modal');
                const options = {
                    placement: 'top-center',
                    backdrop: 'dynamic',
                    backdropClasses: 'bg-gray-900 bg-opacity-50 dark:bg-opacity-80 fixed inset-0 z-40',
                    closable: true,
                    onHide: () => {
                        $('#modal').html("");
                    },
                    onShow: () => {
                        $('#closeModal').html(this.cancelName);
                        $('#titleModal').html(this.title);
                        $('#confirmModal').html(this.actionName).click(function (nesto, fncallback = callback) {
                            console.log(fncallback);
                            fncallback();
                            $('#modal').remove();
                            $('div[modal-backdrop=""]').remove();
                            $('body').prepend('<div id="modal"></div>')
                        });
                    }
                };
                const modal = new Modal($targetEl, options);
                $('#closeModal').click(function () { modal.hide();})
                $('#xButton').click(function () { modal.hide(); })
                modal.show();

            },
            error: function () {
                console.log("ne radi")
            }
        });

    }

    return {
        createConfirmationModal: createConfirmationModal
    }
}();