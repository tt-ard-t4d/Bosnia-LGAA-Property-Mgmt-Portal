﻿using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Municipality;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IMunicipalityRepository
    {
        public Municipality? GetMunicipalityById(int municipalityId);
        public Municipality? GetMunicipalityBySlug(string municipalityName);
        public IQueryable<Municipality> GetAllMunicipalities();
        public RetValue Save(Municipality entity);
        public (IQueryable<Municipality>, int) GetMunicipalityGrid(SearchMunicipalityDTO args);
        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId);
        public IQueryable<Municipality> GetRetiredMunicipalities();
        public Municipality? GetRetiredMunicipality(int id);
        public RetValue DeleteMunicipality(int id);
    }
}
