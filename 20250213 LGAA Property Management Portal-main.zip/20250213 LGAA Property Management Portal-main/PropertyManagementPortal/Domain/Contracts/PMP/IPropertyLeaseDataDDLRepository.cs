﻿using PropertyManagementPortal.Domain.Entities.CodeBooks;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IPropertyLeaseDataDDLRepository
    {
        public IQueryable<PropertyStatus> GetPropertyStatuses();
        public IQueryable<PaymentFrequency> GetPaymentFrequencies();
        public IQueryable<PropertyUseBasisDocument> GetPropertyUseBasisDocuments();
        public IQueryable<PropertyUseBasis> GetPropertyUseBases();
        public IQueryable<PropertyUserGender> GetPropertyUserGenders();
        public IQueryable<PropertyUserType> GetPropertyUserTypes();
        public IQueryable<ContractTypeBasedOnUserStatus> GetContractTypesBasedOnUserStatus();
        public IQueryable<ContractType> GetContractTypes();

    }
}
