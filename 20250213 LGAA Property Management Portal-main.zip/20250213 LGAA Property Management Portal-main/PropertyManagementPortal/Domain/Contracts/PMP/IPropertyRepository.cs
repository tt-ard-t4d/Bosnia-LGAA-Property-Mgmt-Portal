﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Property;
using PropertyManagementPortal.Infrastructure.Helpers;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IPropertyRepository
    {
        public Property? GetPropertyById(Guid id);
        public Property? GetPropertyForStatusReport(Guid id);
        public Property? GetPropertyDetailsById(Guid id);
        public RetValue Save(Property entity, PropertyDTO vm, GlobalEnum.CrudOperation operation);
        public (List<Property>, int) GetPropertyGrid(SearchPropertyDTO args, Guid loggedUserGuid, IConfiguration configuration, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage);
        public IQueryable<Property> GetPropertiesForReport(SearchPropertyDTO args, IConfiguration configuration);
        public RetValue Delete(Guid id, Guid loggedUserId);
        public List<Property> GetPropertiesByType(GlobalEnum.PropertyCategories poljoprivrednoZemljiste, int municipalityId);
        public List<Property> GetAllProperties(int municipalityId);
    }
}
