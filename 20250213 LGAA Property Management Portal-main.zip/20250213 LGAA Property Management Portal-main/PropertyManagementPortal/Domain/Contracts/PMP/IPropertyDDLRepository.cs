﻿using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.Domain.Entities.CodeBooks;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IPropertyDDLRepository
    {
        public IQueryable<PropertyCategory> GetPropertyCategories();
        public IQueryable<PossessionBasis> GetPossessionBases();
        public IQueryable<OwnershipType> GetOwnershipTypes();
        public IQueryable<DisputeType> GetDisputeTypes();
        public IQueryable<OwnershipRightsAcquisitionLegalBasis> GetOwnershipRightsAcquisitionLegalBases();
        public IQueryable<RestrictedRealRightInformation> GetRestrictedRealRightInformation();
        public IQueryable<AL_CreditRatingCategory> GetAL_CreditRatingCategories();
        public IQueryable<AL_LandType> GetLandTypes();
        public IQueryable<BL_ConstructionRightsBasis> GetBLConstructionRightsBases();
        public IQueryable<OBS_RBA_SPF_PropertyType> GetOBS_RBA_SPF_PropertyTypes();
        public IQueryable<SPF_PropertyType> GetSPF_PropertyTypes();
        public IQueryable<OBS_RBA_SPF_EnergyClass> GetOBS_RBA_SPF_EnergyClasses();
        public IQueryable<OBS_RBA_SPF_Condition> GetOBS_RBA_SPF_Conditions();
        public IQueryable<PropertyStatus> GetPropertyStatuses();
        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId);
        public IQueryable<InstalledInfrastructure> GetInstalledInfrastructures();
        public IQueryable<Zone> GetZones();
        public IQueryable<User> GetMunicipalityUsers(int municipalityId);
        public IQueryable<User> GetAllUsers();
    }
}
