﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IPMPDropDownRepository
    {
        public IQueryable<Entity> GetEntities();
        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId);
        public IQueryable<Municipality> GetAllMunicipalities();
    }
}