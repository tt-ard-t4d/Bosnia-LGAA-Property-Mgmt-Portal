﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.PropertyValue;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IPropertyValueRepository
    {
        public PropertyValue? GetPropertyValueById(Guid id);
        public RetValue Save(PropertyValue entity, GlobalEnum.CrudOperation operation);
        public (List<PropertyValue>, int) GetPropertyValueGrid(SearchPropertyValueDTO args, int numberOfRows);
        public RetValue Delete(Guid id, Guid loggedUserId);
    }
}
