﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.PropertyLeaseData;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Domain.Contracts.PMP
{
    public interface IPropertyLeaseDataRepository
    {
        public IQueryable<PropertyLeaseData> GetAllPropertyLeaseData();
        public PropertyLeaseData? GetPropertyLeaseDataById(Guid id);
        public RetValue Save(PropertyLeaseData entity, GlobalEnum.CrudOperation operation);
        public (List<PropertyLeaseData>, int) GetPropertyLeaseDataGrid(SearchPropertyLeaseDataDTO args, int numberOfObjectsPerPage);
        public RetValue Delete(Guid id, Guid loggedUserId);
    }
}
