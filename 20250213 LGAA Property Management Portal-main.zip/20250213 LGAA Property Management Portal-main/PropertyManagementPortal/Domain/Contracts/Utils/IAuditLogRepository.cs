﻿
using Domain.Entities.Utils;
using DTO.Utils;
using PropertyManagementPortal.DTO.Utils;

namespace Domain.Contracts
{
    public interface IAuditLogRepository
    {
        List<AuditLogDTO> GetAllAuditLog();
        AuditLogDTO GetAuditLogItem(int? id);
        void SaveAuditLog(AuditLogDTO auditlog);
        public (IQueryable<AuditLog>, int) GetAuditLogGrid(SearchAuditLogDTO args);
    }
}
