﻿
using DTO.Utils;

namespace Domain.Contracts
{
    public interface IEmailNotificationRepository
    {
        List<EmailNotificationDTO> GetAllEmailNotification();
        EmailNotificationDTO GetEmailNotificationItem(int? id);
        void SaveEmailNotification(EmailNotificationDTO emailnotification, int loggedUserId);
    }
}
