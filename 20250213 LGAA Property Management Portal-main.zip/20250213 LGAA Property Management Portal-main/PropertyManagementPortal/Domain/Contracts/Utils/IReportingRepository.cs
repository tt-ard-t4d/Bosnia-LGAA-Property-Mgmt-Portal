﻿namespace PropertyManagementPortal.Domain.Contracts.Utils
{
    public interface IReportingRepository
    {

    }
}
