﻿
using DTO.Utils;
using System.Collections.Generic;

namespace Domain.Contracts
{
    public interface IAuditLogEnumerationRepository
    {
        List<AuditLogEnumerationDTO> GetAllAuditLogEnumeration();
        AuditLogEnumerationDTO GetAuditLogEnumerationItem(int? id);
        void SaveAuditLogEnumeration(AuditLogEnumerationDTO auditlogenum);
    }
}
