﻿using PropertyManagementPortal.Domain.Entities.Utils;
using PropertyManagementPortal.DTO.Utils;
using PropertyManagementPortal.Infrastructure.Models;

namespace PropertyManagementPortal.Domain.Contracts.Utils
{
    public interface IAttachmentRepository
    {
        RetValue DeleteFile(Guid fileId);
        RetValue Save(AttachedFiles entity);
        AttachmentShowDTO GetFileFromDB(Guid fileId);
    }
}
