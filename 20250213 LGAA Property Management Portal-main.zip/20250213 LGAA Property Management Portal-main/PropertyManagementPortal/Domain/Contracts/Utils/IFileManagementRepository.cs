﻿using PropertyManagementPortal.Domain.Entities.Utils;
using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.Domain.Contracts.Utils
{
    public interface IFileManagementRepository
    {
        public (IQueryable<AttachedFiles>, int) GetFileGrid(SearchFileDTO args);
    }
}
