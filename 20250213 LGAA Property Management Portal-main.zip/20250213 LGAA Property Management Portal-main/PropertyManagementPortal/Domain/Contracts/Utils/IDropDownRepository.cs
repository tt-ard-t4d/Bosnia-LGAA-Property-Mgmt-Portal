﻿using DTO.Utils;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.Domain.Entities.App;
using PropertyManagementPortal.DTO.Utils;

namespace PropertyManagementPortal.Domain.Contracts.Utils
{
    public interface IDropDownRepository
    {
        public IQueryable<UserGroup> GetUserGroups();
        public IQueryable<Entities.Action> GetActions();
        public IQueryable<User> GetUsers();
        public List<AuditLogEnumerationDTO> GetAllAuditLogsEnumeration();
        public IQueryable<Municipality> GetMunicipalities();
    }
}
