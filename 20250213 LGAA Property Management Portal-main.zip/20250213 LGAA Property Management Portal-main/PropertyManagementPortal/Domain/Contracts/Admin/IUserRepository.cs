﻿using Infrastructure.Helpers;
using PropertyManagementPortal.Domain.Entities;
using PropertyManagementPortal.DTO.Admin;
using PropertyManagementPortal.Infrastructure.Models;
using PropertyManagementPortal.Infrastructure.Models.StoredProcedures;

namespace PropertyManagementPortal.Domain.Contracts.Admin
{
    public interface IUserRepository
    {
        public User? GetUserById(Guid userId);
        public User? GetUserByEmailCode(string emailCode);
        public User? GetUserByUserNameEnc(string userNameEnc);
        public User? GetUserByEmailEnc(string emailEnc);
        public UserGroup? GetUserGroupById(int userGroupId);
        public RetValue Save(User entity, UserDTO vm, GlobalEnum.CrudOperation operation);
        public RetValue ChangePassword(User entity, string password);
        public IQueryable<User> GetUserEmails(Guid impersonatedUserId);
        public (IQueryable<User>, int) GetUserGrid(SearchUserDTO args);
        public (IQueryable<User>,int) GetMunicipalityUsersGrid(SearchUserDTO args, List<int> userMunicipalities);
        public IQueryable<GetUserActions> GetUserActions(Guid userId);
        public IQueryable<UserActionRel> GetUserActionRels();
        public IQueryable<UserGroupUserRel> GetUserGroupUserRels();
        User? GetDirectoryUserByEmail(string? email);
        RetValue Delete(Guid id, Guid loggedUserId);
    }
}
