﻿namespace PropertyManagementPortal.Domain.Contracts.Admin
{
    using global::Infrastructure.Helpers;
    using PropertyManagementPortal.Domain.Entities;
    using PropertyManagementPortal.DTO.Admin;
    using PropertyManagementPortal.Infrastructure.Models;
    using Action = Entities.Action;
    public interface IActionManagementRepository
    {
        #region <!-- Action -->
        public Action? GetAction(int actionId);
        public (IQueryable<Action>, int) GetActionGrid(SearchActionDTO args);
        public (IQueryable<ActionHistory>, int) GetTemporalActionGrid(SearchActionDTO args);
        public RetValue SaveAction(Action entity, GlobalEnum.CrudOperation operation);
        #endregion

        #region <!-- User group -->
        public UserGroup? GetUserGroup(int userGroupId);
        public (IQueryable<UserGroup>, int) GetUserGroupGrid(SearchUserGroupDTO args);
        public RetValue SaveUserGroup(UserGroup entity, GlobalEnum.CrudOperation operation);
        #endregion

        #region <!-- Action management -->
        public RetValue SaveActionsForUser(User entity, ActionAssignmentDTO vm);
        public RetValue SaveActionsForUserGroup(UserGroup entity, ActionAssignmentDTO vm);
        public IQueryable<Action> GetActionsForUserGroup(int userGroupId);
        public IQueryable<Action> GetActionsForUser(Guid userId);
        #endregion
    }
}
