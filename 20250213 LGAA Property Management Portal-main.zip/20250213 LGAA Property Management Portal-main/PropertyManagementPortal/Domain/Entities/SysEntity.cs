﻿namespace PropertyManagementPortal.Domain.Entities
{
    public abstract class SysEntity
    {
        public Guid SysCreatedByUserID { get; set; }
        public DateTime SysCreatedDate { get; set; }
        public Guid? SysLastModifiedByUserID { get; set; }
        public DateTime? SysLastModifiedDate { get; set; }
        public bool Retired { get; set; }
    }
}
