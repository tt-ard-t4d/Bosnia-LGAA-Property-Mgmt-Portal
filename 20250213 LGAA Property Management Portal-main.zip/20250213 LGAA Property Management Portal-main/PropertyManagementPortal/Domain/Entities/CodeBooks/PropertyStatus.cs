﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class PropertyStatus : SysEntity
    {
        public byte PropertyStatusID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<PropertyLeaseData> PropertyLeaseData { get; set; }
    }
}
