﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class RBA_SPF_PropertyUserType
    {
        public byte RBA_SPF_PropertyUserTypeID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<PropertyLeaseData> PropertyLeaseData { get; set; }
    }
}
