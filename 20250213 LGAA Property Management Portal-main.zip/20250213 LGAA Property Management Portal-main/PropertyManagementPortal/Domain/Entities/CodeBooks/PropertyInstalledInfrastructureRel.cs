﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class PropertyInstalledInfrastructureRel
    {
        public int PropertyInstalledInfrastructureID { get; set; }
        public Guid PropertyID { get; set; }
        public virtual Property Property { get; set; }
        public byte InstalledInfrastructureID { get; set; }
        public virtual InstalledInfrastructure InstalledInfrastructure { get; set; }
        public bool Retired { get; set; }
    }
}
