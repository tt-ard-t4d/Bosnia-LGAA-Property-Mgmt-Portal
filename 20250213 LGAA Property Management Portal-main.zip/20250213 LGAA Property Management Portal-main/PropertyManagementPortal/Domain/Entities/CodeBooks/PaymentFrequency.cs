﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class PaymentFrequency : SysEntity
    {
        public byte PaymentFrequencyID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<PropertyLeaseData> PropertyLeaseData { get; set; }
    }
}
