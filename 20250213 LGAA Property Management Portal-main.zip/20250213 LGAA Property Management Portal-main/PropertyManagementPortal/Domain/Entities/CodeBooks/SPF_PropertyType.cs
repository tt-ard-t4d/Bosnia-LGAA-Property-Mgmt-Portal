﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class SPF_PropertyType : SysEntity
    {
        public byte Id { get; set; }
        public string Title { get; set; }
        public IEnumerable<Property> Properties { get; set; }
    }
}
