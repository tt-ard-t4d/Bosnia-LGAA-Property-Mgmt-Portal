﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class OwnershipRightsAcquisitionLegalBasis : SysEntity
    {
        public byte OwnershipRightsAcquisitionLegalBasisID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<Property> Properties { get; set; }
    }
}
