﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class AL_CreditRatingCategory : SysEntity
    {
        public byte AL_CreditRatingCategoryID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<Property> Properties { get; set; }
    }
}
