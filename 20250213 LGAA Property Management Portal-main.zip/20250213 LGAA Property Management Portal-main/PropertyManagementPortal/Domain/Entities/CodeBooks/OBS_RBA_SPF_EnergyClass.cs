﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class OBS_RBA_SPF_EnergyClass : SysEntity
    {
        public byte OBS_RBA_SPF_EnergyClassID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<Property> Properties { get; set; }
    }
}
