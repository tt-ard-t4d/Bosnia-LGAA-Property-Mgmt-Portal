﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class PropertyCategory : SysEntity
    {
        public byte PropertyCategoryID { get; set; }
        public string Value { get; set; }
        public string Code { get; set; }
        public string InternalName { get; set; }
        public virtual ICollection<Property> Properties { get; set; }
    }
}
