﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class LocalGovernmentUnit
    {
        public byte LocalGovernmentUnitID { get; set; }
        public string LocalGovernmentUnitName { get; set; } = string.Empty;
        public virtual ICollection<Municipality> Municipalities { get; set; }
    }
}
