﻿namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class InstalledInfrastructure : SysEntity
    {
        public byte InstalledInfrastructureID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<PropertyInstalledInfrastructureRel> PropertyInstalledInfrastructures { get; set; }
    }
}
