﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class ContractTypeBasedOnUserStatus : SysEntity
    {
        public byte ContractTypeBasedOnUserStatusID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<PropertyLeaseData> PropertyLeaseData { get; set; }
    }
}
