﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class OBS_RBA_SPF_PropertyType : SysEntity
    {
        public byte OBS_RBA_SPF_PropertyTypeID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<Property> Properties { get; set; }
    }
}
