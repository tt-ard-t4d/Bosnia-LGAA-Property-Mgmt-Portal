﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.CodeBooks
{
    public class DisputeType : SysEntity
    {
        public byte DisputeTypeID { get; set; }
        public string Value { get; set; }
        public virtual ICollection<Property> Properties { get; set; }
    }
}
