﻿namespace PropertyManagementPortal.Domain.Entities
{
    public class UserGroupActionRel
    {
        public int UserGroupAndActionID { get; set; }
        public short UserGroupID { get; set; }
        public UserGroup UserGroup { get; set; }
        public int ActionID { get; set; }
        public Action Action { get; set; }
        public bool Retired { get; set; }
    }
}
