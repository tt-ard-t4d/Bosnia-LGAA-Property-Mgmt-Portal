﻿namespace PropertyManagementPortal.Domain.Entities.App
{
    public class PropertyValue : SysEntity
    {
        public Guid PropertyValueID { get; set; }
        public virtual Property Property { get; set; }
        public Guid PropertyID { get; set; }
        public decimal CurrentYearBookkeepingValue { get; set; }
        public string? CurrentYearBookkeepingValueComment { get; set; }
        public decimal CurrentYearEstimatedMarketValue { get; set; }
        public string? CurrentYearEstimatedMarketValueComment { get; set; }
        public decimal EstimatedMaintenanceCost { get; set; }
        public string? EstimatedMaintenanceCostComment { get; set; }
    }
}
