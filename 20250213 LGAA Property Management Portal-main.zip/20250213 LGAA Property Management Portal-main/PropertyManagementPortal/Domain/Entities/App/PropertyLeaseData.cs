﻿using PropertyManagementPortal.Domain.Entities.CodeBooks;
using PropertyManagementPortal.Domain.Entities.Utils;

namespace PropertyManagementPortal.Domain.Entities.App
{
    public class PropertyLeaseData : SysEntity
    {
        public Guid PropertyLeaseDataID { get; set; }
        public virtual Property Property { get; set; }
        public Guid PropertyID { get; set; }
        public virtual PropertyStatus PropertyStatus { get; set; }
        public virtual IEnumerable<AttachedFiles> Attachments { get; set; }
        public byte PropertyStatusID { get; set; }
        public string? PropertyUserName { get; set; } = string.Empty;
        public string? ContractNumber { get; set; } = string.Empty;
        public DateTime? ContractConclusionDate { get; set; }
        public int? ContractDurationInMonths { get; set; }

        public virtual PaymentFrequency? PaymentFrequency { get; set; }
        public byte? PaymentFrequencyID { get; set; }
        public string? OtherContractualObligations { get; set; } = string.Empty;

        //Dokument na osnovu kog je zemljište dato na korištenje/osnov korištenja
        //drop down menue (Ugovor, odluka, drugo)
        public virtual PropertyUseBasisDocument? PropertyUseBasisDocument { get; set; }
        public byte? PropertyUseBasisDocumentID { get; set; }

        //Osnov korištenja zemljišta
        //drop down menue (zakup, podzakup, koncesija, drugo)
        public virtual PropertyUseBasis? PropertyUseBasis { get; set; }
        public byte? PropertyUseBasisID { get; set; }

        //Spol korisnika/većinski vlasnik korisnika
        public virtual PropertyUserGender? PropertyUserGender { get; set; }
        public byte? PropertyUserGenderID { get; set; }

        //drop dow menue (kompanija, udruženje, obrt, zadruga, fizičko lice, drugo)
        public virtual PropertyUserType? PropertyUserType { get; set; }
        public byte? PropertyUserTypeID { get; set; }
        public string? PropertyUserTypeOther { get; set; }
        public decimal? ContractedValue { get; set; }

        //Vrsta ugovora po osnovu statusa korisnika
        //drop dow menue (komercijalna cijena, subvencionirana cijena - socijalna kategorija xxx, drugo)
        public virtual ContractTypeBasedOnUserStatus? ContractTypeBasedOnUserStatus { get; set; }
        public byte? ContractTypeBasedOnUserStatusID { get; set; }

        //Vrsta ugovora
        //drop dow menue (Ugovor o prodaji, Ugovor o najmu/zakupu/podzakupu, Drugo)
        public virtual ContractType? ContractType { get; set; }
        public byte? ContractTypeID { get; set; }
    }
}
