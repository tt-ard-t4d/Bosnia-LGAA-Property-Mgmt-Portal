﻿namespace PropertyManagementPortal.Domain.Entities.App
{
    public class Entity
    {
        public byte EntityID { get; set; }
        public string EntityName { get; set; } = string.Empty;
        public virtual ICollection<Municipality> Municipalities { get; set; }
        public bool Retired { get; set; }
    }
}
