﻿using PropertyManagementPortal.Domain.Entities.CodeBooks;
using PropertyManagementPortal.Domain.Entities.Utils;

namespace PropertyManagementPortal.Domain.Entities.App
{
    public class Property : SysEntity
    {
        #region <!--- common fields --->
        public Guid PropertyID { get; set; }
        public virtual ICollection<PropertyLeaseData> PropertyLeaseData { get; set; }
        public int PropertyDisplayID { get; set; }
        public virtual Municipality Municipality { get; set; }
        public int MunicipalityID { get; set; }
        public virtual PropertyCategory PropertyCategory { get; set; }
        public byte PropertyCategoryID { get; set; }
        public string LocationAddress { get; set; } = string.Empty;
        public string? KO { get; set; } = string.Empty;
        public string? KP { get; set; } = string.Empty;
        public virtual IEnumerable<AttachedFiles> Attachments { get; set; }

        //List nepokretnosti
        public string? PropertyRegister { get; set; } = string.Empty;
        public byte? ZoneId { get; set; }
        public virtual Zone? Zone { get; set; }

        //na 7 decimala
        public decimal? Latitude { get; set; }

        //na 7 decimala
        public decimal? Longitude { get; set; }
        public decimal? PropertyArea { get; set; }
        public int? OBS_RBA_SPF_UnitNumber { get; set; }
        public decimal? OBS_RBA_SPF_GardenArea { get; set; }

        public string PropertyOwner { get; set; } = string.Empty;

        //Osnova posjedovanja/raspolaganja/korištenja
        //drop down menue(svojina, pravo korištenja, drugo)
        public virtual PossessionBasis? PossessionBasis { get; set; }
        public byte? PossessionBasisID { get; set; }

        //drop down menue (isključivo vlasništvo, suvlasništvo, zajedničko, izvanknjižno)
        public virtual OwnershipType? OwnershipType { get; set; }
        public byte? OwnershipTypeID { get; set; }

        //postojanje spora
        public bool? IsDispute { get; set; }
        public virtual DisputeType? DisputeType { get; set; }
        public byte? DisputeTypeID { get; set; }
        public bool? UsurpationExists { get; set; }

        //Godina sticanja prava vlasništva
        public int? OwnershipRightsAcquisitionYear { get; set; }

        //Pravni osnov sticanja prava vlasništva
        public virtual OwnershipRightsAcquisitionLegalBasis? OwnershipRightsAcquisitionLegalBasis { get; set; }
        public byte? OwnershipRightsAcquisitionLegalBasisID { get; set; }

        //Podaci o ispravi o sticanju prava vlasništva
        public string? OwnershipRightsAcquisitionLegitimationInformation { get; set; } = string.Empty;
        public bool? IsNationalizedProperty { get; set; }

        //Zabrana raspolaganja
        public bool? IsRestrictedDisposition { get; set; }

        public RestrictedRealRightInformation? RestrictedRealRightInformation { get; set; }
        public byte? RestrictedRealRightInformationID { get; set; }
        public string? RestrictedRealRightInformationOther { get; set; }
        public virtual ICollection<PropertyValue>? PropertyValues { get; set; }

        #endregion

        #region <!--- Agricultural land --->
        public virtual AL_CreditRatingCategory? AL_CreditRatingCategory { get; set; }
        public byte? AL_CreditRatingCategoryID { get; set; }
        public virtual AL_LandType? AL_LandType { get; set; }
        public byte? AL_LandTypeID { get; set; }

        #endregion

        #region <!--- Building land --->
        public bool? BL_HasConstructionRights { get; set; }
        public virtual BL_ConstructionRightsBasis? BL_ConstructionRightsBasis { get; set; }
        public byte? BL_ConstructionRightsBasisID { get; set; }
        public string? BL_ConstructionRightsHolder { get; set; }

        #endregion

        public string? AL_BL_LandUseAccordingRegulatoryPlan { get; set; }

        #region <!--- Office buildings/spaces --->

        public virtual OBS_RBA_SPF_PropertyType? OBS_RBA_SPF_PropertyType { get; set; }
        public byte? OBS_RBA_SPF_PropertyTypeID { get; set; }
        public decimal? OBS_RBA_SPF_NumberOfFloors { get; set; }

        //Etažirano
        public bool? OBS_RBA_IsSharedObject { get; set; }
        public virtual OBS_RBA_SPF_EnergyClass? OBS_RBA_SPF_EnergyClass { get; set; }
        public byte? OBS_RBA_SPF_EnergyClassID { get; set; }

        #endregion

        #region <!--- Residential buildings/apartments --->
        public int? OBS_RBA_SPF_BuildYear { get; set; }
        public virtual OBS_RBA_SPF_Condition? OBS_RBA_SPF_Condition { get; set; }
        public byte? OBS_RBA_SPF_ConditionID { get; set; }

        #endregion

        #region <!--- Special-purpose facilities --->
        public bool? SPF_IsLegallyConstructed { get; set; }
        public SPF_PropertyType? SPF_PropertyType { get; set; }
        public byte? SPF_PropertyTypeID { get; set; }

        #endregion

        public string? Comment { get; set; }
        public virtual ICollection<PropertyInstalledInfrastructureRel> PropertyInstalledInfrastructures { get; set; }

        public string? PropertyInstalledInfrastructuresOther { get; set; }

    }
}
