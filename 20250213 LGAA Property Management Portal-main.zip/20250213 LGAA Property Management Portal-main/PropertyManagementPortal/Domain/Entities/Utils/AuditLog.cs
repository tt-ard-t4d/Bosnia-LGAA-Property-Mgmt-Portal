﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Entities.Utils
{
    public class AuditLog
    {
        public int AuditLogID { get; set; }
        public string AuditLogText { get; set; }
        public int SysCreatedByUserID { get; set; }
        public DateTime SysCreatedDate { get; set; }
        public int? SysLastModifiedByUserID { get; set; }
        public DateTime? SysLastModifiedDate { get; set; }
        public long? RelatedItemID { get; set; }
        public int? AuditLogEnumerationID { get; set; }
    }
}
