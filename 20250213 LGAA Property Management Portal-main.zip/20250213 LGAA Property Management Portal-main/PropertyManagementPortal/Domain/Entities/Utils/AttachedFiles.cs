﻿using PropertyManagementPortal.Domain.Entities.App;

namespace PropertyManagementPortal.Domain.Entities.Utils
{
    public class AttachedFiles
    {
        public int AttachedFileID { get; set; }
        public virtual Property? Property { get; set; }
        public Guid? PropertyID { get; set; }
        public virtual PropertyLeaseData? PropertyLeaseData { get; set; }
        public Guid? PropertyLeaseDataID { get; set; }
        public Guid AzureFileID { get; set; }
        public string FileName { get; set; }
        public string Extension { get; set; }
        public string ContentType { get; set; }
        public string Title { get; set; }
        public long? Size { get; set; }
        public string Link { get; set; }
        public Guid SysCreatedByUserID { get; set; }
        public bool Retired { get; set; }
    }
}
