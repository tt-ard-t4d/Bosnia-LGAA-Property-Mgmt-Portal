﻿namespace Domain.Entities.Utils
{
    public class EmailNotification
    {
        public int EmailNotificationID { get; set; }
        public string EmailDescription { get; set; }
        public string EmailSubject { get; set; }
        public string EmailText { get; set; }
        public DateTime SysDateCreated { get; set; }
        public DateTime? SysDateLastModified { get; set; }
        public int SysCreatedByUserID { get; set; }
        public int? SysModifiedByUserID { get; set; }
        public int? EmailStatus { get; set; }
    }
}
