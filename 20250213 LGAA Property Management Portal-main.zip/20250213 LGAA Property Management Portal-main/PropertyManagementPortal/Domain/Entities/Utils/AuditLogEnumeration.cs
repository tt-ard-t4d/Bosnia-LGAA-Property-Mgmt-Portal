﻿using PropertyManagementPortal.Domain.Entities;

namespace Domain.Entities.Utils
{
    public class AuditLogEnumeration : SysEntity
    {
        public int AuditLogEnumerationID { get; set; }
        public string AuditLogEnumerationDescription { get; set; }
        public string AuditLogEnumerationText { get; set; }
    }
}
