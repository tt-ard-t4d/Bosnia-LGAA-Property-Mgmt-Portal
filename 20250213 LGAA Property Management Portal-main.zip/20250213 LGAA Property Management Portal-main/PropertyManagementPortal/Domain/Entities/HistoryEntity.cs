﻿namespace PropertyManagementPortal.Domain.Entities
{
    public abstract class HistoryEntity
    {
        public int HistoryID { get; set; }
        public Guid SysCreatedByUserID { get; set; }
        public DateTime SysCreatedDate { get; set; }
        public Guid? SysLastModifiedByUserID { get; set; }
        public DateTime? SysLastModifiedDate { get; set; }
        public bool Retired { get; set; }
        public short? Status { get; set; }
        public string? StatusName { get; set; }
        public DateTime SysEntryTime { get; set; }
    }
}
