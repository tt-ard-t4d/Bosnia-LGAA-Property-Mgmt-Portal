﻿namespace PropertyManagementPortal.Domain.Entities
{
    public class Action : SysEntity
    {
        public int ActionID { get; set; }
        public string ActionName { get; set; } 
        public string ActionEnumerationName { get; set; }
        public string? Description  { get; set; }
        public virtual ICollection<UserActionRel> UserActions { get; set; }
        public virtual ICollection<UserGroupActionRel> UserGroupActions { get; set; }
    }
}
