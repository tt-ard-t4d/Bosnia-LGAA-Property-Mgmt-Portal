using Infrastructure.Helpers;
using PropertyManagementPortal.Startup;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

   
//Configure services
builder.Services.RegisterApplicationServices(builder.Configuration);

//Validators
builder.Services.RegisterValidators();


builder.Host.UseSerilog();

Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .CreateLogger();

var app = builder.Build();

AppSettingsHelper.AppSettingsConfigure(app.Services.GetRequiredService<IConfiguration>(), app.Services.GetRequiredService<IHttpContextAccessor>());

//Middleware
app.ConfigureMiddleware();

app.Run();
